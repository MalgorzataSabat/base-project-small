<?php

class CronController extends Base_Controller_Action
{


    public function indexAction()
    {
        Base_Layout::disableLayout();
        Base_Layout::disableView();

        $queryOptions = array(
            'service' => $this->getParam('service'),
        );

        $cronList = Cron::getListToRun($queryOptions);

        foreach ($cronList as $cron) {
            try {
                if ( class_exists($cron['service']) ) {
                    $model = new $cron['service'];
                    $model->cron();
                    Cron::updateExecutionTime($cron['service']);
                }
            } catch (Exception $e) {
                var_dump('Running service: '.$cron['service'].' - [ERROR]');
                var_dump($e->getMessage());
                exit();
            }
        }
    }




}

