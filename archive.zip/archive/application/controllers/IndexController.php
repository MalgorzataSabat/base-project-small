<?php

class IndexController extends Base_Controller_Action
{

	public function indexAction()
	{
		$layoutService = new Layout_Service('dashboard');
		$this->view->layoutService = $layoutService;
	}

	public function manifestAction()
	{
		$manifest = array(
			"ios" => true,
			"name" => "RiseNet CRM",
			"short_name" => "RiseNet CRM",
			"description" => "System RiseNet CRM",
			"default_locale" => "pl",
			"version" => 0.2,
			"author" => "RiseNet.pl",
			"icons" => array(
				array(
					"src" => "/assets/img/favicons/apple-icon-120x120.png",
					"sizes" => "120x120",
					"type" => "image/png"
				),
				array(
					"src" => "/assets/img/favicons/apple-icon-144x144.png",
					"sizes" => "144x144",
					"type" => "image/png"
				),
				array(
					"src" => "/assets/img/favicons/android-icon-192x192.png",
					"sizes" => "192x192",
					"type" => "image/png"
				),
			),
			"scope" => "/",
			"start_url" => "/",
			"background_color" => "#006D99",
			"theme_color" => "#006D99",
			"display" => "standalone"
		);

		if(Base_Auth::isIdentity() && Base_Auth::getUser('token')){
			$manifest['start_url'] = "/login?token=".Base_Auth::getUser('token').'&utm_source=homescreen';
		}


		$this->_helper->json($manifest);
	}

}

