<?php

/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-07-23
 * Time: 15:52
 */
class QueryController extends Base_Controller_Action
{

    /**
     * @var Query
     */
    private $_model;

    private $_queryUserList = null;

    /**
     * @var string
     */
    private $_formClassName = null;

    public function  preDispatch()
    {
        parent::preDispatch();

        $this->_formClassName = $this->_getParam('form');
        $this->forward403Unless($this->_formClassName);

        if(!class_exists($this->_formClassName)){
            $this->forward403('Class Not Exists: '.$this->_formClassName);
        }

        $queryOptions = array('form' => $this->_formClassName);
        $queryOptions['id_user'] = Base_Auth::getUserId();

        $this->_queryUserList = Query::getList($queryOptions);
    }


    public function indexAction()
    {
        $this->view->queryUserList = $this->_queryUserList;
        $this->view->formClassName = $this->_formClassName;
    }


    public function newAction()
    {
        $filter = new $this->_formClassName();

        $this->_model = new Query();
        $this->_model->form = $filter->getElementsBelongTo();
        $this->_model->data = json_encode($filter->getValuesData());

        $this->_formQuery();
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_query_new') );
    }


    public function editAction()
    {
        if(!isset($this->_queryUserList[$this->_getParam('id_query')])){
            $this->forward403('ID Query ('.$this->_getParam('id_query').') Not Exists to User ID ('.Base_Auth::getUserId().')' );
        }

        $this->_model = Query::findRecord($this->_getParam('id_query'));

        $this->_formQuery();
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_query_edit') );
    }

    private function _formQuery()
    {
        $form = new Admin_Form_Query(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                $this->_model->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit($this->_getReturnParams(), $this->_route_return);
                }
            }
        }

        $this->view->form = $form;
    }


    public function saveOrderAction()
    {
        $queryItems = (array)$this->_getParam('queryItems', array());
        $result = array('result' => false);

        if($queryItems){
            $order = 1;
            foreach($queryItems as $id_query){
                if(isset($this->_queryUserList[$id_query])){
                    $query = Query::findRecord($id_query);
                    $query->order = $order;
                    $query->save();

                    $order++;
                }
            }

            $result = array('result' => true);
        }

        $this->_helper->json($result);
    }

    public function deleteAction()
    {
        if(!isset($this->_queryUserList[$this->_getParam('id_query')])){
            $this->forward403('ID Query ('.$this->_getParam('id_query').') Not Exists to User ID ('.Base_Auth::getUserId().')' );
        }

        $this->_model = Query::findRecord($this->_getParam('id_query'));
        $this->forward403Unless($this->_model);

        $this->_model->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'admin_label');
            $this->_redirector()->gotoUrlAndExit($this->_getReturnUrl());
        }
    }

    public function saveAction()
    {
        if(!isset($this->_queryUserList[$this->_getParam('id_query')])){
            $this->forward403('ID Query ('.$this->_getParam('id_query').') Not Exists to User ID ('.Base_Auth::getUserId().')' );
        }

        $id_query = $this->_getParam('id_query');
        $this->_request->setParam('id_query', null);

        $formName = $this->getParam('form');
        $filter = new $formName();

        $this->_model = Query::findRecord($id_query);
        $this->_model->data = json_encode($filter->getValuesData());

        $this->_model->save();

        if($this->_request->isXmlHttpRequest()){
            $this->_helper->json(array('status' => 'OK'));
        }else{
            $this->_flash()->success->addMessage('label_cms_save_success');
            $this->_redirector()->gotoUrlAndExit($this->_getReturnUrl());
        }
    }

    private function _getReturnUrl()
    {
        $url = null;
        if($this->getParam('return')){ $url = $this->getParam('return');}
        elseif(isset($_SERVER['HTTP_REFERER'])){ $url = $_SERVER['HTTP_REFERER']; }
        if(empty($url)){ $url = Base::url('admin'); }

        return $url;
    }

}