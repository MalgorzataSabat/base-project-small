<?php
use GusApi\GusApi;
use GusApi\RegonConstantsInterface;
use GusApi\Exception\InvalidUserKeyException;
use GusApi\ReportTypes;


class ToolsController extends Zend_Controller_Action
{


    public function gusAction()
    {
        require_once 'vendor/autoload.php';
        $status = 0;
        $data = array();

        if (isset($_POST['nip_crm']) && $_POST['nip_crm']) {
            $data = array();
            $key = Setting::getSetting("tools.gus_key");
            $nip_crm = preg_replace('~\D~', '', $_POST['nip_crm']);

            $status = null;
            $gus = new GusApi(
                $key, new \GusApi\Adapter\Soap\SoapAdapter(
                    RegonConstantsInterface::BASE_WSDL_URL,
                    RegonConstantsInterface::BASE_WSDL_ADDRESS //<--- production server / serwer produkcyjny  _TEST
                )
            );

            if ($gus->serviceStatus() === RegonConstantsInterface::SERVICE_AVAILABLE) {

                try {

                    if (!isset($_SESSION['sid']) || !$gus->isLogged($_SESSION['sid'])) {
                        $_SESSION['sid'] = $gus->login();
                        $sid_crm = $_SESSION['sid'];
                    } else {
                        $sid_crm = $_SESSION['sid'];
                    }


                    try {
                        $gusReport = $gus->getByNip($sid_crm, $nip_crm);
                        $response = $gusReport;
                        if(isset($gusReport[0]))
                        {
                            if ($gusReport[0]->getType() == 'f')
                            {
                                $response = $gus->getFullReport($sid_crm, $gusReport[0], ReportTypes::REPORT_ACTIVITY_PHYSIC_CEIDG); //REPORT_ACTIVITY_PHYSIC_CEGID
                            }
                            if ($gusReport[0]->getType() == 'p')
                            {
                                $response = $gus->getFullReport($sid_crm, $gusReport[0], ReportTypes::REPORT_PUBLIC_LAW);
                            }

                        }

                    } catch (\GusApi\Exception\NotFoundException $e) {
                        $status = 0;
                        $response = 'ERROR:' . $gus->getResultSearchMessage($sid_crm);
                    }
                } catch (InvalidUserKeyException $e) {
                    $status = 0;
                    $response = 'ERROR:Bad user key!';
                }
            } else if ($gus->serviceStatus() === RegonConstantsInterface::SERVICE_UNAVAILABLE) {
                $status = 0;
                $response = 'ERROR:Server is unavailable now. Please try again later <br> For more information read server message belowe: <br> ' . $gus->serviceMessage();
            } else {
                $status = 0;
                $response = 'ERROR:Server technical break. Please try again later <br> For more information read server message belowe: <br> ' . $gus->serviceMessage();
            }

            if (strpos($response, 'ERROR') === false) {
                $status = 1;
                $dataAll = $this->preDataGus($response, $gusReport[0]->getType());
                $regon = $gusReport[0]->getRegon();
                if(substr($regon,9,5) == 0)
                {
                    $regon = substr($gusReport[0]->getRegon(), 0,9);
                }

                $nameReplaceFrom = array('SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ', 'SPÓŁKA KOMANDYTOWA');
                $nameReplaceTo = array('Sp. z o.o.', 'Sp. k.');
                $name = str_replace($nameReplaceFrom, $nameReplaceTo, $gusReport[0]->getName());

                $data = array(
                    'name' => $name,
                    'regon' => $regon,
                    'address_province' => $gusReport[0]-> getProvince(),
                    'address_city' => $gusReport[0]->getCity(),
                    'address_street' => $dataAll['street'],
                    'region' => $gusReport[0]->getProvince(),
                    'address_zip_code' => $gusReport[0]->getZipCode(),
                    'krs' => $dataAll['krs'],
                );


            }

        } else {
            $response = 'ERROR: Brak parametrów POST';

        }


        $this->_helper->json(array('status' => $status,  'data' => $data, 'resp' => $response ));
        exit;
    }

    private function preDataGus($response, $type)
    {
        $list = array();
        $data = $response->dane;
        if($type == 'f')
        {
            $list['street'][] = trim($data->fiz_adSiedzUlica_Nazwa);
            $list['street'][] = trim($data->fiz_adSiedzNumerNieruchomosci);
            $list['street'][] = !empty(trim($data->fiz_adSiedzNumerLokalu)) ? 'lok. '. trim($data->fiz_adSiedzNumerLokalu) : '';
            $list['krs'] = (string)$data->fizC_numerwRejestrzeEwidencji;
        }

        if($type == 'p')
        {
            $list['street'][] = trim($data->praw_adSiedzUlica_Nazwa);
            $list['street'][] = trim($data->praw_adSiedzNumerNieruchomosci);
            $list['street'][] = !empty(trim($data->praw_adSiedzNumerLokalu)) ? 'lok. '. trim($data->praw_adSiedzNumerLokalu) : '';
            $list['krs'] = (string)$data->praw_numerWrejestrzeEwidencji;
        }

        $list['street'] = join(' ', $list['street']);
        return $list;
    }

    public function searchAction()
    {
//        if($this->_request->isXmlHttpRequest())
//        {
            Base_Layout::disableLayout();
//        } else {
//            Base_Layout::setLayoutByType('default');
//            $this->_helper->viewRenderer('search-full');
//        }
        //Base_Layout::disableView();
        $search = $this->getParam('search');

        $sql = array();

        $sql[] = "SELECT 'task' as `type`, `t`.`hash` as `id`, CONCAT('#',`t`.`number`,': ',`t`.`subject`) as `title`, '' as `id_image`, CONCAT(`u`.`name`,' ',`u`.`surname`) as `desc`
          FROM `task` as `t` LEFT JOIN `user` as `u` ON `t`.`id_user` = `u`.`id_user`
            WHERE CONCAT(`t`.`number`,`t`.`subject`) LIKE concat('%',:search,'%')
              AND `t`.`id_service` = :id_service AND `t`.`deleted_at` IS NULL AND `t`.`archived_at` IS NULL";

        $sql[] = "SELECT 'client' as `type`, `id_client` as `id`, `name` as `title`, `id_client_image` as `id_image`, CONCAT(`email`,' ', `phone`) as `desc`
          FROM `client`
            WHERE CONCAT(`name`,`email`,`nip`,`phone`) LIKE concat('%',:search,'%')
              AND `id_service` = :id_service AND `deleted_at` IS NULL AND `archived_at` IS NULL";

        $sql[] = "SELECT 'user' as type, `id_user` as `id`, TRIM(CONCAT(name, ' ' ,surname)) as `title`, id_profile_image as `id_image`, CONCAT(`email`,' ', `phone`) as `desc`
          FROM `user`
            WHERE CONCAT(`name`,`surname`, `email`,`phone`) LIKE CONCAT('%',:search,'%')
              AND `id_service` = :id_service AND `deleted_at` IS NULL AND `archived_at` IS NULL";

        $sql[] = "SELECT 'person' as type, `id_person` as `id`, concat(name, ' ' ,surname) as `title`, '' as `id_image`, CONCAT(`email`,' ', `phone`) as `desc`
          FROM `person`
            WHERE CONCAT(`name`,`surname`,`email`,`phone`) LIKE CONCAT('%',:search,'%')
              AND `id_service` = :id_service AND `deleted_at` IS NULL AND `archived_at` IS NULL";


        $sql = join(' UNION ', $sql);

        $query = Doctrine_Manager::getInstance()->getCurrentConnection()->getDbh();
        $stmt = $query->prepare($sql);
        $stmt->execute(array(':search' => $search, ':id_service' => Base_Service::getId()));

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->view->searchList = $result;
    }
    

    public function cookieAction()
    {
        $name = $this->_getParam('name');
        $value = $this->_getParam('value');

        $bCookie = Base_Cookie::_();
        $bCookie->set($name, $value);

        $this->_helper->json(true);
    }


    public function getFileAction()
    {
        Base_Layout::disableLayout();
        Base_Layout::disableView();

        $filename = realpath(APPLICATION_DATA . DS . 'tmp' . DS .$this->getParam('file'));

        if ( file_exists($filename) ) {
            ob_clean();
            ob_end_flush();

            header('Content-Length: ' . filesize($filename));
            header('Content-Type: '. Base::getFileMimeType($filename));
            header('Content-Description: File Transfer');
            header('Content-Disposition: attachment; filename='.$this->getParam('file'));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');

            $handle = @fopen($filename, 'r');
            if($handle){
                while (($buffer = fgets($handle, 4096)) !== false) {
                    echo $buffer;
                }

                fclose($handle);
            }

            unlink($filename);
        } else {
            throw new Exception('File ' . $filename . ' doesn`t exist.');
        }
    }



}
