DELETE FROM `deal`;
DELETE FROM `bill`;
update `client` SET `finance_hour_rate` = NULL;
update `task` set `finance_hour_rate` = null, `finance_amount` = null;
DELETE FROM `invoice`;
DELETE FROM `log`;
DELETE FROM `outlook`;
DELETE FROM `project`;
