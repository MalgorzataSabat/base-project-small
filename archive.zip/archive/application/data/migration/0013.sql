ALTER TABLE `acl_rule` ADD `type` TINYINT UNSIGNED NOT NULL COMMENT '1 - zasoby systemowe; 2 - pola formularzy' AFTER `id_service`;
update `acl_rule` set `type` = 1;
ALTER TABLE `acl_rule` CHANGE `is_allow` `is_allow` TINYINT NOT NULL COMMENT 'Określenie dostępu: 0 – brak dostępu; 1 – nadanie dostępu';
ALTER TABLE `acl_rule` CHANGE `is_allow` `is_allow` TINYINT(4) NOT NULL COMMENT 'Określenie dostępu: 0 – brak dostępu; 1 – nadanie dostępu; Dla typu 2: 0 -brak widoczności; 1 - tylko podgląd; 2 - edycja';
