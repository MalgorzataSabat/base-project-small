ALTER TABLE `setting` CHANGE `id_service` `id_service` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator serwisu';
UPDATE `setting` SET `id_service` = NULL;
ALTER TABLE `email_send` CHANGE `id_service` `id_service` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator serwisu';
