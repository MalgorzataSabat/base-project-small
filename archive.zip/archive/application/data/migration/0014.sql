ALTER TABLE `query` ADD `hash` CHAR(32) NOT NULL AFTER `id_query`;
update `query` SET `hash` = MD5(CONCAT("asdfgsdfgdfsg",`id_query`));
ALTER TABLE `query` ADD UNIQUE(`hash`);



