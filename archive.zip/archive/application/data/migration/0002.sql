INSERT INTO `setting` (`id_setting`, `key`, `value`) VALUES (NULL, 'tools.gus_key', 'aef6fa8b0e93480fb8c1');

INSERT INTO `acl_rule` (`id_acl_rule`, `is_allow`, `role`, `resource`) VALUES (NULL, '1', 'user', 'default_tools');