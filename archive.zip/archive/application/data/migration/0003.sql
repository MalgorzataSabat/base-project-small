CREATE TABLE IF NOT EXISTS `service` (
  `id_service` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `created_at` timestamp NOT NULL COMMENT 'Data dodania',
  `updated_at` timestamp NOT NULL COMMENT 'Data aktualizacji',
  `is_active` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Czy serwis jest aktywny',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa serwisu',
  `domain` varchar(255) NOT NULL COMMENT 'Domana serwisu',
  PRIMARY KEY (`id_service`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `service`
--

INSERT INTO `service` (`id_service`, `created_at`, `updated_at`, `is_active`, `name`, `domain`) VALUES
(1, '2017-12-13 08:11:12', '2017-12-13 08:11:12', 1, 'Konto demo', ''),
(2, '2017-12-13 08:11:12', '2017-12-13 08:11:12', 1, 'RiseNet CRM', '');


