ALTER TABLE `email_send` ADD `id_service` INT UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu' AFTER `id_email_send`, ADD INDEX (`id_service`) ;
update `email_send` SET `id_service` = 1;
ALTER TABLE `email_send` ADD FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `setting` ADD `id_service` INT UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu' AFTER `id_setting`, ADD INDEX (`id_service`);
update `setting` SET `id_service` = 1;
ALTER TABLE `setting` ADD FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE RESTRICT ON UPDATE RESTRICT;

