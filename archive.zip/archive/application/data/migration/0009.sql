SET @idAclResource = (SELECT id_acl_resource FROM acl_resource WHERE name = 'user_access');

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (NULL, @idAclResource, 'user_query', 'Moduł Query', 'default', '', '', '', '');
SET @lastInsertId = LAST_INSERT_ID();

UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query' WHERE name = 'admin_query';
UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query_index' WHERE name = 'admin_query_index';
UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query_new' WHERE name = 'admin_query_new';
UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query_edit' WHERE name = 'admin_query_edit';
UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query_save-order' WHERE name = 'admin_query_save-order';
UPDATE `acl_resource_item` SET `id_acl_resource` = @lastInsertId, `name` = 'default_query_delete' WHERE name = 'admin_query_delete';

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @lastInsertId, 'default_query_save-query');