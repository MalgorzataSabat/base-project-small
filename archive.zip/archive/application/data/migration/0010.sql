INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'system.version', '1.7.2'), (NULL, NULL, '', '');
