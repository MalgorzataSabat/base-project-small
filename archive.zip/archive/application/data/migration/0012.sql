UPDATE `setting` SET `value` = '1.8.6' WHERE `setting`.`key` = 'system.version';
