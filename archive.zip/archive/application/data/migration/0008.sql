SET @id_acl_resource = (SELECT id_acl_resource FROM acl_resource WHERE `name` = 'default_tools');
INSERT INTO `acl_resource_item` (`id_acl_resource`, `name`) VALUES (@id_acl_resource, 'default_tools_search');

SELECT 'Client' as type, name, email, phone FROM `client` WHERE email like '%piotr%'
UNION ALL
select 'User', concat(name, " " ,surname), email, phone from `user` where email like '%piotr%';