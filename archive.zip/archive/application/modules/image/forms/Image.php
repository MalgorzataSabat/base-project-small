<?php

class Image_Form_Image extends Base_Form_Horizontal
{

    /**
     * @var Image
     */
    protected $_model;

    private $_subForm = null;


    protected function setSubForm($subForm)
    {
        $this->_subForm = $subForm;
    }

    public function init()
    {
        $fields = array();
        $buttons = array();

        $fields['title'] = $this->createElement( 'text', 'title', array(
            'label' => $this->_tlabel.'title',
            'dimension' => 12,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model->getTitle(),
        ));

        $fields['desc'] = $this->createElement('textarea', 'desc', array(
            'label' => $this->_tlabel.'desc',
            'filters' => array('StringTrim'),
            'dimension' => 12,
            'rows' => 6,
            'validators' => array(
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model->getDesc()
        ));


        $fields['image'] = $this->createElement('FileImage', 'image', array(
            'label' => $this->_tlabel.'id_image',
            'allowEmpty' => false,
            'validators' => array(
                array('Extension', false, 'jpg, png, gif'),
                array('Count', false, 1),
            ),
//            'filestyle' => array(
//                'buttonText' => $this->getView()->translate('button_browse_file'),
//                'size' => 'sm',
//                'buttonName' => 'btn-primary',
//                'buttonBefore' => true,
//            ),
        ));

        $imageDecorator = $fields['image']->getDecorator('FileImage');
        $imageDecorator->setOptions( array(
            'id_image' => $this->_model->id_image,
            'crop' => true,
        ));

        $this->addDisplayGroup($fields, 'main', array(
            'legend' => $this->_tlabel.'group_std',
        ));

        if($this->_subForm){
            $mainGroup = $this->getDisplayGroup('main');

            $subForm = new $this->_subForm(array('model' => $this->_model, 'wrapperClass' => 'wrapper-blue'));
            $this->addSubForm($subForm, 'subForm');

            $this->addHtmlTag(array($mainGroup, $subForm), array('class' => 'row'));
        }

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

    }

}