<?php

class Image_CdnController extends Zend_Controller_Action
{
    public function init()
    {
        ob_get_clean();

        $this->_helper->viewRenderer->setNoRender();
        $this->_helper->layout()->disableLayout();

        $format = $this->getRequest()->getParam('format');
        $id     = (int) $this->getRequest()->getParam('id');
        $key    = $this->getRequest()->getParam('key');
        $resize = $this->getRequest()->getParam('resize');
        $width  = $this->getRequest()->getParam('width');
        $height = $this->getRequest()->getParam('height');
        $params = $this->getRequest()->getParam('params');

        $image = Image::findRecord($id, array('translations_leftJoin' => true));

        if (!$image) {
            throw new Zend_Controller_Action_Exception('Image not found', 404);
        }

        $params = array(
            'id' => $id,
            'resize' => $resize,
            'width' => $width,
            'height' => $height,
            'format' => $format,
            'params' => $params,
        );

        $okKey = Image::getHashKey($params);
        if (DEBUG == false && $key != $okKey ) {
            throw new Zend_Controller_Action_Exception('Image not found', 404);
        }
        $this->getRequest()->setParam('image', $image);

        $this->_helper->cache(array('serve'), array('images', 'image_' . $id, 'object_' . $image->object_id, 'class_' . $image->channel));
    }

    public function mainAction()
    {
        throw new Zend_Controller_Action_Exception('Image not found', 404);
    }

    /**
     * Show image by params.
     *
     * All params validation - in router regural expression.
     */
    public function serveAction()
    {
        ini_set("gd.jpeg_ignore_warning", true);

        // @todo Zmiana formatu
        $format = $this->getRequest()->getParam('format');

        /** @var Image $image */
        $image = $this->getRequest()->getParam('image');
        $resize = $this->getRequest()->getParam('resize');
        $width = $this->getRequest()->getParam('width');
        $height = $this->getRequest()->getParam('height');
        $params_ex = array_filter(explode('-',$this->getRequest()->getParam('params')));
        $file_image = ROOT_PATH . $image->file_path;
        $file_image_tmp = null;
        $params = array( 'width' => $width, 'height' => $height, 'resize' => $resize);
        $params = $image->getParams($params);

        foreach($params_ex as $v){
            $params[$v[0]] = substr($v, 1);
        }

        $imageService = Base_Image::factory();
        $imageService->open($file_image);
        $image_modify = false;

        if(isset($params[Image::PARAM_CROP]) && $resize != Image::RESIZE_ORYGINAL){
            $cparams = explode(',', $params[Image::PARAM_CROP]);
            $imageService->crop($cparams[0], $cparams[1], $cparams[2], $cparams[3]);
            $image_modify = true;
        }

        if(isset($params[Image::PARAM_PERSPECTIVE]) && $resize != Image::RESIZE_ORYGINAL){
            if($image_modify){ $imageService->save($file_image); }

            $imageService = Base_Image::factory('Base_Image_Adapter_ImageMagick');
            $imageService->open($file_image);
            $imageService->generatePerspective('['.$params[Image::PARAM_PERSPECTIVE].']');
            $file_image = $file_image_tmp = APPLICATION_TMP . DS . $image->getId().'_'.Base::getHash().'.'.$format;
            $imageService->save($file_image);

            $imageService = Base_Image::factory();
            $imageService->open($file_image);
        }

        $imageContent = null;

        if (Image::RESIZE_TO_WIDTH == $resize) {
            $imageService->resize($width, 3000);
        } elseif (Image::RESIZE_TO_HEIGHT == $resize) {
            $imageService->resize(3000, $height);
        } elseif (Image::RESIZE_TO_BOTH == $resize) {
            $imageService->resize($width, $height);
        } elseif (Image::RESIZE_TO_BOTH_IF_BIGGER == $resize) {
            $imageService->resizeIfBigger($width, $height);
        } elseif (Image::RESIZE_TO_BOTH_AND_FILL == $resize) {
            $imageService->resize($width, $height);
        } elseif(Image::RESIZE_ADAPTIVE == $resize || Image::RESIZE_CROP == $resize) {
            $imageService->resizeOut($width, $height);
            $imageService->cropFromCenter($width, $height);
        }else{
            $imageContent = file_get_contents($file_image);
        }

        if(null !== $file_image_tmp){
            @unlink($file_image_tmp);
        }

        $this->getResponse()->setHeader('Content-type', $imageService->getMime(), true);
        if($imageContent){
            echo $imageContent;
        }else{
            echo $imageService.'';
        }
    }
}
