<?php

class Image_IndexController extends Base_Controller_Action
{

    /**
     * @var Image
     */
    private $_image;

    /**
     * @var array
     */
    private $_jsonData;


    public function init(){}


    public function listAction()
    {
    }

    public function uploadAction()
    {
        if ($this->_request->isPost()) {
            $this->_upload();
        }

        $this->_helper->json($this->_jsonData);
    }


    private function _upload()
    {
        $adapter = new Zend_File_Transfer_Adapter_Http();
        $adapter->addValidator('Extension', false, 'jpg,png,gif');
        $files = $adapter->getFileInfo();
        $channel = $this->getParam('channel');
        $object_id = $this->getParam('object_id', null);
        $title = $this->getParam('title');
        $desc = $this->getParam('desc');

        if(empty($object_id)){ $object_id = null; }

        foreach ($files as $file => $info) {
            $mimeType = $adapter->getMimeType($file);
            $size = $adapter->getFileSize($file);

            $image = Image::createImage($channel, array(
                'type' => Base::getFileExt($adapter->getFileName($file, false)),
                'name' => $adapter->getFileName($file, false),
                'source' => $info['tmp_name']),
                $object_id, $title, $desc
            );


            $imageData = array();
            $imageData['title'] = $title;
            $imageData['desc'] = $desc;
            $imageData['size'] = $size;
            $imageData['type'] = $mimeType;
            $imageData['deleteUrl'] = Base::url('image_delete', array('id_image' => $image->getId(), 'token'=> Base_SecurityToken::get($image['id_image'], 'image_delete')));
            $imageData['delete_type'] = 'DELETE';
            $imageData['url'] = Image::getUrl($image->getId(), array('width' => 1600, 'height' => 1200));
            $imageData['thumbUrl'] = Image::getUrl($image->getId(), array('width' => 220, 'height' => 220));

            $this->_jsonData['files'][] = $imageData;
        }
    }


    public function orderAction()
    {
        $images = (array) $this->getParam('image', array());
        $order=0;

        $conn = Doctrine_Manager::connection();
        $conn->beginTransaction();

        foreach($images as $image){
            Doctrine_Query::create()
                ->update('Image')
                ->set('order', '?', ++$order)
                ->set('is_main', '?', ($order == 1 ? 1 : 0))
                ->where('id_image = ?', $image)
                ->execute();
        }

        $conn->commit();

        $this->_helper->json(array(
            'status' => true,
            'gritter_title' => $this->view->translate('gritter-title_gallery_photo-order_save'),
            'gritter_text' => $this->view->translate('gritter-text_gallery_photo-order_save'),
        ));
    }


    public function editAction()
    {
        Base_Layout::setLayoutByType('default');

        $token = $this->getRequest()->getParam('token');
        $id_image = $this->getRequest()->getParam('id_image');
        $validToken = Base_SecurityToken::get($id_image, 'image_edit');

        if ($validToken != $token) {
            throw new Zend_Controller_Action_Exception('Invalid token', 403);
        }


        $this->_image = Image::findRecord($this->getParam('id_image'), array('translations_leftJoin' => true));
        $this->forward403Unless($this->_image);

        $form = new Image_Form_Image(array('model' => $this->_image));

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                $this->_image->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->json(array(
                        'html' => $form->render(),
                        'gritter_title' => $this->view->translate('gritter-title_record_save'),
                        'gritter_text' => $this->view->translate('gritter-text_record_save'),
                    ));
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit();
                }

            }elseif($this->_request->isXmlHttpRequest()){
                $this->_helper->json(array(
                    'html' => $form->render(),
                    'gritter_title' => $this->view->translate('gritter-title_validation_error'),
                    'gritter_text' => $this->view->translate('gritter-text_validation_error'),
                ));
            }
        }

        $this->view->form = $form;
        $this->_helper->viewRenderer('admin/form', null, array('noController' => true));

        $this->view->placeholder( 'page-title' )->set( $this->view->translate('page-title_image-edit') );
    }


    public function deleteAction()
    {
        $token = $this->getRequest()->getParam('token');
        $id_image = $this->getRequest()->getParam('id_image');
        $validToken = Base_SecurityToken::get($id_image, 'image_delete');

        if ($validToken != $token) {
            throw new Zend_Controller_Action_Exception('Invalid token', 403);
        }

        $this->_image = Image::findRecord($this->getParam('id_image'), array('translations_leftJoin' => true));

        if (!$this->_image){
            throw new Zend_Controller_Action_Exception("Image path '{$this->getParam('id_image')}' not exists", 404);
        }

        $this->_image->delete();

        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->json(array('status'=>1));
        }else{
            $return = $this->getParam('return');
            if(empty($return)){ $return = $this->getRequest()->getServer('HTTP_REFERER'); }
            if(empty($return)){ $return = '/'; }
            $this->_flash()->success->addMessage('label_service-image_delete-success');
            $this->_redirector()->gotoUrlAndExit($return);
        }

    }


    /**
     * Strona html - wyświetla widget do wyboru fragmentu zdjęcia.
     * Zdjęcie jest przekazane w parametrze 'img', który jest ścieżką do pliku
     * od katalogu publicznego.
     */
    public function cropperAction()
    {
        $token = $this->getRequest()->getParam('token');
        $id_image = $this->getRequest()->getParam('id_image');
        $validToken = Base_SecurityToken::get($id_image, 'image_cropper');

        if ($validToken != $token) {
            throw new Zend_Controller_Action_Exception('Invalid token', 403);
        }

        $this->_image = Image::findRecord($this->getParam('id_image'), array('translations_leftJoin' => true));
//        $imagePath = '/'.ltrim(base64_decode($this->getRequest()->getParam('path').''), '/');
        if (!$this->_image){
            throw new Zend_Controller_Action_Exception("Image path '{$this->getParam('id_image')}' not exists", 404);
        }

        $this->view->imagePath = $this->_image->getOrginalUrl();
        $this->view->selection = array(50, 50, 500, 500);
        $this->view->imageParams = $this->getImageParams();
        $this->view->preview_image_id = $this->getParam('preview_image_id');

        $this->_helper->layout()->setLayout('layout-image-cropper');

        if ($this->getRequest()->isXmlHttpRequest()) {
//            $config = $this->getRequest()->getParam('config');
            $cords = (array) $this->getRequest()->getParam('cords');
            $cords = array_map('intval', $cords);

            $params = array(Image::PARAM_CROP => $cords['x'].','.$cords['y'].','.$cords['w'].','.$cords['h']);
            try{
                $this->_image->setParams($params);
                $this->_image->save();
                $this->_helper->json(array('status'=>1));
            } catch (Exception $e) {
                $this->_helper->json(array('status'=>0, 'message'=> $e->getMessage()));
            }
        }
    }

    private function getImageParams()
    {
        $imageParams = $this->getRequest()->getParam('imageParams');

        $params = array();

        if (!empty($imageParams)) {
            $imageParams = json_decode($imageParams, true);
            if (false !== $imageParams) {
                $params = $imageParams;
            }
        }

        return $params;
    }


}
