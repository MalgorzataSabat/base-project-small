<?php
class Image_Acl
{
    /**
     * @var Base_Acl
     */
    protected $_acl;

    /**
     * @param $acl Base_Acl
     */
    public function __construct($acl)
    {
        $this->_acl = $acl;
    }


    public function loadAcl()
    {
        $this->_acl->addResource('image_index_list', '_user');
        $this->_acl->addResource('image_index_upload', '_user');
        $this->_acl->addResource('image_index_order', '_user');
        $this->_acl->addResource('image_index_edit', '_user');
        $this->_acl->addResource('image_index_delete', '_user');
        $this->_acl->addResource('image_index_cropper', '_user');

        $this->_acl->addResource('image_cdn_main', '_basic');
        $this->_acl->addResource('image_cdn_serve', '_basic');

        return $this->_acl;
    }


}