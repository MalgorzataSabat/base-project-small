<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('cdn', new Zend_Controller_Router_Route_Regex(
    'cdn/(\d+)/([a-zA-Z0-9]{5})-(w|h|b|c|a|m|bi|n|o)-(\d+)-(\d+)-(.*)\.(jpg|gif|png)',
    array(
        'module' => 'image',
        'controller' => 'cdn',
        'action' => 'serve',
        'format' => 'jpg',
        'resize' => 'b',
        'width' => '100',
        'height' => '100',
        'params' => '',
    ),
    array(
        1 => "id",
        2 => "key",
        3 => "resize",
        4 => "width",
        5 => "height",
        6 => "params",
        7 => "format",
    ),
    'cdn/%d/%s-%s-%d-%d-%s.%s'
));

$router->addRoute('image_manager', new Zend_Controller_Router_Route(
    '/image/manager/:action/:id/:class/*',
    array(
        'module' => 'image',
        'controller' => 'manager',
    )
));

$router->addRoute('image_cropper', new Zend_Controller_Router_Route(
    '/image/cropper/:id_image/:token/*',
    array(
        'module' => 'image',
        'controller' => 'index',
        'action' => 'cropper'
    ),
    array(
        'id_image' => '\d+'
    )
));


$router->addRoute('image_delete', new Zend_Controller_Router_Route(
    '/image/delete/:id_image/:token/*',
    array(
        'module' => 'image',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_image' => '\d+'
    )
));

$router->addRoute( 'image_upload', new Zend_Controller_Router_Route(
    '/@image/@upload',
    array(
        'module' => 'image',
        'controller' => 'index',
        'action' => 'upload'
    )
) );

$router->addRoute( 'image_order', new Zend_Controller_Router_Route(
    '/@image/@order',
    array(
        'module' => 'image',
        'controller' => 'index',
        'action' => 'order'
    )
) );

$router->addRoute('image_edit', new Zend_Controller_Router_Route(
    '/image/edit/:id_image/:token',
    array(
        'module' => 'image',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_image' => '\d+'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);
