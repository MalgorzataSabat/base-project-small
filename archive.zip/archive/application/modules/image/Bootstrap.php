<?php

class Image_Bootstrap extends Base_Application_Module_Bootstrap
{


}