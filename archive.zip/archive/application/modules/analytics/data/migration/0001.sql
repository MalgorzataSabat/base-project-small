CREATE TABLE IF NOT EXISTS `analytics` (
  `id_analytics` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_service` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `channel` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `chart_type` varchar(255) NOT NULL,
  `group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_analytics`),
  KEY `id_service` (`id_service`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `analytics` ADD CONSTRAINT `analytics_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`);


INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `desc`, `assert`, `resource_class`) VALUES (NULL, NULL, 'analytics', 'Analityka', '', '', '');
SET @idAclResourceAnalytics = LAST_INSERT_ID();

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `desc`, `assert`, `resource_class`) VALUES (NULL, @idAclResourceAnalytics, 'analytics_read', 'Przeglądanie', '', '', '');
SET @idAclResource1AnalyticsRead = LAST_INSERT_ID();
INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `desc`, `assert`, `resource_class`) VALUES (NULL, @idAclResourceAnalytics, 'analytics_write', 'Zarządzanie', '', '', '');
SET @idAclResource1AnalyticsWrite = LAST_INSERT_ID();


INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsRead, 'analytics_index_index');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsRead, 'analytics_index_show');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsRead, 'analytics_index_preview');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsWrite, 'analytics_index_manage');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsWrite, 'analytics_index_delete');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsWrite, 'analytics_index_edit');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource1AnalyticsWrite, 'analytics_index_new');
