<?php

class Analytics_Form_Element_Stats extends Base_Form_Element_Select
{
    private $_defaultName       = 'id_analytics';
//    private $_personStatusList    = array();
//    private $_defaultModel      = null;

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_id_analytics';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }


    private function _loadMultiOptions(&$options)
    {
        $multiOptions = array();
        if(!isset($options['required']) || !$options['required']){
            $multiOptions[''] = '';
        }

        $_list = Analytics::getList(array(
            'coll_key' => 'id_analytics',
            'order' => 'channel, name'
        ));

        foreach ($_list as $id => $v) {
            $multiOptions[$id] = $this->getView()->translate($v['channel']).' - '.$v['name'];
        }

        $options['multioptions'] = $multiOptions;

        $options['validators'][] = array('InArray', true, array(array_keys($multiOptions)));

    }
}