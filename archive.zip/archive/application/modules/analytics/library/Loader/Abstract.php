<?php

abstract class Analytics_Loader_Abstract
{

    /**
     * $var array
     */
    protected $_groupOptions;

    /**
     * @var array
     */
    protected $_result;

    /**
     * @var array
     */
    protected $_data;

    protected $_defaultGroup;

    protected $_dataQuery;

    public function setData($data)
    {
        if(is_string($data)){
            $data = json_decode($data, true);
        }


        $this->_data = $data;

        if(!$this->_data['group'] && $this->_defaultGroup){
            $this->_data['group'] = $this->_defaultGroup;
        }

        $this->setFormFilter();

        return $this;
    }

    public function setGroup($group)
    {
        $this->_groupOptions = $group;

        return $this;
    }

    public function getGroupOptions($toFormField = true)
    {
        $groupOptions = $this->_groupOptions;
        if($toFormField){
            $groupOptions = array_flip($groupOptions);

            foreach($groupOptions as $k => &$v){
                $v = $this->getGroupOptionName($k);
            }
        }

        return $groupOptions;
    }

    public function getGroupOptionName($k)
    {
        return strtolower(get_class($this)).'_groupby_'.$k;
    }

    public function getDefaultGroup()
    {
        return $this->_defaultGroup;
    }

    protected function setFormFilter()
    {
        $channel = Base_Analytics::getChannel($this->_data['channel']);

        $filterForm = new $channel['filter'](array(
            'defaultValues' => $this->_data['data'],
        ));
        $filterForm->populate($this->_data['data']);

        $this->_dataQuery = $filterForm->getValuesQuery(true);
    }

}