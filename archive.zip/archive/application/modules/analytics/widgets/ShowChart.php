<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 17.04.2018
 * Time: 12:32
 */

class Analytics_Widget_ShowChart extends Base_Widget_Abstract
{

    public $name = 'label_stats_widget_show-chart';

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return 'show-chart.phtml';
    }

    public function configureForm()
    {
        $fields = array();

        $fields['id_analytics'] = new Analytics_Form_Element_Stats('id_analytics', array(
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
        ));

        $this->view->form->addElements($fields);
    }

    public function renderWidget()
    {
        $data = null;
        if(isset($this->params['id_analytics'])){
            $data = Analytics::find($this->params['id_analytics']);
        }elseif(isset($this->params['data'])){
            $data = $this->params['data'];
        }


        $channel = Base_Analytics::getChannel($data['channel']);
        if(!$channel){
            return;
        }

        if(is_string($data['data'])) {
            $data['data'] = json_decode($data['data'], true)[$channel['filter']];
        }

        $loader = new $channel['loader']();
        $loader->setData($data);

        $this->view->data = $data;
        $this->view->result = $loader->getResult();
    }

}