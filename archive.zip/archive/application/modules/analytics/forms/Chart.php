<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.04.2018
 * Time: 12:18
 */

class Analytics_Form_Chart extends Base_Form_Horizontal
{
    /**
     * @var Stats
     */
//    protected $_model;

    private $_channel;

    protected function setChannel($channel)
    {
        $this->_channel = $channel;
    }


    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());
        $channelsList = Base_Analytics::getChannels();

        foreach ($channelsList as $channel)
        {
            $optionsChannel[$channel['key']] = $this->getView()->translate($channel['name']);
        }


        $filterForm = new $this->_channel['filter'](array(
            'tabColumnOn' => false,
            'isSubForm' => true,
            'useSession' => false,
        ));

        $filterForm->removeDecorator('FormFilter');
        $filterForm->removeDecorator('Form');
        $filterForm->removeDecorator('ViewHelper');
        $filterForm->removeElement('submit');
        $filterForm->removeElement('clear');

        $this->addSubForm($filterForm, 'stats-filter-form');
        $subFormFilter = $this->getSubForm('stats-filter-form');
        $subFormFilterGroup = $subFormFilter->getDisplayGroup('filter-search');
        $subFormFilterGroup->setLegend('<i class="fa fa-fw fa-database txt-color-blue"></i> Filtr danych');
        $subFormFieldsetDecorator = $subFormFilterGroup->getDecorator('Fieldset');
        $subFormFieldsetDecorator->setOption('escape', false);

        $this->addHtmlTag(array($subFormFilter), array('class' => 'form-filter',
            'data-belong-to' => $subFormFilter->getElementsBelongTo()
        ));



        $options = array(
            'pie' => $this->getView()->translate('label_stats_manage_chart-pie'),
            'column' => $this->getView()->translate('label_stats_manage_chart-column'),
            'bar' => $this->getView()->translate('label_stats_manage_chart-bar'),
            'line' => $this->getView()->translate('label_stats_manage_chart-line'),
            'area' => $this->getView()->translate('label_stats_manage_chart-area'),
        );
        $fields['chart_type'] = $this->createElement('select', 'chart_type', array(
            'label' => $this->_tlabel.'chart_type',
            'allowEmpty' => true,
            'required' => false,
            'label-size' => 3, 'size' => 9,
            'multioptions' => $options,
            'value' => ''
        ));

        $loaderName = $this->_channel['loader'];
        $loader = new $loaderName();
        $groupOptions = $loader->getGroupOptions();

        if($groupOptions){
            $fields['group'] = $this->createElement('select', 'group', array(
                'label' => $this->_tlabel.'group',
                'allowEmpty' => true,
                'required' => false,
                'label-size' => 3, 'size' => 9,
                'multioptions' => $groupOptions,
                'value' => $loader->getDefaultGroup(),
            ));
        }


        $this->addDisplayGroup($fields, 'main', array(
            'legend' => '<i class="fa fa-fw fa-bar-chart-o txt-color-greenLight"></i> Prezentacja',
            'escape' => false
        ));


        /***** SUBMIT FIELDS ******/
        $save = $this->createElement('button', 'submit', array(
            'label' => 'label_show',
            'icon' => 'save',
            'type' => 'submit',
            'class' => 'col-md-offset-3',
            'btnClass' => 'primary',
//            'offset' => 3,
        ));

        $save->setDecorators(array('ViewHelper'));
        $this->addHtmlTag(array($save), array('class'=> 'form-actions', 'style' => 'text-align: left;'));
        $this->addElements(array($save));

//        $this->setAttrib('class', $this->getAttrib('class').' form-filter');
//        $this->setAttrib('id', $this->getElementsBelongTo());
//        $this->setAttrib('data-overbox-replace', true);
        //$this->setAttrib('data-replace', '#'.$this->getElementsBelongTo());
    }

    public function getAnalyticsValues()
    {
        $anlyticsValues = array();
        $anlyticsValues['channel'] = $this->_channel['key'];
        $anlyticsValues['chart_type'] = $this->getValue('chart_type');
        $anlyticsValues['group'] = $this->getValue('group');
        $anlyticsValues['data'] = $this->getSubForm('stats-filter-form')->getValues(true);

        return $anlyticsValues;

    }

//    public function postIsValid($data)
//    {
//        parent::postIsValid($data);
//
//        $data = $this->getSubForm('stats-filter-form')->getValues(false);
//        $this->_model->data = json_encode($data);
//
//        return true;
//    }
}