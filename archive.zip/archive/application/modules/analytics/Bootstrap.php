<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 17.04.2018
 * Time: 12:30
 */

class Analytics_Bootstrap extends Base_Application_Module_Bootstrap
{

    public function _initWidgets()
    {
//        Base_Widget::registerWidget('Analytics_Widget_ShowChart', 'analytics');
    }

}