<?php

$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('analytics', new Zend_Controller_Router_Route(
    '/@analytics/:channel',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'index',
        'channel' => null,
    ),
    array(
        'channel' => '.*'
    )
));

$router->addRoute('analytics_panel', new Zend_Controller_Router_Route(
    '/@analytics/@panel',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'panel'
    )
));

$router->addRoute('analytics_edit', new Zend_Controller_Router_Route(
    '/@analytics/@edit/:id_analytics',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_analytics' => '\d+'
    )
));

$router->addRoute('analytics_manage', new Zend_Controller_Router_Route(
    '/@analytics/manage',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'manage'
    )
));

$router->addRoute('analytics_delete', new Zend_Controller_Router_Route(
    '/@analytics/@delete/:id_analytics',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_analytics' => '\d+'
    )
));

$router->addRoute('analytics_show', new Zend_Controller_Router_Route(
    '/@analytics/@show/:id_analytics',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_analytics' => '\d+'
    )
));

$router->addRoute('analytics_preview', new Zend_Controller_Router_Route(
    '/@analytics/@preview/:channel/:id_analytics',
    array(
        'module' => 'analytics',
        'controller' => 'index',
        'action' => 'preview',
        'id_analytics' => null
    ),
    array(
        'channel' => '.*',
        'id_analytics' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);