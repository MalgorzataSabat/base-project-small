<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 17.04.2018
 * Time: 12:31
 */

class Analytics_IndexController extends Base_Controller_Action
{
    /**
     * @var Analytics
     */
    private $_analytics;

    private $_form;

    private $_channel;

//    public function indexAction()
//    {
//        $this->_analytics = new Analytics();
//        $this->_analytics->channel = $this->getParam('channel');
//        if(!Base_Stats::isChannelExists($this->_analytics->channel)){
//            $this->forward404('Channel not exists: '.$this->_analytics->channel);
//        }
//
//        $this->_formAnalytics();
//    }

    public function indexAction()
    {
        $channelKey = $this->getParam('channel');
        if(Base_Analytics::isChannelExists($channelKey)){
            $this->_channel = Base_Analytics::getChannel($channelKey);
        }

        if(!$this->_channel){
            $this->_channel = Base_Analytics::getDefaultChannel();
        }

        if(!$this->_channel){
            $this->forward404('Channel not set');
        }


        $this->_form = new Analytics_Form_Chart(array('channel' => $this->_channel));
//        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() && $this->hasParam($this->_form->getElementsBelongTo())
            && $this->_form->populate($this->_request->getPost())) {
//            $this->_analytics->save();
//
//            if($this->_request->isXmlHttpRequest())
//            {
//                $this->_helper->viewRenderer('form-ajax-result');
//            } else {
//                $this->_flash()->success->addMessage('label_cms_save_success');
//                $this->_redirector()->gotoRouteAndExit(array(), 'analytics');
//            }
        }

//        var_dump($this->_form->getAnalyticsValues());
//        exit();

        $this->view->form = $this->_form;
        $this->view->channel = $this->_channel;
        $this->view->analyticsValues = $this->_form->getAnalyticsValues();
    }


    public function panelAction()
    {
        $layoutService = new Layout_Service('analytics');

        $channelList = Base_Stats::getChannels();


        $this->view->channelList = $channelList;
        $this->view->layoutService = $layoutService;
    }

    public function editAction()
    {
        $this->_analytics = Analytics::findRecord($this->getParam('id_analytics'));
        if($this->hasParam('channel'))
        {
            $this->_analytics->channel = $this->getParam('channel');
        }
        $this->forward403Unless($this->_analytics);

        $this->_formAnalytics();
    }

    private function _formAnalytics()
    {
        $this->_form = new Analytics_Form_Stats(array('model' => $this->_analytics));
//        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() && $this->hasParam($this->_form->getElementsBelongTo())
            && $this->_form->isValid($this->_request->getPost())) {
            $this->_analytics->save();

            if($this->_request->isXmlHttpRequest())
            {
                $this->_helper->viewRenderer('form-ajax-result');
            } else {
                $this->_flash()->success->addMessage('label_cms_save_success');
                $this->_redirector()->gotoRouteAndExit(array(), 'analytics');
            }
        }

        $this->view->analytics = $this->_analytics;
        $this->view->form = $this->_form;
    }

    public function manageAction()
    {
        $query = Analytics::getQuery();

        $channelList = Base_Stats::getChannels();


        $this->view->channelList = $channelList;
        $this->view->analyticsList = $this->_helper->paging($query, array('limit' => 30));
    }

    public function deleteAction()
    {
        $this->_analytics = Analytics::findRecord($this->getParam('id_analytics'));
        $this->forward403Unless($this->_analytics);

        $this->_analytics->delete();
        $this->_analytics->save();

        $this->_helper->viewRenderer('form-ajax-result');
//        if($this->_request->isXmlHttpRequest())
//        {
//        } else {
//            $this->_flash()->success->addMessage('label_cms_save_success');
//            $this->_redirector()->gotoRouteAndExit(array(), 'stats_manage');
//        }
    }

    public function showAction()
    {
        $this->_analytics = Analytics::findRecord($this->getParam('id_analytics'));
        $this->forward403Unless($this->_analytics);

        $this->view->analytics = $this->_analytics;
    }

    public function previewAction()
    {
        Base_Layout::disableLayout();


        if($this->hasParam('id_analytics'))
        {
            $this->_analytics = Analytics::findRecord($this->getParam('id_analytics'));
            $this->_analytics->channel = $this->getParam('channel');
        } else {
            $this->_analytics = new Analytics();
            $this->_analytics->channel = $this->getParam('channel');
        }
        if(!Base_Analytics::isChannelExists($this->_analytics->channel)){
            $this->forward404('Channel not exists: '.$this->_analytics->channel);
        }

        if($this->hasParam('Analytics_Form_Stats'))
        {
            $params = $this->getParam('Analytics_Form_Stats');
            $this->_analytics->group = $params['group'];
            $this->_analytics->chart_type = $params['chart_type'];
            unset($params['name']);
            unset($params['desc']);
            unset($params['chart_type']);
            unset($params['group']);
            $this->_analytics->data = json_encode($params);
        }

        $channel = Base_Analytics::getChannel($this->_analytics['channel']);

        $loader = new $channel['loader']($this->_analytics);

        $this->view->analytics = $this->_analytics;
        $this->view->analyticsList = $loader->getResult();
    }

}