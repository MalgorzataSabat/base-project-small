<?php
$router = Zend_Controller_Front::getInstance()->getRouter();


$router->addRoute('address_ajax_get-province-list', new Zend_Controller_Router_Route(
    '/@address/@ajax/province',
    array(
        'module' => 'address',
        'controller' => 'ajax',
        'action' => 'get-province-list'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);