<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 25.11.2016
 * Time: 10:57
 */
class Address_Form_Element_Province extends Base_Form_Element_Select
{

    private $_defaultName   = 'id_province';
    private $_provinceList  = array();

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_address_province';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    public function getProvinceList()
    {
        return $this->_provinceList;
    }

    private function _loadMultiOptions(&$options)
    {
        $provinceOptions = array();

        if(!isset($options['required']) || !$options['required']){
            $provinceOptions[''] = '';
        }

        $id_country = Setting::getSetting('address.id_country_default');

        if(isset($options['country']) && $options['country']){
            $id_country = $options['country'];
        }

        $this->_provinceList = AddressProvince::getList(array(
            'id_country' => $id_country,
            'coll_key' => 'id_province'
        ));

        foreach ($this->_provinceList as $id_province => $v) {
            $provinceOptions[$id_province] = $v['name'];
        }

        $options['multioptions'] = $provinceOptions;

        $options['validators'][] = array('InArray', true, array(array_keys($provinceOptions)));

    }
}