<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 25.11.2016
 * Time: 10:51
 */
class Address_Form_Element_Country extends Base_Form_Element_Select
{

    private $_defaultName   = 'id_country';
    private $_countryList   = array();

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_address_country';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        $options['select2'] = array(
            'allowClear' => true,
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    public function getCountryList()
    {
        return $this->_countryList;
    }

    private function _loadMultiOptions(&$options)
    {
        $countryOptions = array();
        $this->_countryList = AddressCountry::getList(array('coll_key' => 'id_country'));

        foreach ($this->_countryList as $id_country => $v) {
            $countryOptions[$id_country] = $v['name'];
        }

        $countryOptions = array('' => '') + $countryOptions;

        $options['multioptions'] = $countryOptions;

        $options['validators'][] = array('InArray', true, array(array_keys($countryOptions)));
    }
}