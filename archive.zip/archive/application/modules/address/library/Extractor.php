<?php


class Address_Extractor extends Base_Extractor
{

    protected $_tables = array('address_country', 'address_province');

    protected $_data = array('address_country', 'address_province');

    protected $_module = 'address';

    protected $_dumpResource = array('address');

    protected $_dumpLabel = array('address');

    protected $_dumpChangelog = array('address');

    protected $_dumpSettings = array('address');

    protected $_dumpDictionary = array();

    protected $_dumpRule = array('address');

}