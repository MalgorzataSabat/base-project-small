<?php
/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.10.2014
 * Time: 12:38
 */

class Address_AjaxController extends Base_Controller_Action {


    public function init()
    {
        Base_Layout::disableView();
        Base_Layout::disableLayout();

        if(!$this->_request->isXmlHttpRequest()){
            $this->forward403('Only XmlHttpRequest');
        }
    }


    public function getProvinceListAction()
    {
        $id_country = $this->_getParam('q');
        $provinceList = array();
        if ( !empty( $id_country ) ) {
            $list = AddressProvince::getList(array('id_country' => $id_country));
            foreach($list as $v){
                $provinceList[$v['id_province']] = $v['name'];
            }
        }
        $this->_helper->json(array('result' => true, 'list' => $provinceList));
    }
}