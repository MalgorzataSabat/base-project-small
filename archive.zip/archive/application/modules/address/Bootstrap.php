<?php
/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.10.2014
 * Time: 10:00
 */

class Address_Bootstrap extends Base_Application_Module_Bootstrap {

} 