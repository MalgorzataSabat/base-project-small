-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_country` (
  `id_country` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator kraju',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa kraju',
  `short_code` varchar(3) NOT NULL COMMENT 'Kod kraju',
  PRIMARY KEY (`id_country`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Lista państw';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address_province`
--

DROP TABLE IF EXISTS `address_province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_province` (
  `id_province` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator regionu',
  `id_country` int(10) unsigned NOT NULL COMMENT 'Identyfikator kraju',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa regionu',
  PRIMARY KEY (`id_province`),
  KEY `id_country` (`id_country`),
  CONSTRAINT `address_province_ibfk_1` FOREIGN KEY (`id_country`) REFERENCES `address_country` (`id_country`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='Lista województw';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
INSERT INTO `address_country` VALUES (1,'Polska','PL'),(2,'Niemcy','DE');
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `address_province`
--

LOCK TABLES `address_province` WRITE;
/*!40000 ALTER TABLE `address_province` DISABLE KEYS */;
INSERT INTO `address_province` VALUES (1,1,'Dolnośląskie'),(2,1,'Kujawsko-Pomorskie'),(3,1,'Opolskie'),(4,1,'Lubelskie'),(5,1,'Lubuskie'),(6,1,'Łódzkie'),(7,1,'Małopolskie'),(8,1,'Mazowieckie'),(9,1,'Podkarpackie'),(10,1,'Podlaskie'),(11,1,'Pomorskie'),(12,1,'Śląskie'),(13,1,'Świętokrzyskie'),(14,1,'Warmińsko-Mazurskie'),(15,1,'Wielkopolskie'),(16,1,'Zachodniopomorskie');
/*!40000 ALTER TABLE `address_province` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'address','Adres','');
SET @resParentId54869 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54869,'address');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54869,'address_ajax');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54869,'address_ajax_get-province-list');
-- Dump MODULE: address
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'address'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('_install.sql','address','2017-07-08 08:25:19',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_group_std','label','0000-00-00 00:00:00','2017-03-11 16:19:48','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_id_province','label','0000-00-00 00:00:00','2017-03-11 16:20:00','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Województwo');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_id_city','label','0000-00-00 00:00:00','2017-03-11 16:20:07','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_id_quarter','label','0000-00-00 00:00:00','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dzielnica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_id_subquarter','label','0000-00-00 00:00:00','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Poddzielnica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_street','label','0000-00-00 00:00:00','2017-03-11 16:20:17','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_zip_code','label','0000-00-00 00:00:00','2017-03-11 16:20:27','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_province_empty','label','0000-00-00 00:00:00','2017-03-11 16:20:36','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','-- Wybierz województwo --');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_city_empty','label','0000-00-00 00:00:00','2017-03-11 16:20:45','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','-- Wybierz miasto --');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_quarter_empty','label','0000-00-00 00:00:00','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','- Wybierz dzielnicę -');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_subquarter_empty','label','0000-00-00 00:00:00','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','- Wybierz poddzielnicę -');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('module_name-address','label','0000-00-00 00:00:00','0000-00-00 00:00:00','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_id_country','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kraj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_country_empty','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','- Wybierz kraj -');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('address_form_address_number','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Numer budynku');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms-left_setting-type_address','label','2015-08-17 13:03:59','2015-12-10 11:34:08','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zarządzanie adresami');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_address.default_id_country','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Domyślny kraj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_address.form_display_country','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy wyświetlać pole kraju?');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_address.city_as_text','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa miejscowości jako tekst');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_type_address','label','2015-08-17 13:03:59','2015-12-10 11:34:08','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ustawienia adresu');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_address_form_city_insert','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','- Wpisz miejscowość -');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_address.form_display_quarter','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy wyświetlać pole dzielnicy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('admin_form_setting_address.form_display_subquarter','label','2015-08-17 13:03:59','2015-08-17 13:03:59','address','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy wyświetlać pole poddzielnicy?');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_address_country','label','2016-11-25 17:36:44','2016-11-25 17:36:44','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kraj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_address_province','label','2016-11-25 17:37:01','2016-11-25 17:37:01','address','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Region');
INSERT INTO `setting` (`key`, `value`) VALUES ('address.id_country_default', '1');
INSERT INTO `setting` (`key`, `value`) VALUES ('address.on_field_country', '0');
