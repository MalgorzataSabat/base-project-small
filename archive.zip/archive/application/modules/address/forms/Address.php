<?php
/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 09.10.2014
 * Time: 09:45
 */

class Address_Form_Address extends Base_Form_Horizontal {

    /**
     * @var $_model
     */
    protected $_model = null;

    private $_htmlTagClass = 'col-md-6';

    public function setHtmlTagClass($value)
    {
        $this->_htmlTagClass = $value;
    }

    public function init()
    {
        $this->getView()->headScript()->appendFile('/assets/js/address.js');

        $fields = array();

        if($this->_model->isNew()){
            $this->_model->id_address_country = Setting::getSetting('address.id_country_default');
        }

        // country field
        if ( Setting::getSetting('address.on_field_country') ) {
            $fields['id_address_country'] = new Address_Form_Element_Country('id_address_country', array(
                'value' => $this->_model->getIdAddressCountry(),
                'size' => 9, 'label-size' => 3,
                'decorators' => $this->_elementDecorators,
                'select2' => array(),
                'id' => $this->getElementsBelongTo().'-id_address_country',
                'data-url' => Base::url('address_ajax_get-province-list'),
                'data-name' => 'id_address_country',
                'data-address-selector' => '#'.$this->getElementsBelongTo().'-id_address_province',
                'class' => 'addressAjax addressTrigger',
                'filters' => array('Null')
            ));
        }

        // province field
        $id_country = $this->_model->getIdAddressCountry();
        $fields['id_address_province'] = new Address_Form_Element_Province('id_address_province', array(
            'value' => $this->_model->getIdAddressProvince(),
            'size' => 9, 'label-size' => 3,
            'decorators' => $this->_elementDecorators,
            'select2' => array(),
            'id' => $this->getElementsBelongTo().'-id_address_province',
            'data-name' => 'id_address_province',
            'country' => $id_country = !empty($id_country) ? $id_country : '',
            'filters' => array('Null')
        ));
        $fields['id_address_province']->getDecorator('FieldSize')->setOption('class', 'loader-place');
        // city field
        $fields['address_city'] = $this->createElement('text', 'address_city', array(
            'label' => $this->_tlabel.'id_city',
            'required' => false,
            'class' => 'address_city',
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'data-name' => 'id_city',
            'value' => $this->_model->getAddressCity()
        ));

        // field street
        $fields['address_street'] = $this->createElement('text', 'address_street', array(
            'label' => $this->_tlabel.'street',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'class' => 'address_street',
            'validators' => array(
                array('StringLength', true, array('min' => 3, 'max' => 255))
            ),
            'value' => $this->_model->getAddressStreet()
        ));

        // field zip code
        $fields['address_zip_code'] = $this->createElement('text', 'address_zip_code', array(
            'label' => $this->_tlabel.'zip_code',
            'required' => false,
            'class' => 'address_zip_code',
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('StringLength', true, array('min' => 4, 'max' => 6))
            ),
            'value' => $this->_model->getAddressZipCode()
        ));

        $this->addDisplayGroup(
            $fields,
            'main',
            array(
                'legend' => $this->_tlabel.'group_std',
                'class' => 'panel-primary'
            )
        );

        $group_main = $this->getDisplayGroup('main');

        $this->setDecorators(array(
            'FormElements'
        ));

        $this->addHtmlTag(array($group_main), array('class' => $this->_htmlTagClass . ' addressForm'));
    }

    public function isValid($data)
    {
        $this->populate($data);

        $id_address_country = $this->_model->id_address_country;
        if($this->getValue('id_address_country')){
            $id_address_country = $this->getValue('id_address_country');
        }

        // GET PROVINCE LIST
        if ($id_address_country) {
            $provinceList = AddressProvince::getList(array('id_country' => $id_address_country));
            $multiOptions = array('' => '');
            foreach($provinceList as $v){
                $multiOptions[$v['id_province']] = $v['name'];
            }

            $address_province = $this->getElement('id_address_province');
            $address_province->setMultiOptions($multiOptions);
            $address_province->getValidator('InArray')->setHaystack(array_keys($multiOptions));
        }

        return parent::isValid($data);
    }
} 