<?php

class Api_Bootstrap extends Base_Application_Module_Bootstrap
{

}