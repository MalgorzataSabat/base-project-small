-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_service`
--

DROP TABLE IF EXISTS `api_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_service` (
  `id_api_service` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `key` varchar(255) NOT NULL COMMENT 'Klucz',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa',
  `description` text COMMENT 'Opis',
  PRIMARY KEY (`id_api_service`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `api_service`
--

LOCK TABLES `api_service` WRITE;
/*!40000 ALTER TABLE `api_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_service` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'api','Api','');
SET @resParentId54650 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api_index_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api_index_new');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api_index_edit');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54650,'api_index_show');
-- Dump MODULE: api
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'admin', 'api');
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'api'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('0001.20171018165608.csv','api','2017-10-25 08:03:50',2),('0001.sql','api','2017-10-25 08:03:26',1),('0002.sql','api','2017-11-07 09:46:53',1),('_install.sql','api','2017-11-07 09:46:53',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:45
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_api-column_id_api_service','label','2017-10-25 10:03:49','2017-10-25 10:03:49','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_api-column_key','label','2017-10-25 10:03:49','2017-10-25 10:03:49','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Key');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_api-column_name','label','2017-10-25 10:03:49','2017-10-25 10:03:49','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_filter_id_api_service','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_filter_key','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Key');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_filter_name','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_filter_search','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szukaj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_api_admin_list_id_api_service','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_api_admin_list_key','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Key');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_api_admin_list_name','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_api_list','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Api');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_api_admin_list-add-button','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_api_name','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('api_form_api_description','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Opis');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_api_new','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_api_edit','label','2017-10-25 10:03:50','2017-10-25 10:03:50','api','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja');
INSERT INTO `setting` (`key`, `value`) VALUES ('api.id_service', '1');
INSERT INTO `setting` (`key`, `value`) VALUES ('api.key', '4605003159f821de80fba8b8f2f5e799');
