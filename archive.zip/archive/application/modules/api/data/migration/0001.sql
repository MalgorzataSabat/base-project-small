CREATE TABLE `api_service` ( `id_api_service` TINYINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator' , `key` VARCHAR(255) NOT NULL COMMENT 'Klucz' , `name` VARCHAR(255) NOT NULL COMMENT 'Nazwa' , `description` TEXT NULL COMMENT 'Opis' , PRIMARY KEY (`id_api_service`)) ENGINE = InnoDB;

INSERT INTO `setting` (`id_setting`, `key`, `value`) VALUES (NULL, 'api.id_service', '1'), (NULL, 'api.key', MD5('214ca4 635f1sdfgsf fgd9e9988es dfsdsfgdsfg  958526 6aa9 d103'));

INSERT INTO `api_service` (`id_api_service`, `key`, `name`, `description`) VALUES (NULL, MD5('214ca4 635f1sdfgsf fgd9e9988es dfsdsfgdsfg  958526 6aa9 d103'), 'Main', NULL);

INSERT INTO `acl_rule` (`id_acl_rule`, `is_allow`, `role`, `resource`) VALUES (NULL, '1', 'admin', 'api');
