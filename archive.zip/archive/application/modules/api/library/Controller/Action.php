<?php
class Api_Controller_Action extends Zend_Controller_Action
{

    protected $_result = array(
        'result' => true, 'access' => false,
        'body' => array(), 'redirect' => '', 'message' => '',
        'sig' => '', 'ts' => ''
    );

    /**
     * @var array
     */
    protected $_service = array();

    /**
     * @var Api_Service
     */
    protected $_apiService;

    public function  preDispatch()
    {
        parent::preDispatch();

        $this->validateRequest();

    }

    public function  postDispatch()
    {
        if( $this->_result['result'] ){
            $this->_result['access'] = true;
        }
        $this->_apiService->refreshTs();
        $this->_result['ts'] = $this->_apiService->getTs();
        $this->_result['sig'] = $this->_apiService->getSignature( $this->_result );

        $this->_helper->json($this->_result);
    }


    private function validateRequest()
    {
        if( !$this->_request->isPost() ){
            $this->_result['message'] = 'POST request is required';
            $this->_result['result'] = false;

            return false;
        }



        // sprawadzamy podstawowe parametry
        if( !$this->hasParam('id_api_service') || !$this->hasParam('sig') || !$this->hasParam('ts') ){
            $this->_result['message'] = 'Param id_api_service, sig, ts are required';
            $this->_result['result'] = false;

            return false;
        }

        // pobieray serwis -> na razie na sztywno: ponieważ mamy tylko jeden
//        $this->_service = array(
//            'id_service' => Setting::getSetting('api.id_service'),
//            'api_key' => Setting::getSetting('api.key'),
//        );
        $this->_service = ApiService::findRecord($this->getParam('id_api_service'));
        
        if( !$this->_service || !strlen($this->_service['key'])){
            $this->_result['message'] = 'Unknown Service ('.$this->getParam('id_api_service').')';
            $this->_result['result'] = false;

            return false;
        }

        // sprawdzaony autoryzację przychodzących danych
        $configApi = array(
            'id_api_service' => $this->_service['id_api_service'],
            'key' => $this->_service['key'],
            'ts' => $this->getParam('ts'),
        );

        $this->_apiService = new Api_Service($configApi);
        if( $this->getParam('sig') != $this->_apiService->getSignature() ){
            $this->_result['message'] = 'Signature not match';
            $this->_result['result'] = false;

            return false;
        }


        return true;
    }

}
