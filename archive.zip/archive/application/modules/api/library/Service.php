<?php
class Api_Service
{

    /**
     * ID serwisu/konta aplikacji
     * @var int
     */
    protected $_idApiService;

    /**
     * Adres URL wysłania zapytania
     * @var string
     */
    protected $_url;

    /**
     * Prywatny klucz aplikacji do autoryzacji zapytania/odpowiedzi
     * @var string
     */
    protected $_key;

    /**
     * Losowa zmianna, do autoryzacji zapytania i odpowiedzi
     * @var string
     */
    protected $_ts;

    /**
     *
     * @var array
     */
    protected $_config;

    /**
     * Paremetry które zostaną wysłane w zapytaniu
     * @var array
     */
    protected $params = array();

    /**
     * Default options for curl.
     */
    public static $CURL_OPTS = array(
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
    );


    /**
     * @var Zend_Http_Client
     */
    private $client = null;


    /**
     * @param $config
     */
    public function  __construct( $config )
    {        
        $this->setIdApiService($config['id_api_service']);
        $this->setKey($config['key']);

        if(isset($config['ts'])){
            $this->setTs($config['ts']);
        }else{
            $this->refreshTs();
        }


        $this->_config = $config;
    }


    /**
     * @param $name
     * @param string $value
     * @return $this
     */
    public function addParam( $name, $value='')
    {
        $this->params[$name] = $value;

        return $this;
    }

    /**
     * @param $params
     * @return $this
     */
    public function addParams($params)
    {
        foreach($params as $k => $v){
            $this->addParam($k, $v);
        }

        return $this;
    }

    /**
     * @return mixed|array
     * @throws Exception
     * @throws Zend_Http_Client_Exception
     * @throws Zend_Json_Exception
     */
    public function makeRequest()
    {
        if( !$this->client ){
            $this->client = new Zend_Http_Client();
            $this->client->setConfig(self::$CURL_OPTS);
            $this->client->setMethod(Zend_Http_Client::POST);
        }
        $this->client->setUri($this->getUrl());
        $this->client->setParameterPost( $this->getParams() );
        

        $this->client->setParameterPost(array(
            'sig' => $this->getSignature(),
            'ts' => $this->getTs(),
            'id_api_service' => $this->getIdApiService(),
        ));

        $response = $this->client->request();

//        echo $response->getBody();
//        exit();

        if ($response->getStatus() != 200) { throw new Exception($response->getMessage()); }
        $result = Zend_Json::decode($response->getBody(), true);

//        var_dump($result);
//        exit();

        $this->setTs($result['ts']);

        if($result['sig'] != $this->getSignature()){
            $error['result'] = false;
            $error['message'] = $result['message'];
            return $error;
            //return false;
        }

        return $result['body'];
    }


    /**
     * @return array
     */
    public function getParams()
    {
        return $this->params;
    }

    /**
     * @return string
     */
    public function getSignature()
    {
        return md5($this->getTs().$this->getKey().$this->getIdApiService());
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return $this->_url;
    }


    /**
     * @param $url
     * @return $this
     */
    public function setUrl( $url )
    {
        $this->_url = $url;

        return $this;
    }

    /**
     * @return int
     */
    public function getIdApiService()
    {
        return $this->_idApiService;
    }


    /**
     * @param $id_api_service
     * @return $this
     */
    public function setIdApiService( $id_api_service )
    {
        $this->_idApiService = $id_api_service;

        return $this;
    }

    /**
     * @return string
     */
    public function getKey()
    {
        return $this->_key;
    }

    /**
     * @param $key
     * @return $this
     */
    public function setKey( $key )
    {
        $this->_key = $key;

        return $this;
    }

    /**
     * @return $this
     */
    public function refreshTs()
    {
        return $this->setTs(md5(time().time()));
    }

    /**
     * @return string
     */
    public function getTs()
    {
        return $this->_ts;
    }

    /**
     * @param $ts
     * @return $this
     */
    public function setTs($ts)
    {
        $this->_ts = $ts;

        return $this;
    }
}
