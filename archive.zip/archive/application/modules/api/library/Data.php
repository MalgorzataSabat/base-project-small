<?php
class Api_Data{


    /**
     * @var array
     */
    protected $_data = array();

    /**
     * @var null
     */
    protected $_isValid = null;

    protected $_error = null;

    protected $_errors = null;

    protected $_errorCode = null;


    public function __construct($options = array())
    {
        if(isset($options['data'])){
            $this->setData($options['data']);
        }

    }


    /**
     * @return array
     */
    public function getData()
    {
        return $this->_data;
    }

    /**
     * @param $data
     * @return mixed
     */
    public function setData($data)
    {
        $this->_isValid = null;
        $this->_data = $data;

        return $data;
    }


    public function getErrorMessage()
    {
        return $this->_errors;
    }

    public function getErrorCode()
    {
        return $this->_errorCode;
    }


}