<?php


class Api_Extractor extends Base_Extractor
{

    protected $_tables = array('api_service');

    protected $_data = array('api_service');

    protected $_module = 'api';

    protected $_dumpResource = array('api');

    protected $_dumpRule = array('api');

    protected $_dumpLabel = array('api');

    protected $_dumpChangelog = array('api');

    protected $_dumpSettings = array('api');


}