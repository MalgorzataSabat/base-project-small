<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Zend
 * @package    Zend_View
 * @subpackage Helper
 * @copyright  Copyright (c) 2005-2011 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id: FormFile.php 23775 2011-03-01 17:25:24Z ralph $
 */


/**
 * Abstract class for extension
 */
require_once 'Zend/View/Helper/FormElement.php';


/**
 * Helper to generate a "file" element
 *
 * @category   Zend
 * @package    Zend_View
 * @subpackage Helper
 * @copyright  Copyright (c) 2005-2011 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Auth_View_Helper_FormRules extends Zend_View_Helper_FormElement
{
    /**
     * Generates a 'file' element.
     *
     * @access public
     *
     * @param string|array $name If a string, the element name.  If an
     * array, all other parameters are ignored, and the array elements
     * are extracted in place of added parameters.
     *
     * @param array $attribs Attributes for the element tag.
     *
     * @return string The element XHTML.
     */
    public function formRules($name, $value, $attribs = null)
    {
        $resources = $attribs['resources'];
        $roles = $attribs['roles'];
        $rules = $attribs['rules'];

        unset($attribs['resources']);
        unset($attribs['roles']);
        unset($attribs['rules']);

        /** @var $view Zend_View */
        $view = clone Base_Layout::getView();
        $xhtml = '';

        $view->el_resources = $resources;
        $view->el_roles = $roles;
        $view->el_rules = $rules;
        $view->el_name = $name;
        $view->acl = Base_Acl::_();

        $view->el_rules_options = array(
            '' => '',
            '0' => 'nie',
            '1' => 'tak',
        );

        $xhtml.= $view->render('acl/_auth_form_rules.phtml');


        return $xhtml;
    }
}
