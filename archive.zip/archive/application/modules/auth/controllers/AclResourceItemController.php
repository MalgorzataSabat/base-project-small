<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-06-23
 * Time: 09:04
 */

class Auth_AclResourceItemController extends Base_Controller_Action
{
    /**
     * @var $_model AclResourceItem
     */
    private $_model = null;

    protected $_route_return = 'auth_acl_resource_item_index';

    public function indexAction()
    {
        $this->_resourceItemFilter = new Auth_Form_Filter_AclResourceItem();
        $data = $this->_resourceItemFilter->getValues(true);

        $resourceItemList = AclResourceItem::getQuery($data);

        $this->view->massActionOptions = array(
            'resource' => array(
                'url' => Base::url('auth_acl-resource-item-mass_resource'),
                'name' => $this->view->translate('mass-options_acl-resource')
            ),
            'delete' => array(
                'url' => Base::url('auth_acl-resource-item-mass_delete'),
                'name' => $this->view->translate('mass-options_delete')
            )
        );


        $this->view->aclResourceItemList = $this->_helper->paging($resourceItemList, array('limit' => 50));
        $this->view->formFilter = $this->_resourceItemFilter;
    }

    public function newAction()
    {
        $this->_model = new AclResourceItem();

        $this->_formAclResourceItem();

        $this->view->placeholder('page-title')->set($this->view->translate('page-title_auth_acl_resource_item_new'));
    }

    public function editAction()
    {
        $this->_model = AclResourceItem::findRecord($this->getParam('id_acl_resource_item'));
        $this->forward403Unless($this->_model);

        $this->_formAclResourceItem();

        $this->view->placeholder('page-title')->set($this->view->translate('page-title_auth_acl_resource_item_edit'));
    }

    private function _formAclResourceItem()
    {
        $form = new Auth_Form_AclResourceItem(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                $this->_model->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit($this->_getReturnParams(), $this->_route_return);
                }
            }
        }

        $this->view->form = $form;
    }


    public function deleteAction()
    {
        $this->_model = AclResourceItem::findRecord($this->getParam('id_acl_resource_item'));
        $this->forward403Unless($this->_model);

        $this->_model->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl_resource_item_index');
        }
    }
} 