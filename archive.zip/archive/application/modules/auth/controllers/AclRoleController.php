<?php

/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-07-16
 * Time: 16:06
 */
class Auth_AclRoleController extends Base_Controller_Action
{
    /**
     * @var $_model AclResource
     */
    private $_model = null;

    protected $_route_return = 'auth_acl';

    public function newAction()
    {
        $this->_model = new AclRole();

        $this->_formRole();
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_auth_new-role') );
    }

    public function editAction()
    {
        $this->_model = AclRole::findRecord($this->getParam('id_acl_role'));
        $this->forward403Unless($this->_model);

        $this->_formRole();
        $this->view->placeholder('page-title')->set($this->view->translate('page-title_auth_acl_resource_edit'));
    }


    private function _formRole()
    {
        $form = new Auth_Form_AclRole(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                if(!Auth_Service_AclRole::hasRole()) {
                    $this->_model = Auth_Service_AclRole::setAclRole($this->_model);
                } else {
                    $this->_model->save();
                }


                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit(array(), $this->_route_return);
                }
            }
        }

        $this->view->form = $form;
    }




    public function deleteAction()
    {
        $this->_model = AclRole::findRecord($this->getParam('id_acl_role'));
        $this->forward403Unless($this->_model);

        $this->forward404If($this->_model->name == Base_Auth::MAIN_ROLE, 'Main role cannot be delete');

        if(!Auth_Service_AclRole::hasRole()) {
            $this->_model = Auth_Service_AclRole::setAclRole($this->_model);
        }
        $userList = Doctrine_Query::create()
            ->select("u.*, CONCAT(',',u.role,',') as _roles")
            ->from('User u')
            ->having('_roles LIKE ?', '%,'.$this->_model->getName().',%' )
            ->execute();

        /** @var $user User */
        foreach($userList as $user){
            $roles = explode(',',$user->getRole());
            if(false !== ($key = array_search($this->_model->getName(), $roles))){
                unset($roles[$key]);
            }

            $user->setRole(join(',', $roles));
            $user->save();
        }

        Doctrine_Query::create()
            ->delete('AclRule')
            ->where('role = ?', $this->_model->name)
            ->execute();

        $this->_model->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl');
    }
}