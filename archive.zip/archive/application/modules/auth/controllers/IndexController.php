<?php

class Auth_IndexController extends Base_Controller_Action
{
    /**
     * @var Auth_Form_Login 
     */
    private $_authFormLogin;
    
    private $_redirectUrl;

    /**
     * @var User
     */
    private $_user;

    /**
     * @var UserConfirmRequest
     */
    private $_userConfirmRequest;

    /**
     * @var Auth_Form_ChangePass;
     */
    private $_formChangePass;
    /**
     * @var Auth_Form_RecoverPassword
     */
    private $_formRecoverPassword;


    public function preDispatch()
    {
        parent::preDispatch();
//
//        if(strstr($this->_request->getPathInfo(), 'admin')){
            Base_Layout::setLayoutByType('auth');
            $this->_helper->viewRenderer('index-admin');
//        }

    }

    public function indexAction()
    {
        $redirect = $this->_getParam('redirect');
        $loginUrl = '/login';

        $this->authAutoLogin();

        $this->_authFormLogin = new Auth_Form_Login(array(
            'tableName' => 'User',
            'loginColumn' => 'email',
            'passwordColumn' => 'password',
            'authAdapter' => 'Base_Auth_Adapter_Doctrine',
        ));


        if($this->_request->isPost())
        {
            if($this->_authFormLogin->isValid($this->getAllParams()))
            {
                $auth = Base_Auth::getInstance();
                $authFormValidator = $this->_authFormLogin->getElement('password')->getValidator($this->_authFormLogin->_formValidator);
                $authAdapter = $authFormValidator->adapter;

                $resultsObject = $authAdapter->getResultRowObject();
                $auth->getStorage()->write($resultsObject);

                Log::addLog(Log::TYPE_LOGIN, null, array(
                    'model' => 'User', 'id_user' => $resultsObject->id_user, 'id_object' => $resultsObject->id_user
                ));

                $session = Session::findRecord(session_id());
                $session->id_user = $resultsObject->id_user;
                $session->save();

                if(!empty($redirect) && $redirect != $loginUrl) {
                    $this->setRedirectUrl('/' . $redirect);
                } elseif(!empty($redirect) && $redirect == $loginUrl) {
                    $this->setRedirectUrl('/');
                } elseif($this->_request->getPathInfo() != $loginUrl) {
                    $this->setRedirectUrl($this->_request->getRequestUri());
                }
            }
        }
        
        $this->_redirectIfAuthenticated();
        $this->view->authFormLogin = $this->_authFormLogin;
	}

    public function recoverPasswordAction()
    {
        //Base_Layout::setLayoutByType('auth');
        $this->_helper->viewRenderer('recover-password');
        $this->_formRecoverPassword = new Auth_Form_RecoverPassword();

        if ( $this->_request->isPost() && $this->_formRecoverPassword->isValid($this->_request->getPost()) ) {
            $email = $this->_formRecoverPassword->getValue('email');
            $userEmail = UserEmail::findOneByEmail($email);
            $this->_user = $userEmail->User;
            $message = null;
            $result = null;

            // get userConfirmRequest
            $query = UserConfirmRequest::getQuery(
                array(
                    'type' => UserConfirmRequest::TYPE_RECOVER_PASSWORD,
                    'id_user' => $this->_user->getId(),
                    'channel' => get_class($this->_user),
                    'object_id' => $this->_user->getId()
                )
            );
            $this->_userConfirmRequest = $query->fetchOne();

            if ( !$this->_userConfirmRequest ) {
                $this->_userConfirmRequest = new UserConfirmRequest();
                $this->_userConfirmRequest->setType(UserConfirmRequest::TYPE_RECOVER_PASSWORD);
                $this->_userConfirmRequest->setHash(Base::getHash());
                $this->_userConfirmRequest->setChannel(get_class($this->_user));
                $this->_userConfirmRequest->setObjectId($this->_user->getId());
                $this->_userConfirmRequest->User = $this->_user;

                $this->_userConfirmRequest->save();

                $this->view->user = $this->_user;
                $this->view->userConfirmRequest = $this->_userConfirmRequest;

                $mail = new Base_Mail();
                $mail->setBodyTemplate('index/_mail_recovery_pass_new.phtml');
                $mail->setSubject( $this->view->translate( 'mail_auth_index_recover-password_new-link_subject' ) );
                $mail->clearRecipients();
                $mail->addTo( $this->_user->getMainEmail()->email, $this->_user->getUserName() );
                $mail->send();

                $message = 'Password link was sent to your email address';
                $result = 'success';

            } else {
                $this->_user = $this->_userConfirmRequest->User;
                $isActive = (bool) $this->_userConfirmRequest->is_active;

                if ( $isActive ) {
                    $this->_sendRecoverPasswordLink();
                    $message = sprintf($this->view->translate('Change password link was sent to your email address at %s'), $this->_userConfirmRequest->created_at);
                    $result = 'info';
                } else {
                    $this->_userConfirmRequest = new UserConfirmRequest();
                    $this->_userConfirmRequest->User = $this->_user;
                    $this->_userConfirmRequest->setHash(Base::getHash());
                    $this->_userConfirmRequest->setType(UserConfirmRequest::TYPE_RECOVER_PASSWORD);
                    $this->_userConfirmRequest->setChannel(get_class($this->_user));
                    $this->_userConfirmRequest->setObjectId($this->_user->getId());
                    $this->_userConfirmRequest->save();

                    $this->_sendRecoverPasswordLink(true);

                    $message = 'New change password link was sent to your email address';
                    $result = 'success';

                }
            }

            $this->_flash()->$result->addMessage($message);
            $this->_redirector()->gotoRouteAndExit();
        }

        $this->view->form = $this->_formRecoverPassword;
    }

    private function _sendRecoverPasswordLink($new = null)
    {
        $this->view->user = $this->_user;
        $this->view->userConfirmRequest = $this->_userConfirmRequest;


        $mail = new Base_Mail();
        if (null === $new) {
            $mail->setBodyTemplate('index/_mail_recovery_pass_link.phtml');
            $mail->setSubject( $this->view->translate( 'mail_auth_index_recover-password-link_subject' ) );
        } else {
            $mail->setBodyTemplate('index/_mail_recovery_pass_new.phtml');
            $mail->setSubject( $this->view->translate( 'mail_auth_index_recover-password_new-link_subject' ) );
        }
        $mail->clearRecipients();
        $mail->addTo( $this->_user->getMainEmail()->email, $this->_user->getUserName() );
        $mail->send();
    }

    public function changePassAction()
    {
        //Base_Layout::setLayoutByType('auth');
        $this->_helper->viewRenderer('change-pass');
        $this->_userConfirmRequest = UserConfirmRequest::findOneByHash($this->_getParam('hash'));
        $this->_user = $this->_userConfirmRequest->User;
        $message = null;
        $result = null;

        if ( !$this->_userConfirmRequest ) {
            $message = 'message_auth_index_confirm-change_pass';
            $result = 'error';
        } else {
            $isActive = (bool) $this->_userConfirmRequest->is_active;
            if ( !$isActive ) {
                $message = 'message_auth_index_confirm-change_pass_info-link-expired';
                $result = 'info';
            } else {
                // show form to change pass
                $this->_formChangePass = new Auth_Form_ChangePass(array('model'=>$this->_user));
                if ( $this->_request->isPost() && $this->_formChangePass->isValid($this->_request->getPost()) ) {
                    $this->_userConfirmRequest->setUsedAt(date('YmdHis'));
                    $this->_userConfirmRequest->save();
                    $this->_user->save();

                    $message = 'message_auth_index_confirm-activate_success';
                    $result = 'success';
                }
            }
        }

        if($message){
            $this->_flash()->$result->addMessage($message);
            $this->_redirector()->gotoRouteAndExit(array(), 'login');
        }

        $this->view->form = $this->_formChangePass;

    }

    
    public function logoutAction()
    {
        $redirect = $this->_getParam('redirect', '/');

        $session = Session::findRecord(session_id());
        $session->id_user = null;
        $session->save();

        Log::addLog(Log::TYPE_LOGOUT, null, array(
            'model' => 'User', 'id_user' => Base_Auth::getUserId(), 'id_object' => Base_Auth::getUserId()
        ));

        Zend_Auth::getInstance()->clearIdentity();
        session_destroy();
        $this->_redirector()->gotoUrlAndExit($redirect);
        exit();
    }
    
    
    private function _redirectIfAuthenticated()
    {
        if(Base_Auth::isIdentity()) {
            if(empty($this->_redirectUrl)){
                $this->setRedirectUrl('/');
            }
            
           $this->_redirector()->gotoUrlAndExit($this->getRedirectUrl());
        }
    }
    
    /**
     * @param string $url
     * @return string
     */
    public function setRedirectUrl($url)
    {
        return $this->_redirectUrl = '/'.ltrim($url, '/');
    }

    /**
     * @return string
     */
    public function getRedirectUrl()
    {
        return $this->_redirectUrl;
    }

    private function authAutoLogin()
    {
        $redirect = $this->_getParam('redirect');
        $loginUrl = '/login';
        if($this->hasParam('token'))
        {

            $user = User::getQuery()
                ->addWhere('o.token = ?', $this->getParam('token'))
                ->fetchOne(array(), Doctrine::HYDRATE_RECORD);

            if($user)
            {
                Base_Auth::loginUser($user);

                if(!empty($redirect) && $redirect != $loginUrl) {
                    $this->setRedirectUrl('/' . $redirect);
                } elseif(!empty($redirect) && $redirect == $loginUrl) {
                    $this->setRedirectUrl('/');
                } elseif($this->_request->getPathInfo() != $loginUrl) {
                    $this->setRedirectUrl($this->_request->getRequestUri());
                }



            }

            $this->_redirectIfAuthenticated();
        }
    }
    
}
