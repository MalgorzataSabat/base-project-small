<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-06-22
 * Time: 14:21
 */

class Auth_AclResourceController extends Base_Controller_Action
{
    /**
     * @var $_model AclResource
     */
    private $_model = null;

    public function newAction()
    {
        $this->_model = new AclResource();

        $this->_formAclResource();

        $this->view->placeholder('page-title')->set($this->view->translate('page-title_auth_acl_resource_new'));
    }

    public function editAction()
    {
        $this->_model = AclResource::findRecord($this->getParam('id_acl_resource'));
        $this->forward403Unless($this->_model);

        $this->_formAclResource();

        $this->view->placeholder('page-title')->set($this->view->translate('page-title_auth_acl_resource_edit'));
    }

    private function _formAclResource()
    {
        $form = new Auth_Form_AclResource(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                $this->_model->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit($this->_getReturnParams(), $this->_route_return);
                }
            }
        }

        $this->view->form = $form;
    }


    public function deleteAction()
    {
        $this->_model = AclResource::findRecord($this->getParam('id_acl_resource'));
        $this->forward403Unless($this->_model);

        $this->_model->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl_resource_item_index');
        }
    }
}