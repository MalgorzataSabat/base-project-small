<?php

class Auth_AclController extends Base_Controller_Action
{
    /**
     * @var AclResource
     */
    private $_aclResourceModel = null;

    /**
     * @var Auth_Form_AclRule
     */
    private $_formRules;

    /**
     * @var array
     */
    private $_resourceList;

    /**
     * @var array
     */
    private $_roleList;

    /**
     * @var array
     */
    private $_aclRolesWithoutResourceList;

    /**
     * @var array
     */
    private $_rulesList;

    /**
     * @var
     */
    private $_rulesRoleList;

    public function indexAction()
    {
        $queryOptionsAclRole = array(
            'channel' => $this->getParam('channel', null),
        );
        $this->_roleList = AclRole::getQuery($queryOptionsAclRole)->execute();
        $this->_aclRolesWithoutResourceList = AclRole::getGroupRole($this->_roleList);
        $this->_rulesList = AclRule::getList();
        $this->_resourceList = Doctrine_Query::create()
            ->from('AclResource o INDEXBY o.id_acl_resource')
            ->leftJoin('o.Resources o2 INDEXBY o2.id_acl_resource WITH o2.is_hidden = 0')
            ->leftJoin('o2.Resources o3 INDEXBY o3.id_acl_resource WITH o3.is_hidden = 0')
            ->where('o.id_parent IS NULL AND o.is_hidden = 0')
            ->execute(array(), Doctrine::HYDRATE_ARRAY);

        $this->_rulesRoleList = array();
        foreach($this->_roleList as $role){
            $this->_rulesRoleList[$role['name_role']] = array();
        }

        foreach($this->_rulesList as $rule){
            $this->_rulesRoleList[$rule['role']][$rule['resource']] = (int)$rule['is_allow'];
        }

        $countResourceItemWithoutResource = AclResourceItem::getQuery()->addWhere('o.id_acl_resource IS NULL')->count();

        $this->view->roleList = $this->_roleList;
        $this->view->resourceList = $this->_resourceList;
        $this->view->rulesRoleList = $this->_rulesRoleList;

        $this->view->aclRolesWithoutResourceList = $this->_aclRolesWithoutResourceList;
        $this->view->countResourceItemWithoutResource = $countResourceItemWithoutResource;
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_auth_rule') );
    }


    public function saveRuleAction()
    {
        $role = $this->getParam('role');
        $resource = $this->getParam('resource');
        $access = $this->getParam('access');
        $this->forward404Unless($role);
        $this->forward404Unless($resource);

        if(!Auth_Service_AclRule::hasRule()) {
            $aclRule = Auth_Service_AclRule::setAclRule(array(
                'role' => $role,
                'resource' => $resource,
            ));
        } else {
            $aclRule = AclRule::getRecord(array(
                'role' => $role,
                'resource' => $resource,
                'hydrate' => Doctrine::HYDRATE_RECORD
            ));
        }

        if($access === ''){
            if($aclRule) {
                $aclRule->delete();
            }
        }else{
            if(!$aclRule){
                $aclRule = new AclRule();
                $aclRule->role = $role;
                $aclRule->resource = $resource;
            }
            $aclRule->is_allow = $access === 'true' ? true : false;
            $aclRule->save();
        }

        Base_Cache::clean();
        $roleRules = $this->_getRoleRulesList();

        $this->_helper->json($roleRules);
    }



    public function newResourceAction()
    {
        $this->_aclResourceModel = new AclResource();

        $form = new Auth_Form_AclResource(array('model' => $this->_aclResourceModel));
        if($this->_request->isPost() && $form->isValid($this->_request->getPost())){
            $this->_aclResourceModel->save();
            $this->_flash()->success->addMessage('label_cms_save_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl');
        }

        $this->view->placeholder('page-title')->set($this->view->translate('h1-cms_user-acl-resource_new-form'));
        $this->_helper->viewRenderer('admin/form', null, array('noController' => true));
        $this->view->form = $form;
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_auth_new-resource') );
    }


    public function deleteResourceAction()
    {
        $this->_aclResourceModel = AclResource::findRecord($this->getParam('id_acl_resource'));
        $this->forward404Unless($this->_aclResourceModel);

        $this->_aclResourceModel->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl');
    }


    public function loadResourceAction()
    {
        $acl = Base_Acl::getInstance();

        $resourceList = $acl->getResources();
        $resourceList = array_combine($resourceList, $resourceList);
        $resourceItemList = $acl->getResourceItems();
        $resourceItemFromModules = $this->_getResourcesFromModules();

        $resourceItemToDelete = array_intersect($resourceList, array_keys($resourceItemList));

        foreach($resourceItemToDelete as $resourceItem){
            Doctrine_Query::create()
                ->delete('AclResourceItem o')
                ->where('o.name = ?', $resourceItem)
                ->execute();
        }

        foreach($resourceItemFromModules as $item){
            if(!array_key_exists($item, $resourceList) && !array_key_exists($item, $resourceItemList)){
                $resourceItem = new AclResourceItem();
                $resourceItem->name = $item;
                $resourceItem->save();
            }
        }

        $this->_flash()->success->addMessage('flash-cms_acl-resource_load');
        $this->_redirector()->gotoRouteAndExit(array(), 'auth_acl');

    }


    private function _getResourcesFromModules()
    {
        $frontController = Zend_Controller_Front::getInstance();
        $modules = $frontController->getControllerDirectory();
        $result = array();

        foreach($modules as $module => $path){
//            $result[] = $module;

            if (is_dir($path)) foreach (scandir($path) as $file) {
                if ($file{0} !== '.' && strpos($file, '.php') === strlen($file) - 4) {
                    $controller = Base::camelToDash(substr($file, 0, -14));
//                    $result[] = $module.'_'.$controller;

                    require_once $path . '/' . $file;

                    $class_name = ($module === 'default' ? '' : Base::dashToCamel($module) . '_') . substr($file, 0, -4);
                    foreach (get_class_methods($class_name) as $method) {
                        if (substr($method,-6) === 'Action') {
                            $action = Base::camelToDash(substr($method, 0, -6));
                            $result[] = $module.'_'.$controller.'_'.$action;
                        }
                    }
                }
            }
        }

        return $result;
    }


    private function _getRoleRulesList()
    {
        $result = array();
        $_resourceList = AclResource::getListName();
        $acl = Base_Acl::_();
        $acl->loadRolesResourcesRules();
        $this->_roleList = AclRole::getList();

        foreach($this->_roleList as $role){
            foreach($_resourceList as $id_resource => $resource_name){

                $result[$role['name']][$id_resource] = $acl->hasAccess($resource_name, null, $role['name']);
            }
        }

        return $result;
    }


}
