<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 11.03.2017
 * Time: 12:17
 */
class Auth_AclResourceItemMassController extends Base_Controller_Action
{

    private $_items = array();

    public function deleteAction()
    {
        if ( $this->_request->isPost() ) {
            $ids = (array) explode(',',$this->getParam('massItems'));
            $all = (bool)$this->getParam('massItemAllPage');
            $this->_items = $this->_getItems($ids, $all);

            if(count($ids)){
                Doctrine_Query::create()->delete('AclResourceItem')
                    ->whereIn('id_acl_resource_item', $this->_items)
                    ->execute();
            }

            $this->_helper->viewRenderer('delete-ajax-result');
        } else {
            $this->forward403('Post request method is required');
        }
    }

    public function resourceAction()
    {
        $this->_form = new Auth_Form_AclResourceItemMass(array('data' => array(
            'ids' => $this->getParam('massItems'),
            'all' => $this->getParam('massItemAllPage'),
        )));

        if ( $this->_request->isPost() && $this->hasParam($this->_form->getElementsBelongTo())
            && $this->_form->isValid( $this->_request->getPost()))
        {
            $ids = (array) explode(',',$this->_form->getValue('ids'));
            $all = (bool)$this->_form->getValue('all');
            $this->_items = $this->_getItems($ids, $all);

            if(count($this->_items)){
                Doctrine_Query::create()->update('AclResourceItem')
                    ->set('id_acl_resource', $this->_form->getValue('id_acl_resource'))
                    ->whereIn('id_acl_resource_item', $this->_items)
                    ->execute();
            }

            $this->_helper->viewRenderer('form-ajax-result');
        }

        $this->view->form = $this->_form;
        $this->view->countItems = $this->getParam('countItems');
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_acl-resource-item-mass') );
    }

    private function _getItems($ids, $all)
    {
        if($all){
            $filter = new Auth_Form_Filter_AclResourceItem();
            $dataQuery = $filter->getValuesQuery(true);
            $dataQuery['coll_key'] = 'id_acl_resource_item';
            $query = AclResourceItem::getQuery($dataQuery);
            $query->select('id_acl_resource_item');

            $result = $query->execute();

            $ids = array_keys($result);
        }

        if(empty($ids)){
            $this->forward403('Mass Action not selected items');
        }


        $this->_items = $ids;

        return $this->_items;
    }
}