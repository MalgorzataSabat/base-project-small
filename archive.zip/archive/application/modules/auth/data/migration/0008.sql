ALTER TABLE `acl_role` CHANGE `channel` `object` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Objekt roli // do czego jest ta rola przypisana, np: do projektu';
