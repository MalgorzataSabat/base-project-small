ALTER TABLE `acl_role` ADD `id_service` INT(11) UNSIGNED NULL COMMENT 'Serwis' AFTER `id_acl_role`, ADD INDEX (`id_service`);
ALTER TABLE `acl_rule` ADD `id_service` INT(11) UNSIGNED NULL COMMENT 'Serwis' AFTER `id_acl_rule`, ADD INDEX (`id_service`);

ALTER TABLE `acl_role` ADD CONSTRAINT `acl_role_service` FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE CASCADE ON UPDATE RESTRICT;
ALTER TABLE `acl_rule` ADD CONSTRAINT `acl_rule_service` FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE CASCADE ON UPDATE RESTRICT;