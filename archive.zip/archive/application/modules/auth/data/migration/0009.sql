ALTER TABLE `acl_rule` CHANGE `is_allow` `is_allow` TINYINT(1) NOT NULL COMMENT 'Określenie dostępu: 0 – brak dostępu; 1 – nadanie dostępu; Dla typu 2: 0 -brak widoczności; 1 - tylko podgląd; 2 - edycja';
ALTER TABLE `acl_rule` CHANGE `is_allow` `is_allow` TINYINT(1) NOT NULL COMMENT 'Określenie dostępu: 0 – brak dostępu; 1 – nadanie dostępu';
ALTER TABLE `acl_rule` ADD `privileges` VARCHAR(255) NOT NULL AFTER `resource`;
ALTER TABLE `acl_rule` CHANGE `privileges` `privileges` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Przywileje';
