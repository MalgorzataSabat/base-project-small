ALTER TABLE `acl_resource` ADD `assert` VARCHAR(255) NOT NULL COMMENT 'Klasa obsługująca dostep' , ADD `resource_class` VARCHAR(255) NOT NULL COMMENT 'Klasa zasobu' ;
