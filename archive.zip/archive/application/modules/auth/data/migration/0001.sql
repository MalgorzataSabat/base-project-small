ALTER TABLE `acl_resource` ADD `module` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT 'Moduł' AFTER `text`;

