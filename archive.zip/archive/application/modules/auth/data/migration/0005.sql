ALTER TABLE `acl_role` ADD `name_role` VARCHAR(255) NOT NULL COMMENT 'Nazwa systemowa roli' AFTER `name`;
ALTER TABLE `acl_role` CHANGE `name` `name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Nazwa roli';

ALTER TABLE acl_rule DROP FOREIGN KEY acl_rule_service;
ALTER TABLE acl_rule DROP FOREIGN KEY acl_rule_ibfk_1;

ALTER TABLE `acl_rule` ADD CONSTRAINT `acl_rule_service` FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE CASCADE ON UPDATE RESTRICT;
ALTER TABLE `acl_role` ADD INDEX(`name_role`);
ALTER TABLE `acl_rule` ADD CONSTRAINT `acl_rule_role` FOREIGN KEY (`role`) REFERENCES `acl_role`(`name_role`) ON DELETE CASCADE ON UPDATE RESTRICT;

