TRUNCATE `acl_rule`;
TRUNCATE `acl_role`;


