ALTER TABLE `acl_resource` ADD `is_hidden` BOOLEAN NOT NULL COMMENT 'Czy zasób jest ukryty na liście do zarządzania' ;
update `acl_resource` SET is_hidden = 1 WHERE `name` = '_superadmin';
update `acl_resource` SET is_hidden = 1 WHERE `name` = 'outlook';
update `acl_resource` SET is_hidden = 1 WHERE `name` = 'module';
