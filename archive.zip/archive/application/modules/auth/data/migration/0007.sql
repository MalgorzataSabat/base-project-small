ALTER TABLE `acl_role` ADD `channel` VARCHAR(255) NULL DEFAULT NULL AFTER `id_parent`, ADD INDEX (`channel`);


