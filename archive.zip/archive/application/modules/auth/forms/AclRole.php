<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Robert Rogiński <robert.roginski@gmail.com>
 * Date: 01.07.13
 * Time: 19:26
 * To change this template use File | Settings | File Templates.
 */

class Auth_Form_AclRole extends Base_Form_Horizontal{

    /**
     * @var AclRole
     */
    protected $_model;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
            'allowEmpty' => false,
            'dimension' => 12,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('AlreadyTaken', true, array(
                    'model' => 'AclRole',
                    'column' => 'name',
                    'params' => array(
                        array('id_acl_role', '!=', $this->_model->getId())
                    )
                )),
            ),
            'value' => $this->_model->getName(),
        ));

        $fields['order'] = $this->createElement('text', 'order', array(
            'label' => $this->_tlabel.'order',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model['order'],
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        //$this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        //$this->setAttrib('data-overbox-replace', true);
    }
}
