<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Robert Rogi�ski <robert.roginski@gmail.com>
 * Date: 01.07.13
 * Time: 19:26
 * To change this template use File | Settings | File Templates.
 */

class Auth_Form_AclResource extends Base_Form_Horizontal
{
    /**
     * @var AclResource
     */
    protected $_model;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['id_acl_resource'] = $this->createElement('hidden', 'id_acl_resource', array(
            'value' => $this->_model->id_acl_resource,
        ));

        $resourceParentOptions = array('' => '') + AclResource::getParentList();
        $fields['id_parent'] = $this->createElement('select', 'id_parent', array(
            'label' => $this->_tlabel . 'id_parent',
            'required' => false,
            'allowEmpty' => true,
            'multiOptions' => $resourceParentOptions,
            'placeholder' => $this->getView()->translate('label_auth_acl_resource_form_placeholder_id_parent'),
            'validators' => array(
                array('InArray', true, array(array_keys($resourceParentOptions)))
            ),
            'select2' => array(
                'allowClear' => true,
                'placeholder' => $this->getView()->translate('label_auth_acl_resource_form_placeholder_id_parent'),
            ),
            'value' => $this->_model->getIdParent(),
            'size' => 9,
            'label-size' => 3,
        ));

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel . 'name',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('Regex', true, array('pattern' => '/^[(a-zA-Z0-9)_-]+$/'))
            ),
            'size' => 9,
            'label-size' => 3,
            'value' => $this->_model->getName(),
        ));

        $fields['text'] = $this->createElement('text', 'text', array(
            'label' => $this->_tlabel . 'text',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'size' => 9,
            'label-size' => 3,
            'value' => $this->_model->getText(),
        ));

        $fields['desc'] = $this->createElement('textarea', 'desc', array(
            'label' => $this->_tlabel . 'desc',
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'size' => 9,
            'label-size' => 3,
            'value' => $this->_model->getDesc(),
            'rows' => 4
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

    public function isValid($data)
    {
        parent::populate($data);

        $nameAlreadyTakenParams = array();
        if ($this->getValue('id_acl_resource')) {
            $nameAlreadyTakenParams = array(
                array('id_acl_resource', '!=', (int)$this->getValue('id_acl_resource'))
            );
        }

        $this->getElement('name')->addValidator('AlreadyTaken', true, array(
            'model' => 'AclResource',
            'column' => 'name',
            'params' => $nameAlreadyTakenParams,
        ));

        return parent::isValid($data);
    }

    public function postIsValid($data = array())
    {
        parent::postIsValid($data);

        if(strlen($this->_model->id_parent) == 0 || !is_numeric($this->_model->id_parent)){
            $this->_model->id_parent = null;
        }

        return true;
    }
}
