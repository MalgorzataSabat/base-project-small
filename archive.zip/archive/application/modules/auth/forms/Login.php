<?php

class Auth_Form_Login extends Base_Form_Vertical
{

    /**
     * Number of seconds to expire the namespace.
     *
     * @var string
     */
    protected $_loginLifetime = null;

    /**
     * The validator class name.
     *
     * @var string
     */
    public $_formValidator = 'Auth_Validate_Login';


    /**
     * @var Zend_Session_Namespace
     */
    protected $_sessionCaptcha = null;


    /**
     * Constructor.
     *
     * @param array $params Params to instantiate the form validator
     * @param string $formName Form name
     * @param string $loginLifetime Number of seconds to expire the namespace
     * @return void
     */
    public function  __construct( array $params )
    {
        parent::__construct();

        $save = $this->createElement('button', 'submit', array(
            'label' => 'form_auth-login_submit',
            'type' => 'submit',
            'ignore' => true,
            'value'=> 'form_auth-login_submit',
            'class' => 'btn',
            'order' => 99,
            'size' => 12
        ))->removeDecorator('Label');

        $keys = array( 'tableName', 'loginColumn', 'passwordColumn');
        $diff = array_diff_key(array_flip($keys), $params);

        if (count($diff) != 0) {
            throw new Engine_Form_Exception('constructor array must have keys for ' . implode(' ', array_keys($diff)));
        }

        $fields['login'] = $this->createElement('text', 'login', array(
            'label' => 'form_auth-login_login',
            'required' => true,
            'allowEmpty' => false,
            'filters'    => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'input-group' => array(
                'class' => 'input-group-sm',
                'post' => array(
                    'type' => 'icon',
                    'class' => 'fa-user fa-fw',
                )
            )
        ));

        $fields['password'] = $this->createElement('password', 'password', array(
            'label' => 'form_auth-login_password',
            'required' => true,
            'allowEmpty' => false,
            'filters'    => array('StringTrim'),
            'validators'    =>  array(
                array(
                    'validator'             => 'StringLength',
                    'options'               => array('min' =>  3),
                    'breakChainOnFailure'   => true
                ),
                array(new $this->_formValidator($params))
            ),
            'input-group' => array(
                'class' => 'input-group-sm',
                'post' => array(
                    'type' => 'icon',
                    'class' => 'fa-lock fa-fw',
                )
            )
        ));

        $fields['recover'] = $this->createElement('html', 'recover', array(
            'label' => 'form_auth-login_recover',
            'size' => 12,
            'tag' => 'a',
            'html' => $this->getView()->translate('label_auth_index_recover-password').' &raquo;',
            'href' => Base::url('auth_index_recover-pass')
        ))->removeDecorator('Label');

        // Captcha
        if(Setting::getSetting('auth.form_captcha_on')){
            $this->_sessionCaptcha = new Zend_Session_Namespace($this->_belong_to.'_captcha');

            if(!$this->_sessionCaptcha->__isset('show')){
                $this->_sessionCaptcha->__set('show',false);
                $this->_sessionCaptcha->__set('count_error',0);
            }

            if($this->_sessionCaptcha->count_error > 0){
                $this->_sessionCaptcha->show = true;
            } else {
                $this->_sessionCaptcha->show = false;
            }

            if($this->_sessionCaptcha->show){
                $fields['captcha'] = $this->_createCaptchaElement();
            }
        }


        $this->addDisplayGroup($fields, 'main');

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $mainGroup = $this->getDisplayGroup('main');
        $mainGroup->removeDecorator('panel');
    }

    public function isValid($data)
    {
        if(Setting::getSetting('auth.form_captcha_on')) {
            $this->_sessionCaptcha->count_error += 1;
        }
        return parent::isValid($data);
    }

    protected function postIsValid($data)
    {
        parent::postIsValid($data);
        if(Setting::getSetting('auth.form_captcha_on')) {
            $this->_sessionCaptcha->count_error = 0;
        }
        return true;
    }

    /**
     * @return Zend_Form_Element
     * @throws Zend_Form_Exception
     */
    private function _createCaptchaElement()
    {
        $captchaElement = $this->createElement('captcha', 'captcha', array(
            'label' => 'form_auth-login_captcha',
            'size' => 9,
            'label-size' => 3,
            'order' => 98,
            'captcha' => array(
                'captcha' => 'Image',
                'font' => ROOT_PATH . '/public/assets/fonts/open-sans/OpenSans-Bold.ttf',
                'width' => 225,
                'height' => 75,
                'dotNoiseLevel' => 50,
                'lineNoiseLevel' => 5,
                'wordLen' => 6,
                'imgUrl' => 'http://' . DOMAIN . '/cached/captcha/',
                'imgDir' => ROOT_PATH . '/public/cached/captcha/',
            ),
            'class' => 'form-control captcha',
            'placeholder' => $this->getView()->translate('label_captcha_placeholder_text'),
            'offset' => 3,
        ));

        $captchaElement->removeDecorator('ViewHelper');
        $captchaElement->removeDecorator('Label');

        return $captchaElement;
    }
}
