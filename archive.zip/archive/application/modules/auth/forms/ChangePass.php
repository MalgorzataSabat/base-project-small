<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Marek Skotarek
 * Date: 07.07.2013
 * Time: 03:23
 * To change this template use File | Settings | File Templates.
 */

class Auth_Form_ChangePass extends Base_Form_Vertical {

    protected $_belong_to = "AuthFormChangePass";

    protected $_tlabel = "auth_form_change_pass_";

    public function init()
    {
        // set validators
        $vStringLength = new Zend_Validate_StringLength(array('min' => 6, 'max' => 20));
        $vIdentical = new Zend_Validate_Identical('password');

        $fields = array();

        $fields['password'] = $this->createElement('password', 'password', array(
            'label' => $this->_tlabel.'password',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array($vStringLength, true)
            ),
            'input-group' => array(
                'class' => 'input-group-sm',
                'post' => array(
                    'type' => 'icon',
                    'class' => 'fa-lock fa-fw',
                )
            )
        ));

        $fields['password_repeat'] = $this->createElement('password', 'password_repeat', array(
            'label' => $this->_tlabel.'password_repeat',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array($vStringLength, true),
                array($vIdentical, true),
            ),
            'input-group' => array(
                'class' => 'input-group-sm',
                'post' => array(
                    'type' => 'icon',
                    'class' => 'fa-lock fa-fw',
                )
            )
        ));

        $save = $this->createElement('button', 'submit', array(
            'label' => $this->_tlabel.'submit',
            'type' => 'submit',
            'ignore' => true,
            'class' => 'btn',
            'icon' => 'save'
        ))->removeDecorator('Label');

        $this->addDisplayGroup(
            $fields,
            'main'
        );

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $mainGroup = $this->getDisplayGroup('main');
        $mainGroup->removeDecorator('panel');
    }
}