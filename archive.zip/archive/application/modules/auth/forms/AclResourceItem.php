<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-06-23
 * Time: 09:46
 */

class Auth_Form_AclResourceItem extends Base_Form_Horizontal
{
    /**
     * @var AclResourceItem
     */
    protected $_model;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $resourceOptions = array('' => '') + AclResource::getListArray();
        $fields['id_acl_resource'] = $this->createElement( 'select', 'id_acl_resource', array(
            'label' => $this->_tlabel.'id_acl_resource',
            'required' => true,
            'allowEmpty' => false,
            'multiOptions' => $resourceOptions,
            'allowEmpty' => false,
            'validators' => array(
                array('NotEmpty', true),
                array('InArray', true, array(array_keys($resourceOptions)))
            ),
            'select2' => array(
                'placeholder' => $this->getView()->translate('label_auth_acl_resource_item_form_placeholder_id_acl_resource'),
            ),
            'value' => $this->_model->getIdAclResource(),
            'size' => 9,
            'label-size' => 3,
        ));

        $params = array();
        if(!$this->_model->isNew()){
            $params = array(
                array('id_acl_resource_item', '!=', $this->_model->getId())
            );
        }

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('AlreadyTaken', true, array(
                    'model' => 'AclResourceItem',
                    'column' => 'name',
                    'params' => $params
                )),
                array('Regex', true, array('pattern' => '/^[(a-zA-Z0-9)_-]+$/'))
            ),
            'size' => 9,
            'label-size' => 3,
            'value' => $this->_model->getName(),
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }
}
