<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-06-23
 * Time: 09:46
 */

class Auth_Form_AclResourceItemMass extends Base_Form_Horizontal
{
    protected $_data;

    /**
     * @param $data
     */
    protected function setData($data)
    {
        $this->_data = $data;
    }

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['ids'] = $this->createElement('hidden', 'ids', array('value' => $this->_data['ids']));
        $fields['ids']->removeDecorator('WrapElement')->removeDecorator('FieldSize');
        $fields['all'] = $this->createElement('hidden', 'all', array('value' => $this->_data['all']));
        $fields['all']->removeDecorator('WrapElement')->removeDecorator('FieldSize');

        $resourceOptions = array('' => '') + AclResource::getListArray();
        $fields['id_acl_resource'] = $this->createElement( 'select', 'id_acl_resource', array(
            'label' => $this->_tlabel.'id_acl_resource',
            'required' => true,
            'allowEmpty' => false,
            'multiOptions' => $resourceOptions,
            'allowEmpty' => false,
            'validators' => array(
                array('NotEmpty', true),
                array('InArray', true, array(array_keys($resourceOptions)))
            ),
            'select2' => array(
                'placeholder' => $this->getView()->translate('label_auth_acl_resource_item_form_placeholder_id_acl_resource'),
            ),
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }
}
