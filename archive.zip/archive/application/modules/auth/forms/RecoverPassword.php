<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Marek Skotarek
 * Date: 03.07.2013
 * Time: 22:09
 * To change this template use File | Settings | File Templates.

 */

class Auth_Form_RecoverPassword extends Base_Form_Vertical {

    protected $_belong_to = "AuthFormRecoverPassword";

    protected $_tlabel = "auth_form_recover_password_";

    public function init()
    {
        $fields = array();

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('RecordExists', true, array('model' => 'UserEmail', 'column' => 'email' )),
                array('EmailAddress', true)
            ),
            'input-group' => array(
                'class' => 'input-group-sm',
                'post' => array(
                    'type' => 'icon',
                    'class' => 'fa-envelope fa-fw',
                )
            )
        ));

        $fields['login'] = $this->createElement('html', 'login', array(
            'label' => 'form_auth-login_index',
            'size' => 12,
            'tag' => 'a',
            'html' => $this->getView()->translate('label_auth_index_back_to_login_form').' &raquo;',
            'href' => Base::url('admin')
        ))->removeDecorator('Label');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'form_auth_recover_submit',
            'class' => 'btn',
            'ignore' => true,
            'type' => 'submit',
            'icon' => 'refresh'
        ))->removeDecorator('Label');

        $this->addDisplayGroup(
            $fields,
            'main'
        );

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $g = $this->getDisplayGroup('main');
        $g->removeDecorator('panel');
    }
}