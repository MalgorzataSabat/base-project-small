<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Robert
 * Date: 03.07.13
 * Time: 21:47
 * To change this template use File | Settings | File Templates.
 */

class Auth_Form_AclRule extends Base_Form_Horizontal
{
    /**
     * @var array
     */
    private $_resourceList;

    /**
     * @var array
     */
    private $_roleList;


    /**
     * @var array
     */
    private $_rulesRoleList;


    /**
     * @param $rulesList array
     */
    protected function setRoleList($roleList)
    {
        $this->_roleList = $roleList;
    }

    /**
     * @param $resourceList array
     */
    protected function setResourceList($resourceList)
    {
        $this->_resourceList = $resourceList;
    }

    /**
     * @param $rulesRoleList array
     */
    protected function setRulesRoleList($rulesRoleList)
    {
        $this->_rulesRoleList = $rulesRoleList;
    }



    public function init()
    {
        $fields = array();

        $fields['rules'] = new Auth_Form_Element_Rules('rules', array(
            'value' => array(),
            'resources' => $this->_resourceList,
            'roles' => $this->_roleList,
            'rules' => $this->_rulesRoleList,
//            'decorators' => $this->_elementDecorators,
        ));

        $fields['submit'] = $this->createElement('submit', 'submit', array(
            'offset' => 5,
            'size' => 3,
            'loader' => 'false',
        ));

        $this->addDisplayGroup(
            $fields,
            'main',
            array(
                'legend' => $this->_tlabel.'group_user_info',
            )
        );


//        $this->setAttrib('class', trim($this->getAttrib('class').' ajax'));
//        $this->setAttrib('id', $this->getElementsBelongTo());
    }


}