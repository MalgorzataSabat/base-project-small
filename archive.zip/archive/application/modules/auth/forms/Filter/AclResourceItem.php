<?php

class Auth_Form_Filter_AclResourceItem extends Base_Form_Filter{

    protected $_tabColumnOn = false;

    protected $_fieldsAllow     = array(
        'search',
        'not_resource',
        'id_acl_resource',
    );

    protected $_fieldsDisplay   = array(
        'search', 'not_resource', 'id_acl_resource'
    );


    public function init()
    {
        $this->setMethod('get');
        $this->setAction('?page=1');

        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel.'search',
            'dimension' => 12,
            'filters' => array('StringTrim'),
        ));

        $this->_searchElements['not_resource'] = new Base_Form_Element_IsActive('not_resource', array(
            'label' => $this->_tlabel.'not_resource',
        ));

        $resourceList = array('' => '') + AclResource::getListArray();
        $this->_searchElements['id_acl_resource'] = $this->createElement('select', 'id_acl_resource', array(
            'label' => $this->_tlabel.'id_acl_resource',
            'allowEmpty' => true,
            'multiOptions' => $resourceList,
            'select2' => array(
                'allowClear' => true,
                'placeholder' => $this->getView()->translate('label_acl_resource_item_resource_empty'),
            ),
            'validators' => array(
                array('InArray', true, array(array_keys($resourceList)))
            ),
        ));

    }
}