<?php

class Auth_Bootstrap extends Base_Application_Module_Bootstrap
{

}