<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('auth_acl-resource-item-mass_delete', new Zend_Controller_Router_Route(
    '/@acl/@resources/@item/@mass-delete',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item-mass',
        'action' => 'delete'
    )
));

$router->addRoute('auth_acl-resource-item-mass_resource', new Zend_Controller_Router_Route(
    '/@acl/@resources/@item/@mass-resource',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item-mass',
        'action' => 'resource'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);


