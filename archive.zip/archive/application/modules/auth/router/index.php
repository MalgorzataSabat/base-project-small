<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('login', new Zend_Controller_Router_Route(
	'/login',
	array(
		'module' => 'auth',
		'controller' => 'index',
		'action' => 'index',
	)
));

$router->addRoute('auth_index_recover-pass', new Zend_Controller_Router_Route(
    '/@auth/@recover_pass',
    array(
        'module' => 'auth',
        'controller' => 'index',
        'action' => 'recover-password',
    )
));

$router->addRoute('auth_index_change-pass', new Zend_Controller_Router_Route(
    '/@auth/@change_pass/:hash',
    array(
        'module' => 'auth',
        'controller' => 'index',
        'action' => 'change-pass',
    ),
    array(
        'hash' => '(.*)',
    )
));

$router->addRoute('logout', new Zend_Controller_Router_Route(
	'/logout',
	array(
		'module' => 'auth',
		'controller' => 'index',
		'action' => 'logout',
	)
));

Zend_Controller_Front::getInstance()->setRouter($router);


