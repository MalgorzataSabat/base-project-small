<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('auth_acl_role_new', new Zend_Controller_Router_Route(
    '/@acl/@role/@new',
    array(
        'module' => 'auth',
        'controller' => 'acl-role',
        'action' => 'new',
    )
));

$router->addRoute('auth_acl_role_edit', new Zend_Controller_Router_Route(
    '/@acl/@role/@edit/:id_acl_role',
    array(
        'module' => 'auth',
        'controller' => 'acl-role',
        'action' => 'edit',
    ),
    array(
        'id_acl_role' => '\d+'
    )
));

$router->addRoute('auth_acl_role_delete', new Zend_Controller_Router_Route(
    '/@acl/@role/@delete/:id_acl_role',
    array(
        'module' => 'auth',
        'controller' => 'acl-role',
        'action' => 'delete',
    ),
    array(
        'id_acl_role' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);