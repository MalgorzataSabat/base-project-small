<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('auth_acl_resource_item_index', new Zend_Controller_Router_Route(
    '/@acl/@resources/@item',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item',
        'action' => 'index',
    )
));

$router->addRoute('auth_acl_resource_item_new', new Zend_Controller_Router_Route(
    '/@acl/@resource/@item/@new',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item',
        'action' => 'new',
    )
));

$router->addRoute('auth_acl_resource_item_edit', new Zend_Controller_Router_Route(
    '/@acl/@resource/@item/@edit/:id_acl_resource_item',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item',
        'action' => 'edit',
    ),
    array(
        'id_acl_resource_item' => '\d+'
    )
));

$router->addRoute('auth_acl_resource_item_delete', new Zend_Controller_Router_Route(
    '/@acl/@resource/@item/@delete/:id_acl_resource_item',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource-item',
        'action' => 'delete',
    ),
    array(
        'id_acl_resource_item' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


