<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('auth_acl', new Zend_Controller_Router_Route(
	'/@acl',
	array(
		'module' => 'auth',
		'controller' => 'acl',
		'action' => 'index',
	)
));

$router->addRoute('auth_acl_save-rule', new Zend_Controller_Router_Route(
    '/@acl/save-rule',
    array(
        'module' => 'auth',
        'controller' => 'acl',
        'action' => 'save-rule',
    )
));

$router->addRoute('auth_acl_new-resource', new Zend_Controller_Router_Route(
    '/@acl/@new-resource',
    array(
        'module' => 'auth',
        'controller' => 'acl',
        'action' => 'new-resource',
    )
));

$router->addRoute('auth_acl_delete-resource', new Zend_Controller_Router_Route(
    '/@acl/@delete-resource/:id_acl_resource',
    array(
        'module' => 'auth',
        'controller' => 'acl',
        'action' => 'delete-resource',
    ),
    array(
        'id_acl_resource' => '\d+'
    )
));

$router->addRoute('auth_acl_load-resource', new Zend_Controller_Router_Route(
    '/@acl/@load-resource',
    array(
        'module' => 'auth',
        'controller' => 'acl',
        'action' => 'load-resource',
    )
));


$router->addRoute('auth_acl_rule', new Zend_Controller_Router_Route(
    '/@acl/@rule/:role',
    array(
        'module' => 'auth',
        'controller' => 'acl',
        'action' => 'rule',
    ),
    array(
        'role' => '.*'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


