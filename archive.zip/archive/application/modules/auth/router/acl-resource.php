<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('auth_acl_resource_new', new Zend_Controller_Router_Route(
    '/@acl/@resource/@new',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource',
        'action' => 'new',
    )
));

$router->addRoute('auth_acl_resource_edit', new Zend_Controller_Router_Route(
    '/@acl/@resource/@edit/:id_acl_resource',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource',
        'action' => 'edit',
    ),
    array(
        'id_acl_resource' => '\d+'
    )
));

$router->addRoute('auth_acl_resource_delete', new Zend_Controller_Router_Route(
    '/@acl/@resource/@delete/:id_acl_resource',
    array(
        'module' => 'auth',
        'controller' => 'acl-resource',
        'action' => 'delete',
    ),
    array(
        'id_acl_resource' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


