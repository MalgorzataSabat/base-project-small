<?php
/**
 * Created by PhpStorm.
 * User: Robert
 * Date: 2014-12-15
 * Time: 15:29
 */

class Auth_Form_Element_Rules  extends Zend_Form_Element_Xhtml{

    public $helper = 'formRules';

    public function __construct($name = null, $options = array())
    {
        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }


    /**
     * Adds a file decorator if no one found
     */
    public function loadDefaultDecorators()
    {
        $this->clearDecorators();

        $this->setDecorators(array(
            array('ViewHelper'),
            array('ElementErrors'),
            array('Description', array('tag' => 'span', 'class' => 'help-block')),
            array('FieldSize'),
            array('WrapElement')
        ));

        return $this;
    }

}

