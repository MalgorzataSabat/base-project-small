<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 22.03.2018
 * Time: 09:06
 */

class Auth_Service_AclRule
{
    /**
     * @var AclRule
     */
    protected static $_list;


    protected static function getList()
    {

        if(!self::$_list)
        {
            self::$_list = AclRule::getQuery(array(
                'coll_key' => 'id_acl_rule',
                'id_service' => null,
            ))->fetchArray();
        }

        return self::$_list;
    }

    /**
     * @param $options
     * @return AclRule|null
     * @throws Doctrine_Connection_Exception
     * @throws Doctrine_Record_Exception
     * @throws Exception
     */
    public static function setAclRule($options)
    {
        $list = self::getList();
        $model = null;

        foreach($list as $rule)
        {
            $aclRule = new AclRule();
            $aclRule->role = $rule['role'];
            $aclRule->resource = $rule['resource'];
            $aclRule->is_allow = $rule['is_allow'];
            $aclRule->save();
            if($rule['resource'] == $options['resource'] && $rule['role'] == $options['role'])
            {
                $model = $aclRule;
            }
        }

        return $model;
    }

    public static function hasRule()
    {
        $rule = Doctrine_Query::create()
            ->from('AclRule o')
            ->addWhere('o.id_service = ?', Base_Service::getId())
            ->fetchArray();

        return (bool) $rule;
    }
}