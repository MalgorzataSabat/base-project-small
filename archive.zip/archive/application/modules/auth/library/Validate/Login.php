<?php

class Auth_Validate_Login extends Zend_Validate_Abstract
{

    const NOT_MATCH = 'notmatch';
    const DB_INVALID = 'databaseinvalid';

    /**
     * Adapter
     *
     * @var null
     */
    public $adapter = null;

    /**
     * Auth adapter name.
     *
     * @var string
     */
    protected $_authAdapter = 'Base_Auth_Adapter_DbTable';

    
    /**
     * Table name.
     *
     * @var string
     */
    protected $_tableName = null;

    /**
     * Login column.
     *
     * @var string
     */
    protected $_loginColumn = null;

    /**
     * Password column.
     *
     * @var string
     */
    protected $_passwordColumn = null;

    /**
     * Salting mechanism.
     *
     * @var string
     */
    protected $_saltingMechanism = null;

    /**
     * Array of validation failure messages
     *
     * @var array
     */
    protected $_messageTemplates = array(
        self::NOT_MATCH => 'error_login_auth_unknown',
        self::DB_INVALID => 'error_login_auth_unknown'
    );

    /**
     * Constructor.
     *
     * @param array $params Params
     * @return void
     */
    public function __construct(array $params)
    {
        foreach ($params as $paramName => $paramValue) {
            $paramName = '_' . $paramName;
            if (property_exists($this, $paramName)) {
                $this->{$paramName} = $paramValue;
            }
        }
    }

    public function isValid($value, $context = null)
    {
        $auth = Base_Auth::getInstance();
        $this->adapter = new $this->_authAdapter(
            $this->_tableName, $this->_loginColumn, $this->_passwordColumn
        );

        $this->adapter->setIdentity($context['login']);
        $this->adapter->setCredential(Base_Auth::hashPassword($context['password']));

        $result = $this->adapter->authenticate();
        if ($result->isValid()) {
            return true;
        }

        $this->_error(self::NOT_MATCH);
        return false;
    }

}