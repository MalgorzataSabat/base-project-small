SET @idResource000 = (SELECT id_acl_resource FROM acl_resource WHERE name = 'deal');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`, `assert`, `resource_class`) VALUES (@idResource000,'deal_api','Deal Api','','','');
SET @idResource101 = LAST_INSERT_ID();

INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@idResource101,'deal_api');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@idResource101,'deal_api_create');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@idResource101,'deal_api-test');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@idResource101,'deal_api-test_create');
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'guest', 'deal_api');

