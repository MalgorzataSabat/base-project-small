CREATE TABLE IF NOT EXISTS `deal` (
  `id_deal` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Serwis',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data ostatniej modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `id_user_created` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator użytkownika który dodał szanse sprzedazy',
  `hash` varchar(50) NOT NULL COMMENT 'Hash',
  `price` float(10,2) NULL COMMENT 'Wartość',
  `id_status` smallint(5) UNSIGNED NOT NULL COMMENT 'Status',
  `id_user` int(10) UNSIGNED DEFAULT NULL COMMENT 'Przypisane do uzytkownika',
  `id_client` int(10) UNSIGNED DEFAULT NULL COMMENT 'Klient',
  `tags` text NULL DEFAULT NULL COMMENT 'Tagi',
  `description` text NULL DEFAULT NULL COMMENT 'Opis',
  PRIMARY KEY (`id_deal`),
  KEY `id_service` (`id_service`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_status` (`id_status`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `deal`
  ADD CONSTRAINT `deal_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`),
  ADD CONSTRAINT `deal_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL,
  ADD CONSTRAINT `deal_ibfk_3` FOREIGN KEY (`id_status`) REFERENCES `dictionary` (`id_dictionary`),
  ADD CONSTRAINT `deal_ibfk_4` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  ADD CONSTRAINT `deal_ibfk_5` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL;
COMMIT;

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`) VALUES (NULL, NULL, 'deal', 'Szanse sprzedażowe', 'deal', '', '', '');
SET @id_acl_resource = LAST_INSERT_ID();

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`) VALUES (NULL, @id_acl_resource, 'deal_read', 'Przeglądanie', 'deal', '', '', '');
SET @id_acl_resource_read = LAST_INSERT_ID();

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`) VALUES (NULL, @id_acl_resource, 'deal_write', 'Zarządzanie', 'deal', '', '', '');
SET @id_acl_resource_write = LAST_INSERT_ID();

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_read, 'deal_index_index');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_read, 'deal_index_show');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_write, 'deal_index_new');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_write, 'deal_index_edit');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_write, 'deal_index_archive');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource_write, 'deal_index_delete');

INSERT INTO `acl_rule` (`id_acl_rule`, `is_allow`, `role`, `resource`) VALUES (NULL, '1', 'admin', 'deal');

INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Nowy', '1', '0', '1', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Wycena', '2', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Negocjacje', '3', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Realizacja', '4', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Wygrany', '5', '1', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DealStatus', 'Przegrany', '6', '1', '0', '', '', '');

ALTER TABLE `deal` CHANGE `hash` `hash` CHAR(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Hash';
