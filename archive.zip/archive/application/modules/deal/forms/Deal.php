<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 16:32
 */

class Deal_Form_Deal extends Base_Form_Horizontal
{

    /**
     * @var $_model Deal
     */
    protected $_model = null;

    public function init()
    {
        $this->setAction(Base::url());
        $fields = array();
        $fields_desc = array();

        $fields['title'] = $this->createElement('text', 'title', array(
            'label' => $this->_tlabel.'title',
            'value' => $this->_model['title'],
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
        ));

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => 'field_status',
            'object' => 'DealStatus',
            'value' => $this->_model['id_status'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['id_client'] = new Client_Form_Element_Client('id_client', array(
            'label' => $this->_tlabel.'id_client',
            'value' => $this->_model['id_client'],
            'required' => false,
            'allowEmpty' => true,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['id_user'] = new User_Form_Element_User('id_user', array(
            'label' => $this->_tlabel.'id_user',
            'value' => $this->_model['id_user'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
            'value' => $this->_model['email'],
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => $this->_tlabel.'phone',
            'value' => $this->_model['phone'],
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Phone),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['price'] = $this->createElement('text', 'price', array(
            'label' => $this->_tlabel.'price',
            'value' => $this->_model['price'],
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Float(), 'Null'),
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
        ));

        $fields['tags'] = new Tag_Form_Element_Tag('tags', array(
            'value' => !empty($this->_model['tags']) ? json_decode($this->_model['tags']) : array(),
            'size' => 8,
            'label-size' => 4,
            'allowEmpty' => true,
            'required' => false,
            'select2' => array(),
            'data-tags' => true,
            'data-token-separators' => "[',']",
            'multiple' => 'multiple',
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'model' => 'Deal',
        ));
        $fields['tags']->getDecorator('Description')->setEscape(false);
        $fields['tags']->setDescription('<i class="fa fa-tags"></i> Opisz szanse sprzedaży tagami');


        $fields['description'] = $this->createElement('wysiwyg', 'description', array(
            'label' => $this->_tlabel.'description',
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getDescription(),
            'size' => 12,
            'data-small' => true
        ))->removeDecorator('Label');

        $this->addDisplayGroup(
            $fields,
            'main'
        );

        $group_main = $this->getDisplayGroup('main');

        $this->addHtmlTag(array($group_main), array('class' => 'col-md-12'));
        $this->addHtmlTag(array($group_main), array('class' => 'row'));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array( $save));
        $this->addElements(array($save));


        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }


}