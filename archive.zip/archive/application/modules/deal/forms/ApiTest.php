<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.03.2018
 * Time: 15:02
 */

class Deal_Form_ApiTest extends Base_Form_Horizontal
{

    public function init()
    {
        $fields = array();

        $fields['title'] = $this->createElement('text', 'title', array(
            'label' => 'Tytuł',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'size' => 8,
            'label-size' => 4
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => 'E-mail',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => 'Telefon',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Phone()),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['description'] = $this->createElement('wysiwyg', 'description', array(
            'label' => 'Treść',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));


        $this->addDisplayGroup($fields, 'main', array(
            'legend' => 'API Test - Szanse Sprzedaży'
        ));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));
    }
}