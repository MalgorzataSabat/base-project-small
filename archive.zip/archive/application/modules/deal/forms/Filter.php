<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 15:35
 */

class Deal_Form_Filter extends Base_Form_Filter
{

    protected $_sortCols        = array(
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'id_user_created' => 'o.id_user_created',
        'id_status' => 'o.id_status',
        'id_user' => 'o.id_user',
        'id_client' => 'o.id_client',
        'price' => 'o.price',
        'title' => 'o.title',
        'email' => 'o.email',
        'phone' => 'o.phone',
    );

    protected $_avalibleCols    = array(
        'title' => 'filter_deal-column_title',
        'created_at' => 'filter_deal-column_created_at',
        'updated_at' => 'filter_deal-column_id_updated_at',
        'id_status' => 'filter_deal-column_id_status',
        'id_user_created' => 'filter_deal-column_id_user_created',
        'id_user' => 'filter_deal-column_id_user',
        'id_client' => 'filter_deal-column_id_client',
        'price' => 'filter_deal-column_price',
        'email' => 'filter_deal-column_email',
        'phone' => 'filter_deal-column_phone',
        'tags' => 'filter_deal-column_tags',
    );

    protected $_fieldsDisplay   = array(
        'search'
    );

    protected $_defaultCols     = array (
        'created_at', 'title', 'id_status', 'id_user', 'id_client', 'price','email', 'phone', 'tags'
    );

    public function init()
    {
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel.'search',
        ));

        $this->_searchElements['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => 'filed_status',
            'object' => 'DealStatus',
        ));

        $this->_searchElements['id_client'] = new Client_Form_Element_Client('id_client', array(
            'label' => $this->_tlabel.'id_client',
        ));

        $this->_searchElements['price'] = $this->createElement('search_Number', 'price', array(
            'label' => $this->_tlabel . 'price',
        ));

        $this->_searchElements['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
        ));

        $this->_searchElements['phone'] = $this->createElement('text', 'phone', array(
            'label' => $this->_tlabel.'phone',
            'filters' => array(new Base_Filter_Phone),
        ));

        $this->_searchElements['id_user'] = new User_Form_Element_User('id_user', array(
            'label' => $this->_tlabel.'id_user',
        ));

        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' => $this->_tlabel . 'id_user_created'
        ));

        $this->_searchElements['tags'] = new Tag_Form_Element_Tag('tags', array(
            'select2' => array(),
            'multiple' => 'multiple',
            'model' => 'Deal',
        ));

        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => $this->_tlabel . 'created_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['updated_at'] = $this->createElement('search_Date', 'updated_at', array(
            'label' => $this->_tlabel . 'updated_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $optionsArchive = array(
            '' => '',
            0 => 'label_archive_all',
            1 => 'label_archive_only'
        );

        $this->_searchElements['archived_at'] = $this->createElement('select', 'archived_at', array(
            'label' => $this->_tlabel.'archived_at',
            'multiOptions' => $optionsArchive,
        ));

    }

}