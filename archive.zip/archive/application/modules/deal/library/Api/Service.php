<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.03.2018
 * Time: 15:56
 */

class Deal_Api_Service extends Api_Service
{
    private $_base_url = null;

    private static $URL_MAP = array(
        'create-deal' => 'deal/api/create',
    );

    /**
     * @param $options
     */
    public function __construct($options)
    {
        parent::__construct($options);

        if(isset($options['base_url'])){
            $this->setBaseUrl($options['base_url']);
        }

    }

    /**
     * @return null
     */
    public function getBaseUrl()
    {
        return $this->_base_url;
    }

    /**
     * @param $baseUrl
     * @return $this
     */
    public function setBaseUrl($baseUrl)
    {
        $this->_base_url = $baseUrl;

        return $this;
    }


    public function createDeal($data)
    {
        if(!$this->_validateDeal($data)){
            return false;
        }

        $this->addParams($data);

        $this->setUrl($this->getBaseUrl().'/'.self::$URL_MAP['create-deal']);

        return $this->makeRequest();
    }

    private function _validateDeal($data)
    {

        if(!isset($data['title']) || !strlen($data['title'])){
            return false;
        }

        return true;
    }
}