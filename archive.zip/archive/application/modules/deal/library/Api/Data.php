<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.03.2018
 * Time: 14:40
 */

class Deal_Api_Data extends Api_Data
{
    /**
     * @var Deal
     */
    protected $_deal;

    /**
     * @var Client
     */
    protected $_client;

    public function isValid($data = null)
    {
        if($data){
            $this->setData($data);
        }

        if(null !== $this->_isValid){
            return $this->_isValid;
        }

        if( !isset($this->_data['id_api_service']) || !strlen($this->_data['id_api_service'])){
            $this->_error['message'] = 'Deal: Field "id_api_service" is required';

            $this->_isValid = false;
            return $this->_isValid;
        }

        if( !isset($this->_data['title']) || !strlen($this->_data['title'])){
            $this->_error['message'] = 'Deal: Field "title" is required';

            $this->_isValid = false;
            return $this->_isValid;
        }

        $this->_isValid = true;
        return $this->_isValid;
    }


    /**
     * @return Deal
     * @throws Exception
     */
    public function getDeal()
    {
        if(!$this->isValid()){
            throw new Exception('Deal data is not Valid');
        }

        $this->_deal = new Deal();

        $dictionary = Dictionary::getDefault('DealStatus');
        $phoneFilter = new Base_Filter_Phone();

        if($dictionary)
        {
            $this->_deal->id_status = $dictionary['id_dictionary'];
        }
        $this->_deal->title = $this->_data['title'];
        $this->_deal->phone = $phoneFilter->filter($this->_data['phone']);
        $this->_deal->email = $this->_data['email'];
        $this->_deal->description = $this->_data['description'];

        $this->_deal->save();


        return $this->_deal;
    }

}