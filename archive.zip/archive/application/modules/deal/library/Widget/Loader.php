<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:46
 */

class Deal_Widget_Loader extends Base_Widget_Loader
{


    public function getParamsByWidget($widget)
    {
        $params = array();

        if($widget == 'Deal_Widget_Card')
        {
            $params = array('deal' => $this->_model);
        }

        elseif($widget == 'Client_Widget_Card')
        {
            if(isset($this->_model['Client']) && is_array($this->_model['Client'])){
                $params = array('client' => $this->_model['Client']);
            }else{
                $params = array('client' => $this->_model['id_client']);
            }
        }

        elseif($widget == 'Document_Widget_Channel')
        {
            $params = array(
                'channel' => 'Deal',
                'object_id' => $this->_model['id_deal']
            );
        }

        elseif($widget == 'Note_Widget_Note')
        {
            $params = array(
                'channel' => 'Deal',
                'object_id' => $this->_model['id_deal']
            );
        }

        elseif($widget == 'Log_Widget_Timeline')
        {
            $params = array(
                'model' => 'Deal',
                'id_object' => $this->_model['id_deal']
            );
        }

        return $params;
    }



}
