<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:46
 */

class Deal_Loader extends Base_Loader_List
{
    /**
     * @var Deal_Form_Filter
     */
    protected $_filter;


    /**
     * @param array $options
     */
    public function __construct($options = array())
    {
        parent::__construct($options);
        $this->_filter = new Deal_Form_Filter();
    }

    /**
     * @return array
     */
    public function getResult($select = null)
    {
        if($this->getAll())
        {
            $dataQuery = $this->_filter->getValuesQuery(true);
            $dataQuery['coll_key'] = 'id_deal';
            $query = Deal::getQuery($dataQuery);
        }
        elseif($this->getValue())
        {
            $query = Doctrine_Query::create()
                ->from('Deal o INDEXBY o.id_deal')
                ->whereIn('o.id_deal', $this->getValue());
        }

        if($select){
            $query->select($select);
        }


        $this->_result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        return $this->_result;
    }
}