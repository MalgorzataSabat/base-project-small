<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 12:10
 */


class Deal_Extractor extends Base_Extractor
{

    protected $_tables = array('deal');

    protected $_data = array();

    protected $_module = 'deal';

    protected $_dumpResource = array('deal');

    protected $_dumpRule = array('deal');

    protected $_dumpLabel = array('deal');

    protected $_dumpChangelog = array('deal');

    protected $_dumpSettings = array('deal');

    protected $_dumpDictionary = array('DealStatus');


}