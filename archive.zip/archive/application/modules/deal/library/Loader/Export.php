<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:45
 */

class Deal_Loader_Export extends Deal_Loader
{
    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $filter = new Deal_Form_Filter();
        $dataQuery = $filter->getValuesQuery(true);
        $selectColumn = join(',', $dataQuery['column']);
        $view = Base_Layout::getView();

        if ($this->getAll()) {
            $query = Deal::getQuery($dataQuery)
                ->select($selectColumn);
        } elseif ($this->getValue()) {
            $query = Doctrine_Query::create()
                ->select($selectColumn)
                ->from('deal o')
                ->whereIn('o.id_deal', $this->getValue());

        }

        $query->addSelect('s.name as id_status');
        $query->leftJoin('o.Status s');
        $query->addSelect("concat(uc.name, ' ',uc.surname) as id_user_created");
        $query->leftJoin('o.UserCreated uc');
        $query->addSelect("concat(u.name, ' ',u.surname) as id_user");
        $query->leftJoin('o.User u');
        $query->addSelect("c.name as id_client");
        $query->leftJoin('o.Client c');

        if ($select) {
            $query->select($select);
        }

        $result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        foreach($result as $k => $data){
            foreach ($dataQuery['column'] as $column) {
                $this->_labels[$column] =  $view->translate('label_deal_admin_list_' . $column);

                if ($column == 'tags') {
                    $this->_result[$k][$column] = join(', ', json_decode($data[$column], true));
                }else{
                    $this->_result[$k][$column] = trim(strip_tags($data[$column]));
                }
            }
        }

        unset($result);

        return $this->_result;
    }
}