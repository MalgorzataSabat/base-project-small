<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 15:04
 */

class Deal_IndexController extends Base_Controller_Action
{

    /**
     * @var Deal
     */
    protected $_model;
    private $_formFilter;
    private $_dataQuery = array();

    public function indexAction()
    {
        $this->_formFilter = new Deal_Form_Filter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = Deal::getQuery($this->_dataQuery);

        if($this->view->hasAccess('export_deal')){
            $this->view->massActionOptions = array(
                'export' => array(
                    'url' => Base::url('export', array('object' => 'deal')),
                    'name' => $this->view->translate('mass-options_export')
                )
            );
        }

        $this->view->dealList = $this->_helper->paging($query);
        $this->view->formFilter = $this->_formFilter;
    }

    public function showAction()
    {
        $this->_model = Deal::find($this->getParam('id_deal'), array('addClient' => ''));
        $this->forward403Unless($this->_model);

        $layoutService = new Layout_Service('deal_card');
        $layoutService->setLoader('Deal_Widget_Loader', array(
            'model' => $this->_model
        ));

        $this->view->layoutService = $layoutService;
        $this->view->deal = $this->_model;
    }

    public function newAction()
    {
        $this->_model = new Deal();
        $this->_model->id_user = Base_Auth::getUserId();

        $this->_formDeal();
    }

    public function editAction()
    {
        $this->_model = Deal::findRecord($this->getParam('id_deal'));
        $this->forward403Unless($this->_model);

        $this->_formDeal();
    }

    private function _formDeal()
    {
        $form = new Deal_Form_Deal(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() ) {
            if ( $form->isValid($this->_request->getPost()) ) {
                $this->_model->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                } else {
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit(array('id_deal' => $this->_model['id_deal']), 'deal_show');
                }
            }
        }

        $this->view->form = $form;
        $this->view->model = $this->_model;
    }

    public function archiveAction()
    {
        $id_deal = $this->getParam('id_deal');
        $this->_model = Deal::findRecord($id_deal);
        $this->forward403Unless($this->_model);

        $this->_model->archived_at = $this->_model->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_model->save();

        if ( $this->_model->archived_at ) {
            $this->_flash()->success->addMessage('label_cms_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_cms_unarchive_success');
        }

        $this->_redirector()->gotoRouteAndExit(array(), 'deal');
    }

    public function deleteAction()
    {
        $this->_model = Deal::findRecord($this->getParam('id_deal'));
        $this->forward404Unless($this->_model);

        $this->_model->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'deal');
        }
    }

}