<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.03.2018
 * Time: 14:14
 */

class Deal_ApiTestController extends Base_Controller_Action
{
    public function createAction()
    {
        $form = new Deal_Form_ApiTest();

        if($this->_request->isPost() && $form->isValid( $this->_request->getPost())) {
            $apiConfig = array(
                'id_api_service' => Setting::getSetting('api.id_api_service'),
                'key' => Setting::getSetting('api.key'),
                'base_url' => PROTOCOL.'://'.DOMAIN,
            );

            $api = new Deal_Api_Service($apiConfig);

            $data = $form->getValues(true);

            var_dump('--- REQUEST ---');
            var_dump($data);

            $deal = $api->createDeal($data);

            var_dump('--- RESPONSE ---');
            var_dump($deal);
        }


        $this->view->form = $form;
    }
}