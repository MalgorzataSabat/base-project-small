<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 16.03.2018
 * Time: 14:14
 */

class Deal_ApiController extends Api_Controller_Action
{
    private $_dealData = array(

    );

    public function createAction()
    {

        if(!$this->_result['result']){
            return;
        }

        $this->_processDeal();
    }


    private function _processDeal()
    {
        $this->_dealData = $this->getAllParams();

        $dataDeal = new Deal_Api_Data();
        if(!$dataDeal->isValid($this->_dealData)){
            $this->_result['message'] = $dataDeal->getErrorMessage();
            $this->_result['result'] = false;

            return false;
        }

        $deal = $dataDeal->getDeal();

        if($deal){
            $deal = $deal->toArray();
        }

        $this->_result['body'] = $deal;
    }
}