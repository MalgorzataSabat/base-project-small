<?php

$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('deal', new Zend_Controller_Router_Route(
    '/@deal',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('deal_new', new Zend_Controller_Router_Route(
    '/@deal/@new',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'new'
    )
));

$router->addRoute('deal_edit', new Zend_Controller_Router_Route(
    '/@deal/@edit/:id_deal',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_deal' => '\d+'
    )
));

$router->addRoute('deal_show', new Zend_Controller_Router_Route(
    '/@deal/@show/:id_deal',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_deal' => '\d+'
    )
));

$router->addRoute('deal_archive', new Zend_Controller_Router_Route(
    '/@deal/@archive/:id_deal',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'archive'
    ),
    array(
        'id_deal' => '\d+'
    )
));

$router->addRoute('deal_delete', new Zend_Controller_Router_Route(
    '/@deal/@delete/:id_deal',
    array(
        'module' => 'deal',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_deal' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);