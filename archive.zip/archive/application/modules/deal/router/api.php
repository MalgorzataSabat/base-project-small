<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('deal_api_create', new Zend_Controller_Router_Route(
    '/deal/api/create',
    array(
        'module' => 'deal',
        'controller' => 'api',
        'action' => 'create'
    )
));




Zend_Controller_Front::getInstance()->setRouter($router);