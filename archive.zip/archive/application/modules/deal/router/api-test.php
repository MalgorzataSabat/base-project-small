<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('deal_api-test_create', new Zend_Controller_Router_Route(
    '/deal/api/test/create',
    array(
        'module' => 'deal',
        'controller' => 'api-test',
        'action' => 'create'
    )
));




Zend_Controller_Front::getInstance()->setRouter($router);