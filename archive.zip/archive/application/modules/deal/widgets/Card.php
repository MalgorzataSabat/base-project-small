<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Deal_Widget_Card extends Base_Widget_Abstract
{
    public      $name = 'label_deal_widget_card';
    public      $_renderView = 'card.phtml';

    /**
     * @var Deal
     */
    protected   $_deal;

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }

    public function renderWidget()
    {
        if(!isset($this->params['deal'])){
            $this->_renderView = null;
            return;
        }


        if($this->params['deal'] instanceof Deal)
        {
            $this->_deal = $this->params['deal'];

        } elseif(is_array($this->params['deal'])) {
            $this->_deal = $this->params['deal'];
        } else {
            $this->_deal = Deal::find($this->params['deal']);
        }

        $this->view->deal = $this->_deal;
    }
}