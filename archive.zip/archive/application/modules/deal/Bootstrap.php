<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 13:57
 */

class Deal_Bootstrap extends Base_Application_Module_Bootstrap
{

    public function _initWidget()
    {
        if(DEV){
            Base_Widget::registerWidget('Deal_Widget_Card');
        }
    }

}