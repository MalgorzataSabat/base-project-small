<?php
/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2015-10-04
 * Time: 14:20
 */

class Admin_Form_Query extends Base_Form_Horizontal
{
    public function init()
    {
        $this->setAction(Base::url());
        $fields = array();

        $fields['title'] = $this->createElement('text', 'title', array(
            'label' => $this->_tlabel . 'title',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model['title'],
        ));

//        $fields['is_public'] = $this->createElement('checkbox', 'is_public', array(
//            'label' => $this->_tlabel . 'is_public',
//            'required' => false,
//            'allowEmpty' => true,
//            'text' => $this->getView()->translate($this->_tlabel.'is_public_desc'),
//            'checked' => $this->_model['is_public']
//        ));

        $fields['is_default'] = $this->createElement('checkbox', 'is_default', array(
            'label' => $this->_tlabel . 'is_default',
            'required' => false,
            'allowEmpty' => true,
            'text' => $this->getView()->translate($this->_tlabel.'is_default_desc'),
            'checked' => $this->_model['is_default']
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));


        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }


} 