<?php

class Admin_Form_Label extends Base_Form_Horizontal
{

    /**
     * @var $_model Label
     */
    protected $_model;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $params = array();
        if ( !$this->_model->isNew() ) {
            $params[] = array('id_label', '<>', $this->_model->getId());
        }

        $fields['name'] = $this->createElement( 'text', 'label', array(
            'label' => $this->_tlabel.'label',
            'required' => true,
            'allowEmpty' => false,
            'dimension' => 3,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
                array('TranslationTaken', true, array('label', $params))
            ),
            'value' => $this->_model->getLabel(),
        ));

        $fields['value'] = $this->createElement('text', 'value', array(
            'label' => $this->_tlabel.'value',
            'filters' => array('StringTrim'),
            'dimension' => 3,
            'value' => $this->_model->Translations[Base_I18n::getLangId()]->getValue()
        ));


        $labelTypeOptions = Label::getTypes();

        $fields['type'] = $this->createElement( 'select', 'type', array(
            'label' => $this->_tlabel.'type',
            'required' => true,
            'multiOptions' => $labelTypeOptions,
            'allowEmpty' => false,
            'validators' => array(
                array('NotEmpty', true),
                array('InArray', true, array(array_keys($labelTypeOptions)))
            ),
            'value' => $this->_model->getType(),
            'dimension' => 3
        ));



        $moduleOptions = array('' => '') + Base_Module::getModules();
        $fields['module'] = $this->createElement('select', 'module', array(
            'label' => $this->_tlabel.'module',
            'required' => true,
            'allowEmpty' => false,
            'validators' => array(
                array('NotEmpty', true),
                array('InArray', true, array(array_keys($moduleOptions)))
            ),
            'multiOptions' => $moduleOptions,
            'value' => $this->_model->getModule(),
            'select2' => true,
        ));

        $languageOptions = Language::getAvailableLanguagesArray();
        $fields['id_language'] = $this->createElement('select', 'id_language', array(
            'label' => $this->_tlabel.'id_language',
            'required' => true,
            'allowEmpty' => false,
            'validators' => array(
                array('InArray', true, array(array_keys($languageOptions)))
            ),
            'select2' => true,
            'multiOptions' => $languageOptions,
            'value' => $this->_model->Translations[Base_I18n::getLangId()]['id_language'],
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

    public function isValid($data)
    {
        $data = $data[$this->getElementsBelongTo()];

        if ( $data['type'] == 'route' ) {
            $parameters_label = array(
                array('label', '=', $data['label']),
            );
            $parameters_value = array(
                array('t.value', '=', $data['value']),
            );
            if ( !$this->_model->isNew() ) {
                $parameters_label[] = array('id_label', '<>', $this->_model->getId());
                $parameters_value[] = array('id_label', '<>', $this->_model->getId());
            }
            $this->getElement('label')->addValidator('TranslationTaken', true, array('label', $parameters_label));
            $this->getElement('value')->addValidator('TranslationTaken', true, array('t.value', $parameters_value));
        }

        return parent::isValid($data);
    }


    protected function postIsValid($data)
    {
        parent::postIsValid($data);

        $this->_model->Translations[$this->getValue('id_language')]['value'] = $this->getValue('value');

        return true;
    }

}