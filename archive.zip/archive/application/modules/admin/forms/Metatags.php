<?php

class Admin_Form_Metatags extends Base_Form_Horizontal
{

    /**
     * @var Base_Doctrine_Record
     */
    protected $_model;

    private $_wrapper_class = null;

    protected function setWrapperClass($wrapper_class)
    {
        $this->_wrapper_class = $wrapper_class;
    }

    public function init()
    {
        $fields = array();

        $fields['meta_title'] = $this->createElement( 'text', 'meta_title', array(
            'label' => $this->_tlabel.'meta_title',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getMetaTitle(),
        ));

        $fields['meta_keywords'] = $this->createElement( 'text', 'meta_keywords', array(
            'label' => $this->_tlabel.'meta_keywords',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getMetaKeywords(),
        ));

        $fields['meta_description'] = $this->createElement( 'text', 'meta_description', array(
            'label' => $this->_tlabel.'meta_description',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getMetaDescription(),
        ));



        $this->addDisplayGroup( $fields, 'main',  array(
            'legend' => $this->_tlabel.'group_main',
            'class' => $this->_wrapper_class . ' ',
        ));


        $this->setDecorators(array(
            'FormElements',
        ));
    }
}