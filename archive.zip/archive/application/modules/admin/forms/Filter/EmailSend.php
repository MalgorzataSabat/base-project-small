<?php

class Admin_Form_Filter_EmailSend extends Base_Form_Filter {
    
    protected $_sortCols = array(
        
        'id_email_send' => 'o.id_email_send',
        'created_at'    => 'o.created_at',
        'is_sent'       => 'o.is_sent',
        'to_send'       => 'o.to_send',
        'subject'       => 'o.subject',
        'from'          => 'o.from',
        'to'            => 'o.to',
        'sent_time'     => 'o.sent_time',
        //'filename'      => 'o.filename',
        //'exception'     => 'o.exception'
    );
    
    protected $_avalibleCols = array(
        
        'id_email_send' =>  'admin_form_filter_emailsend_id_email_send',
        'created_at'    =>  'admin_form_filter_emailsend_created_at',
        'is_sent'       =>  'admin_form_filter_emailsend_is_sent',
        'to_send'       =>  'admin_form_filter_emailsend_to_send',
        'subject'       =>  'admin_form_filter_emailsend_subject',
        'from'          =>  'admin_form_filter_emailsend_from',
        'to'            =>  'admin_form_filter_emailsend_to',
        'sent_time'     =>  'admin_form_filter_emailsend_sent_time'
    );
    
    protected $_fieldsAllow = array(
        
        'search',
        'created_at',
        'is_sent',
        'to_send',
        'subject',
        'from',
        'to',
        'sent_time'
    );
    
    protected $_fieldsDisplay = array(
        
        'search',
        'created_at',
        'is_sent',
        'to_send',
        'subject',
        'from',
        'to',
        'sent_time'
    );
    protected $_defaultCols = array(
        
        'id_email_send',
        'created_at',
        'subject',
        'from',
        'to',
        'sent_time',
        'is_sent',
        'to_send'
    );
    
    public function init(){
        
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel.'search',
        ));
        
        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => $this->_tlabel . 'created_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd')),
            ),
        ));
        
        $this->_searchElements['from'] = $this->createElement('text', 'from', array(
            'label' => $this->_tlabel.'from',
        ));
        
        $this->_searchElements['to'] = $this->createElement('text', 'to', array(
            'label' => $this->_tlabel.'to',
        ));
        
        $this->_searchElements['sent_time'] = $this->createElement('search_Date', 'sent_time', array(
            'label' => $this->_tlabel . 'sent_time',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd')),
            ),
        ));

    }
}