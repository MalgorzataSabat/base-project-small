<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 12.01.2018
 * Time: 10:44
 */

class Admin_Form_Service extends Base_Form_Horizontal
{
    public function init()
    {
        $this->setAction(Base::url());
        $fields = array();

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel . 'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model['name'],
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['domain'] = $this->createElement('text', 'domain', array(
            'label' => $this->_tlabel . 'domain',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model['domain'],
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['is_active'] = $this->createElement('checkbox', 'is_active', array(
            'label' => $this->_tlabel . 'is_active',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model['is_active'],
            'size' => 8,
            'label-size' => 4,
        ));

        $dateOptions = array(
            'sideBySide' => true,
            'locale' => 'pl',
            'format' => 'YYYY-MM-DD',
            'language' => 'pl',
            'pickTime' => false,
        );
        $fields['package_end'] = $this->createElement('DateTimePicker', 'package_end', array(
            'label' => $this->_tlabel.'package_end',
            'allowEmpty' => true,
            'datetime' => $dateOptions,
            'filters' => array('Null'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            ),
            'value' => $this->_model['package_end'],
            'size' => 8,
            'label-size' => 4,
        ));

        if($this->_model->isNew())
        {
            $fields['email'] = $this->createElement('text', 'email', array(
                'label' => $this->_tlabel . 'email',
                'required' => false,
                'allowEmpty' => true,
                'filters' => array('StringTrim'),
                'validators' => array(
                    array('EmailAddress', true)
                ),
                'size' => 8,
                'label-size' => 4,
            ));
            $fields['email']->setDescription('Podanie adresu email stworzy konto użytkownika.');
        }

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));


        $this->setAttrib('class', $this->getAttrib('class') . ' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

    public function postIsValid($data)
    {
        parent::postIsValid($data);

        return true;
    }
}