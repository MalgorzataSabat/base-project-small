<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 12.01.2018
 * Time: 10:44
 */

class Admin_Form_ServiceFilter extends Base_Form_Filter
{
    protected $_sortCols = array(
        'id_service' => 'o.id_service',
        'is_active' => 'o.is_active',
        'name' => 'o.name',
        'domain' => 'o.domain',
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'package_end' => 'o.package_end'
    );
    protected $_avalibleCols = array(
        'id_service' => 'filter_service-column_id_service',
        'is_active' => 'filter_service-column_is_active',
        'name' => 'filter_service-column_name',
        'domain' => 'filter_service-column_domain',
        'created_at' => 'filter_service-column_created_at',
        'updated_at' => 'filter_service-column_updated_at',
        'package_end' => 'filter_service-column_package_end',
    );

    protected $_fieldsDisplay = array(
        'search'
    );
    protected $_defaultCols = array('id_service', 'name', 'domain', 'is_active','created_at', 'package_end');

    public function init() {
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel . 'search',
        ));

        $optionsActive = array(
            '' => '',
            0 => 'label_no',
            1 => 'label_yes',
        );
        $this->_searchElements['is_active'] = $this->createElement('select', 'is_active', array(
            'label' => $this->_tlabel . 'is_active',
            'multiOptions' => $optionsActive,
        ));


        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => $this->_tlabel . 'created_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd')),
            ),
        ));

        $this->_searchElements['updated_at'] = $this->createElement('search_Date', 'updated_at', array(
            'label' => $this->_tlabel . 'updated_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd')),
            ),
        ));

        $this->_searchElements['package_end'] = $this->createElement('search_Date', 'package_end', array(
            'label' => $this->_tlabel . 'package_end',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd')),
            ),
        ));



    }
}