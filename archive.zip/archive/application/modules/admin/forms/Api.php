<?php

class Admin_Form_Api extends Base_Form_Horizontal
{
    
    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());
        
        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel . 'name',
            'required' => true,
            'allowEmpty' => false,
            
            'size' => 8,
            'label-size' => 4,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('StringLength', true, array('max' => 255)),
            ),
            'value' => $this->_model['name'],
        ));
        
        $fields['description'] = $this->createElement('textarea', 'description', array(
            'label' => $this->_tlabel . 'description',
            'size' => 8,
            'label-size' => 4,
            'rows' => 6,
            'value' => $this->_model['description'],
        ));
        
        $this->addDisplayGroup($fields, 'main');
        
        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));
        
        

        $this->setFormActions(array( $save));
        $this->addElements(array($save));
        
        //$this->setAttrib('class', $this->getAttrib('class') . ' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        //$this->setAttrib('data-overbox-replace', true);
    }
    
    public function postIsValid($data)
    {
        parent::postIsValid($data);
        
        if($this->_model->isNew())
        {
            $this->_model->key = md5(microtime() . rand(1,1000). $this->_model->name );
            $this->_model->save();
        }
        
        return true;
    }
    
}
