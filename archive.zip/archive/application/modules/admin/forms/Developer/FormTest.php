<?php

class Admin_Form_Developer_FormTest extends Base_Form_Horizontal
{

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['name'] = $this->createElement( 'text', 'label', array(
            'label' => 'Nazwa: text',
            'required' => true,
            'allowEmpty' => false,
            'dimension' => 3,
            'filters' => array('StringTrim'),
            'description' => 'Pole wymagane'
        ));

        $moduleOptions = array('' => '') + Base_Module::getModules();
        $fields['module'] = $this->createElement('select', 'module', array(
            'label' => 'Moduł: select',
            'required' => true,
            'allowEmpty' => false,
            'validators' => array(
                array('NotEmpty', true),
                array('InArray', true, array(array_keys($moduleOptions)))
            ),
            'multiOptions' => $moduleOptions,
            'select2' => array()
        ));

        $fields['publication_start'] = $this->createElement('DateTimePicker', 'publication_start', array(
            'label' => 'Przykładowa data',
            'allowEmpty' => true,
            'required' => false,
            'size' => 8,
            'label-size' => 4,
            'data-mask' => "9999-99-99 99:99",
            'data-mask-placeholder' => "_"
        ));


        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

}