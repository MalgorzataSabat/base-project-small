<?php

class Admin_Form_ApiFilter extends Base_Form_Filter
{
    protected $_sortCols        = array(
        'id_api_service' => 'o.id_api_service',
        'key' => 'o.key',
        'name' => 'o.name',
        
    );

    protected $_avalibleCols    = array(
        'id_api_service' => 'filter_api-column_id_api_service',
        'key' => 'filter_api-column_key',
        'name' =>'filter_api-column_name',
    );

    protected $_fieldsDisplay   = array(
        'search'
    );

    protected $_defaultCols     = array (
        'id_api_service', 'key', 'name'
    );

    public function init()
    {
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel.'search',
        ));
    }
}