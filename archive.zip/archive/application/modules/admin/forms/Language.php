<?php

class Admin_Form_Language extends Base_Form_Horizontal
{

    /**
     * @var Language
     */
    protected $_model;

    public function init()
    {
        $fields = array();

        $fields['name'] = $this->createElement( 'text', 'name', array(
            'label' => $this->_tlabel.'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'dimension' => 12,
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model->getName(),
        ));


        $fields['is_active'] = $this->createElement( 'checkbox', 'is_active', array(
            'label' => $this->_tlabel.'is_active',
            'value' => $this->_model->getIsActive(),
        ));

        $fields['is_main'] = $this->createElement( 'checkbox', 'is_main', array(
            'label' => $this->_tlabel.'is_main',
            'value' => $this->_model->getIsMain(),
        ));


        $fields['code'] = $this->createElement( 'text', 'code', array(
            'label' => $this->_tlabel.'code',
            'required' => true,
            'allowEmpty' => false,
            'dimension' => 12,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model->getCode(),
        ));

        $fields['domain'] = $this->createElement( 'text', 'domain', array(
            'label' => $this->_tlabel.'domain',
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'dimension' => 12,
            'validators' => array(
                array('StringLength', true, array('max' => 255))
            ),
            'value' => $this->_model->getDomain(),
        ));


        $fields['submit'] = $this->createElement('submit', 'submit', array(
            'label' => $this->_tlabel.'submit',
        ));

        $this->addDisplayGroup($fields, 'main', array(
            'legend' => $this->_tlabel.'group_std',
        ));
    }



    protected function postIsValid($data)
    {
        parent::postIsValid($data);

        if($this->getValue('is_main')){
            $query = Doctrine_Query::create()
                ->update('Language')
                ->set('is_main', '0');

            if(!$this->_model->isNew()){
                $query->addWhere('id_language != ?', $this->_model->getId());
            }

            $query->execute();
            $this->_model->is_active = true;
        }

        return true;
    }


}