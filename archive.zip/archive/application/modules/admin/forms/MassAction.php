<?php
/**
 * Created by JetBrains PhpStorm.
 * User: skotar
 * Date: 08.09.2013
 * Time: 16:19
 * To change this template use File | Settings | File Templates.
 */

class Admin_Form_MassAction extends Base_Form_Vertical {

    protected $_belong_to = "Admin_Form_MassAction";
    protected $_tlabel = "admin_form_mass-action_";

    private $_actions = array();


    protected function setActions($actions)
    {
        $this->_actions = $actions;
    }

    public function init()
    {
        $fields = array();

        $fields['mass'] = $this->createElement('select', 'mass', array(
            'multiOptions' => $this->_actions,
            'class' => 'massEditSelect form-control',
        ));

        $fields['submit'] = $this->createElement('submit', 'submit', array(
            'label' => 'label_mass_edit_proceed',
            'type' => 'submit',
            'ignore' => true,
            'class' => 'btn btn-success mass-edit-button confirmMassAction',
            'data-confirm' => $this->getView()->translate('label_mass_action_confirm'),
        ));

        $this->addDisplayGroup($fields, 'mass-action', array(
            'legend' => $this->_tlabel.'mass-action'
        ));
    }
}