<?php

class Admin_Form_Label_Import extends Base_Form_Horizontal
{

    public function init()
    {
        $fields = array();

        $fields['file'] = $this->createElement( 'file', 'file', array(
            'label' => $this->_tlabel.'file',
            'required' => true,
            'allowEmpty' => false,
            'validators' => array(
                array('Extension', true, 'csv')
            )
        ));

        $fields['submit'] = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'cloud-upload',
            'type' => 'submit',
            'offset' => 3
        ))->removeDecorator('Label');

        $this->addDisplayGroup($fields, 'main', array(
            'legend' => $this->_tlabel.'group_std',
        ));
    }

}