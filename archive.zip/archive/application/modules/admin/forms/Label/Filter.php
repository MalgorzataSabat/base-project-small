<?php
/**
 * Created by JetBrains PhpStorm.
 * User: skotar
 * Date: 08.09.2013
 * Time: 12:55
 * To change this template use File | Settings | File Templates.
 */

class Admin_Form_Label_Filter extends Base_Form_Filter {

    protected $_tabColumnOn = false;


    protected $_fieldsDisplay   = array(
        'type', 'label', 'value'
    );

    public function init()
    {
        $labelTypeOptions = array('' => '') + Label::getTypes();
        $this->_searchElements['type'] = $this->createElement('select', 'type', array(
            'label' => $this->_tlabel.'type',
            'multiOptions' => $labelTypeOptions,
        ));

        $this->_searchElements['label'] = $this->createElement('text', 'label', array(
            'label' => $this->_tlabel.'label',
        ));

        $this->_searchElements['value'] = $this->createElement('text', 'value', array(
            'label' => $this->_tlabel.'value',
        ));


        $moduleList = Base_Module::getModules();
        $moduleOptions = array();
        foreach($moduleList as $module){
            $moduleOptions[$module] = $this->getView()->translate('module_name-' . $module);
        }
        asort($moduleOptions);
        $moduleOptions = array('' => '', 'empty' => $this->getView()->translate('module_name-empty')) + $moduleOptions;

        $this->_searchElements['_module'] = $this->createElement('select', '_module', array(
            'label' => $this->_tlabel.'module',
            'multiOptions' => $moduleOptions,
        ));

        $this->_searchElements['date'] = $this->createElement('search_Date', 'date', array(
            'label' => $this->_tlabel . 'date',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));
    }
}