<?php

class Admin_Form_Setting extends Base_Form_Horizontal
{

    protected $_belong_to = 'Admin_Form_Setting';

    protected $_tlabel = 'admin_form_setting_';

    protected $_type;

    protected $_definitions = array(
        'email.bcc' => array('validators' => 'EmailAddress'),
        'email.cc' => array('validators' => 'EmailAddress'),
        'email.cron_on' => array('type' => 'checkbox'),
        'email.from' => array('validators' => 'EmailAddress', 'required' => true),
        'email.password' => array('type' => 'text', 'required' => true),
        'email.send_on' => array('type' => 'checkbox'),
        'email.smtp_on' => array('type' => 'checkbox'),
        'email.ssl' => array('type' => 'select', 'multiOptions' => array('' => '', 'ssl' => 'ssl', 'tls' => 'tls') ),
        'email.to' => array('validators' => 'EmailAddress', 'required' => true),
        'email.transporter' => array('required' => true),
        'email.user' => array('required' => true),
        'system.script_head_begin' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
        'system.script_head_end' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
        'system.script_body_begin' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
        'system.script_body_end' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
        'system.robots' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
        'system.locale' => array('type' => 'select'),
        'system.log_on' => array('type' => 'checkbox'),
        'user.support_many_emails' => array('type' => 'text'),
        'news.comments' => array('type' => 'checkbox'),
        'news.category_on' => array('type' => 'checkbox'),
        'shop.sort_products' => array('type' => 'checkbox'),
        'shop.payment_cod_cost_on' => array('type' => 'checkbox'),
        'shop.insert_price_as_net' => array('type' => 'checkbox'),
        'shop.discount_on' => array('type' => 'checkbox'),
        'shop.lightbox_category_on' => array('type' => 'checkbox'),
        'address.id_country_default' => array('type' => 'select', 'select2' => true),
        'address.on_field_country' => array('type' => 'checkbox'),
        'box.wysiwyg_on' => array('type' => 'checkbox'),
        'calendar.min_time' => array('description' => 'Format: hh:mm:ss'),
        'calendar.max_time' => array('description' => 'Format: hh:mm:ss'),
        'calendar.weekends_on' => array('type' => 'checkbox'),
        'auth.form_captcha_on' => array('type' => 'checkbox'),
        'user.edit_dashboard_on' => array('type' => 'checkbox'),
        'slider.wysiwyg_on' => array('type' => 'checkbox'),
        'user.manage_company' => array('type' => 'checkbox'),
        'facebook.appJavaScript' => array('type' => 'textarea', 'style' => 'width: 500px; height: 150px;'),
    );

    /**
     * @var Doctrine_Collection
     */
    protected $_settings;


    protected function setType($type)
    {
        $this->_type = $type;
    }

    public function init()
    {
        if($this->_type == 'system'){
            $this->_definitions['system.locale']['multiOptions'] = Base_I18n::getLocaleList();
        }
        elseif($this->_type == 'address'){
            $provinceList = AddressCountry::getList();
            $provinceListOptions = array();
            foreach($provinceList as $v){
                $provinceListOptions[$v['id_country']] = $v['name'];
            }

            $this->_definitions['address.id_country_default']['multiOptions'] = $provinceListOptions;
        }

        $fields = array();

        $this->_settings = Doctrine_Query::create()
            ->from('Setting s')
            ->where('s.key LIKE ?', $this->_type.'.%')
            ->addWhere('s.key NOT LIKE ?', Setting::SETTING_FORM_CLASS . '.%')
            ->execute()
        ;

        foreach($this->_settings as $k => $v)
        {
            $field_name = str_replace('.', '__', $k);
            $field_type = isset($this->_definitions[$k]['type']) ? $this->_definitions[$k]['type'] : 'text';

            $label = str_replace('admin_form_setting_shop.form-name_', 'Formularz: ',$this->_tlabel.$k);
            $field_options = array(
                'label' => $label,
                'dimension' => 6,
                'filters' => array('StringTrim'),
                'value' => $v['value'],
                'size' => '9',
                'label-size' => '3'
            );

//            if($field_type == 'checkbox') $field_options['class'] = 'iCheck';

            if(isset($this->_definitions[$k]['validators'])){
                $validators = (array) $this->_definitions[$k]['validators'];
                foreach($validators as $v){
                    $field_options['validators'][] = array($v, true);
                }
                unset($this->_definitions[$k]['validators']);
            }

            if(isset($this->_definitions[$k]['multiOptions'])){
                $field_options['multiOptions'] = $this->_definitions[$k]['multiOptions'];
                $field_options['validators'][] = array('InArray', true, array(array_keys($this->_definitions[$k]['multiOptions'])));
                unset($this->_definitions[$k]['multiOptions']);
            }

            if(isset($this->_definitions[$k])){
                foreach($this->_definitions[$k] as $k => $v){
                    $field_options[$k] = $v;
                }
            }

            $fields[$field_name] = $this->createElement($field_type, $field_name, $field_options);
        }

        $this->addDisplayGroup($fields, 'main', array(
            'legend' => $this->_tlabel.'type_'.$this->_type,
        ));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));
    }


    protected function postIsValid($data)
    {
        $data = $this->getValues($this->getElementsBelongTo());
        foreach($data as $k => $v){
            $name = str_replace('__', '.', $k);
            $this->_settings[$name]->value = $v;
        }

        $this->_settings->save();

        return true;
    }
}