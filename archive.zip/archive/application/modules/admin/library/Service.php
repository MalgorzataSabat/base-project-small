<?php

class Admin_Service
{
    protected $_serviceFrom = 1;
    protected $_serviceTo = null;

    protected $_users = array();
    protected $_dictionary = array();
    protected $_clients = array();
    protected $_person = array();
    protected $_project = array();
    protected $_stage = array();
    protected $_industry = array();
    protected $_department = array();
    protected $_template = array();
    protected $_quickmail = array();
    protected $_quickmailEmail = array();
    protected $_invoice = array();
    protected $_task = array();

    public function create($serviceTo)
    {
        $this->_serviceTo = $serviceTo;

        if(!$this->_serviceTo){
            throw new Exception('ID Service To is required');
        }

//        $this->_createUsers();
        $this->_createDictionary();
//        $this->_createClients();
//        $this->_createPersons();
//        $this->_createProject();
//        $this->_createStage();
//        $this->_createIndustry();
//        $this->_createDepartment();
//        $this->_createTemplate();
//        $this->_createQuickmail();
//        $this->_createInvoice();
//        $this->_createTask();
    }

    private function _createTask()
    {
        $taskList =  Doctrine_Query::create()
            ->from('Task o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($taskList as $v) {
            $task = new Task();
            $task->fromArray($v);
            $task->id_task = null;

            $task->id_service = $this->_serviceTo;
            $task->id_task_parent = null;

            if($v['id_status']){
                $task->id_status = $this->_dictionary[$v['id_status']];
            }

            if($v['id_user_created']){
                $task->id_user_created = $this->_users[$v['id_user_created']];
            }

            if($v['id_client']){
                $task->id_client = $this->_clients[$v['id_client']];
            }

            if($v['id_project']){
                $task->id_project = $this->_project[$v['id_project']];
            }

            if($v['id_user']){
                $task->id_user = $this->_users[$v['id_user']];
            }

            $task->save();

            $this->_task[$v['id_task']] = $task['id_task'];
        }


        foreach($this->_task as $id_old => $id_new){
            $taskTimeList =  Doctrine_Query::create()
                ->from('TaskTimeEnity o')
                ->where('o.id_task = ?', $id_old)
                ->fetchArray();

            foreach($taskTimeList as $v){
                $taskTimeEnity = new TaskTimeEnity();
                $taskTimeEnity->fromArray($v);
                $taskTimeEnity->id_task_time_enity = null;

                if($v['id_task']){
                    $taskTimeEnity->id_task = $this->_task[$v['id_task']];
                }

                if($v['id_user_created']){
                    $taskTimeEnity->id_user_created = $this->_users[$v['id_user_created']];
                }

                if($v['id_user']){
                    $taskTimeEnity->id_user = $this->_users[$v['id_user']];
                }

                $taskTimeEnity->save();
            }
        }

    }

    private function _createInvoice()
    {
        $invoiceList =  Doctrine_Query::create()
            ->from('Invoice o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($invoiceList as $v) {
            $invoice = new Invoice();
            $invoice->fromArray($v);
            $invoice->id_invoice = null;

            $invoice->id_service = $this->_serviceTo;

            if($v['id_user_created']){
                $invoice->id_user_created = $this->_users[$v['id_user_created']];
            }

            if($v['id_client']){
                $invoice->id_client = $this->_clients[$v['id_client']];
            }

            if($v['id_payment_method']){
                $invoice->id_payment_method = $this->_dictionary[$v['id_payment_method']];
            }

            if($v['id_payment_term_day']){
                $invoice->id_payment_term_day = $this->_dictionary[$v['id_payment_term_day']];
            }

            if($v['id_currency']){
                $invoice->id_currency = $this->_dictionary[$v['id_currency']];
            }

            $invoice->save();

            $this->_invoice[$v['id_invoice']] = $invoice['id_invoice'];
        }


        foreach($this->_invoice as $id_old => $id_new){
            $invoiceItemList =  Doctrine_Query::create()
                ->from('InvoiceItem o')
                ->where('o.id_invoice = ?', $id_old)
                ->fetchArray();

            foreach($invoiceItemList as $v){
                $invoiceItem = new InvoiceItem();
                $invoiceItem->fromArray($v);
                $invoiceItem->id_invoice_item = null;

                if($v['id_invoice']){
                    $invoiceItem->id_invoice = $this->_invoice[$v['id_invoice']];
                }

                if($v['id_unit']){
                    $invoiceItem->id_unit = $this->_dictionary[$v['id_unit']];
                }

                if($v['id_tax']){
                    $invoiceItem->id_tax = $this->_dictionary[$v['id_tax']];
                }

                $invoiceItem->save();
            }

            $invoiceRelatedList =  Doctrine_Query::create()
                ->from('InvoiceRelated o')
                ->where('o.id_invoice = ?', $id_old)
                ->fetchArray();

            foreach($invoiceRelatedList as $v){
                $invoiceRelated = new InvoiceRelated();
                $invoiceRelated->fromArray($v);
                $invoiceRelated->id_invoice_related = null;

                if($v['id_invoice']){
                    $invoiceRelated->id_invoice = $this->_invoice[$v['id_invoice']];
                }

                if($v['id_invoice_parent']){
                    $invoiceRelated->id_invoice_parent = $this->_invoice[$v['id_invoice_parent']];
                }

                $invoiceRelated->save();
            }

            $invoiceTaxList =  Doctrine_Query::create()
                ->from('InvoiceTax o')
                ->where('o.id_invoice = ?', $id_old)
                ->fetchArray();

            foreach($invoiceTaxList as $v){
                $invoiceTax = new InvoiceTax();
                $invoiceTax->fromArray($v);
                $invoiceTax->id_invoice_tax = null;

                if($v['id_invoice']){
                    $invoiceTax->id_invoice = $this->_invoice[$v['id_invoice']];
                }

                if($v['id_tax']){
                    $invoiceTax->id_tax = $this->_dictionary[$v['id_tax']];
                }

                $invoiceTax->save();
            }
        }
    }

    private function _createQuickmail()
    {
        $list = Doctrine_Query::create()
            ->from('Quickmail o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $quickmail = new Quickmail();
            $quickmail->fromArray($v);
            $quickmail->id_quickmail = null;
            $quickmail->id_service = $this->_serviceTo;
            $quickmail->hash = Base::getHash();

            if($v['id_user']){
                $quickmail->id_user = $this->_users[$v['id_user']];
            }

            if($v['id_user_created']){
                $quickmail->id_user_created = $this->_users[$v['id_user_created']];
            }

            $quickmail->save();

            $this->_quickmail[$v['id_quickmail']] = $quickmail['id_quickmail'];
        }


        $listEmail = Doctrine_Query::create()
            ->from('QuickmailEmail o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($listEmail as $v) {
            if(!isset($this->_quickmail[$v['id_quickmail']])){
                continue;
            }

            $quickmailEmail = new QuickmailEmail();
            $quickmailEmail->fromArray($v);
            $quickmailEmail->id_quickmail_email = null;
            $quickmailEmail->id_service = $this->_serviceTo;

            if($v['id_quickmail']){
                $quickmailEmail->id_quickmail = $this->_quickmail[$v['id_quickmail']];
            }

            $quickmailEmail->save();

            $this->_quickmailEmail[$v['id_quickmail']] = $quickmailEmail['id_quickmail'];
        }
    }

    private function _createTemplate()
    {
        $list = Doctrine_Query::create()
            ->from('Template o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $template = new Template();
            $template->fromArray($v);
            $template->id_template = null;
            $template->id_service = $this->_serviceTo;

            if($v['id_user_created']){
                $template->id_user_created = $this->_users[$v['id_user_created']];
            }

            $template->save();

            $this->_template[$v['id_template']] = $template['id_template'];
        }
    }

    private function _createDepartment()
    {
        $list = Doctrine_Query::create()
            ->from('Department o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $department = new Department();
            $department->fromArray($v);
            $department->id_department = null;
            $department->id_service = $this->_serviceTo;

            if($v['id_user_created']){
                $department->id_user_created = $this->_users[$v['id_user_created']];
            }

            $department->save();

            $this->_department[$v['id_department']] = $department['id_department'];
        }
    }

    private function _createIndustry()
    {
        $list = Doctrine_Query::create()
            ->from('Industry o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->addWhere('o.id_parent IS NULL')
            ->fetchArray();

        foreach($list as $v) {
            $industry = new Industry();
            $industry->fromArray($v);
            $industry->id_industry = null;
            $industry->id_service = $this->_serviceTo;

            $industry->save();

            $this->_industry[$v['id_industry']] = $industry['id_industry'];
        }
    }

    private function _createStage()
    {
        $list = Doctrine_Query::create()
            ->from('Stage o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $stage = new Stage();
            $stage->fromArray($v);
            $stage->id_stage = null;

            $stage->id_service = $this->_serviceTo;
            $stage->hash = Base::getHash();

            if($v['id_project']){
                $stage->id_project = $this->_project[$v['id_project']];
            }

            if($v['id_user_created']){
                $stage->id_user_created = $this->_users[$v['id_user_created']];
            }

            $stage->save();

            $this->_stage[$v['id_stage']] = $stage['id_stage'];
        }
    }

    private function _createProject()
    {
        $list = Doctrine_Query::create()
            ->from('Project o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $project = new Project();
            $project->fromArray($v);
            $project->id_project = null;

            $project->id_service = $this->_serviceTo;
            if($v['id_user_created']){
                $project->id_user_created = $this->_users[$v['id_user_created']];
            }
            if($v['id_status']){
                $project->id_status = $this->_dictionary[$v['id_status']];
            }
            if($v['id_client']){
                $project->id_client = $this->_clients[$v['id_client']];
            }

            $project->save();

            $this->_project[$v['id_project']] = $project['id_project'];
        }
    }

    private function _createPersons()
    {
        $list = Doctrine_Query::create()
            ->from('Person o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $person = new Person();
            $person->fromArray($v);
            $person->id_person = null;

            $person->id_service = $this->_serviceTo;
            if($v['id_user_created']){
                $person->id_user_created = $this->_users[$v['id_user_created']];
            }
            if($v['id_status']){
                $person->id_status = $this->_dictionary[$v['id_status']];
            }
            if($v['id_client']){
                $person->id_client = $this->_clients[$v['id_client']];
            }

            $person->save();

            $this->_person[$v['id_person']] = $person['id_person'];
        }
    }

    private function _createClients()
    {
        $list = Doctrine_Query::create()
            ->from('Client o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($list as $v) {
            $client = new Client();
            $client->fromArray($v);
            $client->id_client = null;

            $client->id_service = $this->_serviceTo;
            if($v['id_user_created']){
                $client->id_user_created = $this->_users[$v['id_user_created']];
            }
            if($v['id_status']){
                $client->id_status = $this->_dictionary[$v['id_status']];
            }

            $client->save();

            $this->_clients[$v['id_client']] = $client['id_client'];
        }
    }

    private function _createDictionary()
    {
        $dictionaryList = Doctrine_Query::create()
            ->from('Dictionary o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();

        foreach($dictionaryList as $v){
            $dictionary = new Dictionary();
            $dictionary->id_service = $this->_serviceTo;
            $dictionary->object = $v['object'];
            $dictionary->name = $v['name'];
            $dictionary->order = $v['order'];
            $dictionary->is_closed = $v['is_closed'];
            $dictionary->is_default = $v['is_default'];
            $dictionary->class = $v['class'];
            $dictionary->style = $v['style'];
            $dictionary->data = $v['data'];

            $dictionary->save();

            $this->_dictionary[$v['id_dictionary']] = $dictionary['id_dictionary'];
        }
    }

    private function _createUsers()
    {
        $userList = Doctrine_Query::create()
            ->from('User o')
            ->where('o.id_service = ?', $this->_serviceFrom)
            ->fetchArray();


        foreach($userList as $value){
            $user = new User();
            $user->id_service = $this->_serviceTo;
            $user->role = $value['role'];
            $user->email = $value['email'];
            $user->setPassword('Demo1@3-17');
            $user->name = $value['name'];
            $user->surname = $value['surname'];
            $user->id_profile_image = $value['id_profile_image'];
            $user->id_language = $value['id_language'];
            $user->locale = $value['locale'];
            $user->phone = $value['phone'];
            $user->street = $value['street'];
            $user->post_code = $value['post_code'];
            $user->city = $value['city'];

            $userEmail = new UserEmail();
            $userEmail->email = $value['email'];
            $userEmail->is_active = 1;
            $user->Emails->add($userEmail);

            $user->save();

            $this->_users[$value['id_user']] = $user['id_user'];
        }
    }


}