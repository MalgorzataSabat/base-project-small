<?php
/**
 * Created by PhpStorm.
 * User: RisenetKomp
 * Date: 2014-11-24
 * Time: 13:56
 */

class Admin_Label_Diff extends Admin_Label {

    public function start()
    {
        echo "\n* Missing import: ";

        if(empty($this->_missing_import))
        {
            echo "none";
        }

        foreach($this->_missing_import as $key => $files)
        {
            echo "\n- $key :";
            foreach($files as $file)
            {
                echo "\n$file;";
            }
        }

        echo "\n\n* Missing file in server:\n";

        if(empty($this->_missing_file))
        {
            echo "none";
        }

        foreach($this->_missing_file as $key => $files)
        {
            echo "\n-$key :";
            foreach($files as $file)
            {
                echo "\n$file;";
            }
        }
    }

} 