<?php

class Admin_Label_Import extends Admin_Label {

    public function start($moduleImport = NULL, $fileImport = NULL)
    {
        $count_ok = 0;
        $conn = Doctrine_Manager::connection();

        $files = $this->getFilesToInput($moduleImport, $fileImport);

        if (!in_array($moduleImport, array_keys($this->controllerDirectory)) && !empty($moduleImport)) {
            echo "\n-> Module '$moduleImport' was not found [ERROR]";
            echo "\n=========================================\n";
        }

        if($files)
        {
            foreach($files as $module => $file){

                foreach($file as $f)
                {
                    $file_path = $this->_frontController->getModuleDirectory($module).DS.'data'.DS.'translation'.DS.$f;

                    $fp = fopen($file_path, "r");
                    while (($data = fgetcsv($fp,null,';')) !== false){
                        if(count($data) !== 5) continue;
                        foreach($data as $v) if(empty($v)) continue;

                        $label = Doctrine_Query::create()->from('Label l')
                            ->innerJoin('l.Translations t')
                            ->where('label = ? AND t.id_language = ? AND l.type = ?', array($data[0], $data[1], $data[2]))
                            ->fetchOne();

                        if(!$label){
                            $label = new Label();
                            $label->setLabel($data[0]);
                            $label->setType($data[2]);
                        }

                        $label->setFromImport(1);
                        $label->setValue($data[3], $data[1]);
                        $label->setModule($data[4]);
                        $label->save();
                    }
                    fclose($fp);

                    $databaseChangelog = new DatabaseChangelog();
                    $databaseChangelog->id_database_changelog = $f;
                    $databaseChangelog->module = $module;
                    $databaseChangelog->type = DatabaseChangelog::TYPE_TRANSLATIONS;
                    $databaseChangelog->save();

                    echo "\n-> Execute translation file: $module - $f [OK]";
                    $count_ok++;
                }
            }

            echo "\n\n* Add $count_ok translation file\n";

            if($moduleImport != NULL)
            {
                echo "* Update last translation time in database.\n";
                Doctrine_Query::create()
                    ->update('DatabaseChangelog')
                    ->set('executed_at', 'now()')
                    ->addWhere('id_database_changelog = ?', DatabaseChangelog::DB_CHANGELOG_IMPORT)
                    ->execute();
            }
            Base_Cache::clean();
        }
        elseif (!$files && $fileImport)
        {
            echo "\n-> File '$fileImport' was not found [ERROR]";
            echo "\n=========================================\n";
        }
        else
        {
            echo "\n* There is nothing to import\n";
        }
    }
} 