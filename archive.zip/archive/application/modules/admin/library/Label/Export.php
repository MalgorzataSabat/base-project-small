<?php

class Admin_Label_Export extends Admin_Label {

    public function start($module = NULL)
    {
        if ($module == NULL) {
            $modules = array_keys($this->controllerDirectory);
        } else {
            if (!in_array($module, array_keys($this->controllerDirectory))) {
                echo "\n-> Module '$module' was not found [ERROR]";
                echo "\n=========================================";
                exit;
            }
            $modules = array($module);
        }

        $files = $this->getTranslationFileArray();
        $last = array();

        foreach ($files as $key => $file) {
            $last[$key] = 0;
            if (is_array($file)) {
                foreach ($file as $v) {
                    $v = (int)$v;
                    if ($last[$key] < $v) {
                        $last[$key] = $v;
                    }
                }
            }
        }

        $last_export = DatabaseChangelog::find(DatabaseChangelog::DB_CHANGELOG_EXPORT);

        foreach ($modules as $module) {
            $labelList = Label::getQuery();
            if ($module == 'default') {
                $labelList->addWhere("(o.module = '' OR o.module = ?)", $module);
            } else {
                $labelList->addWhere('o.module = ?', $module);
            }
            $labelList->addWhere('modified_at > ?', $last_export['executed_at']);
            $labelList->addWhere('o.from_import = 0');
            $result = $labelList->execute();

            $last[$module] = isset($last[$module]) ? $last[$module] : 0;
            $last[$module]++;

            if (count($result) > 0) {
                $data_dir = $this->_frontController->getModuleDirectory($module) . DS . 'data';
                if (!is_dir($data_dir)) {
                    Base::createDir($data_dir);
                }
                if (!is_dir($data_dir . DS . 'translation')) {
                    Base::createDir($data_dir . DS . 'translation');
                }

                $file_name = str_pad($last[$module], 4, "0", STR_PAD_LEFT) . '.' . date('YmdHis') . '.csv';

                $file_path = $data_dir . DS . 'translation' . DS . $file_name;
                $fp = fopen($file_path, 'w');

                foreach ($result as $label) {
                    /** @var Label $label */
                    $row = array(
                        'label' => $label['label'],
                        'id_language' => $label['id_language'],
                        'type' => $label['type'],
                        'value' => $label['value'],
                        'module' => $label['module']
                    );
                    fputcsv($fp, $row, ';');
                }
                echo "\n* Module: " . $module . "\n";
                echo "* Labels export: " . count($result) . "\n";
                echo "* Save file: " . $file_name . "\n";
                fclose($fp);

                $databaseChangelog = new DatabaseChangelog();
                $databaseChangelog->id_database_changelog = $file_name;
                $databaseChangelog->module = $module;
                $databaseChangelog->type = DatabaseChangelog::TYPE_TRANSLATIONS;
                $databaseChangelog->save();
            }
        }

        if($module != NULL)
        {
            Doctrine_Query::create()
                ->update('DatabaseChangelog')
                ->set('executed_at', 'now()')
                ->addWhere('id_database_changelog = ?', DatabaseChangelog::DB_CHANGELOG_EXPORT)
                ->execute();
        }
    }
} 