<?php

class Admin_Label {

    protected $_frontController;

    protected $_missing_import;
    protected $_missing_file;

    protected $controllerDirectory;

    public function __construct()
    {
        $this->_frontController = Zend_Controller_Front::getInstance();

        $files = $this->getTranslationFileArray();
        $database = $this->getDatalog();

        $this->_missing_import = $this->arrayRecursiveDiff($files, $database);
        $this->_missing_file = $this->arrayRecursiveDiff($database, $files);

        $this->controllerDirectory = $this->_frontController->getControllerDirectory();
    }

    protected function getTranslationFileArray()
    {
        $modules = $this->_frontController->getControllerDirectory();

        $files = array();

        foreach($modules as $key => $module)
        {
            $files_path = glob($this->_frontController->getModuleDirectory($key).DS.'data'.DS.'translation'.DS.'*.csv');

            foreach($files_path as $path)
            {
                if (file_exists($path)) {
                    $data = explode(DS, $path);
                    $data = $data[count($data)-1];
                    $files[$key][$data] = $data;
                }
            }
        }
        return $files;
    }

    protected function arrayRecursiveDiff($aArray1, $aArray2) {
        $aReturn = array();

        foreach ($aArray1 as $mKey => $mValue) {
            if (array_key_exists($mKey, $aArray2)) {
                if (is_array($mValue)) {
                    $aRecursiveDiff = self::arrayRecursiveDiff($mValue, $aArray2[$mKey]);
                    if (count($aRecursiveDiff)) { $aReturn[$mKey] = $aRecursiveDiff; }
                } else {
                    if ($mValue != $aArray2[$mKey]) {
                        $aReturn[$mKey] = $mValue;
                    }
                }
            } else {
                $aReturn[$mKey] = $mValue;
            }
        }

        return $aReturn;
    }

    protected function getDatalog()
    {
        $result = Doctrine_Query::create()
            ->from('DatabaseChangelog')
            ->addWhere('type = ?', DatabaseChangelog::TYPE_TRANSLATIONS)
            ->orderBy('module, executed_at ASC')
            ->fetchArray();

        $data = array();
        foreach($result as $v) {
            $data[$v['module']][$v['id_database_changelog']] = $v['id_database_changelog'];
        }

        return $data;
    }

    protected function getFilesToInput($module = NULL,$file = NULL)
    {
        $files = $this->getMissingImportFiles();

        $m = array();
        $f = array();

        if($module)
        {
            if(in_array($module,array_keys($files)))
            {
                $m[] = $module;
                if(!$file)
                {
                    $f[] = $files[$module];
                }
                else
                {
                    foreach($files as $mx => $fx)
                    {
                        if($mx != $module) continue;

                        foreach($fx as $v)
                        {
                            if($file == $v)
                            {
                                $f[] = array($v);
                            }
                            elseif(strlen($file) <= 4)
                            {
                                $file = str_pad($file, 4, "0", STR_PAD_LEFT);
                                $cut = substr($v, 0, 4);
                                if ($file != $cut) continue;
                                $f[] = array($v);
                            }
                        }
                    }
                }
            }
            if(!empty($f) && !empty($m))
            {
                $files = array_combine($m,$f);
            }
            else
            {
                $files = 0;
            }
        }

        return $files;
    }

    protected function getMissingImportFiles()
    {
        $m = array();
        $f = array();

        foreach($this->_missing_import as $module => $files)
        {
            $m[] = $module;
            $f[] = $files;
        }
        return $files = array_combine($m,$f);
    }

} 