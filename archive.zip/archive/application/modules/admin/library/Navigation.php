<?php


class Admin_Navigation
{

    private $_pages = null;

    /**
     * Singleton instance
     *
     * @var Admin_Navigation
     */
    protected static $_instance = null;


    /**
     * Singleton pattern implementation makes "new" unavailable
     *
     * @return void
     */
    protected function __construct() {}

    /**
     * Returns an instance of Admin_Navigation
     *
     * Singleton pattern implementation
     *
     * @return Admin_Navigation
     */
    public static function getInstance()
    {
        if ( null === self::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Returns an instance of Admin_Navigation
     *
     * Singleton pattern implementation
     *
     * @return Admin_Navigation
     */
    public static function _()
    {
        return self::getInstance();
    }


    public function getPages($namspace = null)
    {
        if(null === $this->_pages){
            $acl = Base_Acl::getInstance();
            Zend_View_Helper_Navigation_HelperAbstract::setDefaultAcl($acl);
            $pages = array();
            $frontController = Zend_Controller_Front::getInstance();
            $modulesEnabled = $frontController->getControllerDirectory();

            foreach($modulesEnabled as $module => $path){
                $filename = $frontController->getModuleDirectory( $module ) . DS . 'config' . DS . 'navigation.php';
                if(file_exists($filename)){
                    $pages_module = include $filename;
                    $pages = array_merge_recursive($pages, $pages_module);
                }
            }

            $this->_pages = $pages['admin'];
        }

        if(null !== $namspace){
            return (array) @$this->_pages[$namspace];
        }else{
            return $this->_pages;
        }
    }

    public function setPages(array $pages, $namespace = null)
    {
        if ( null !== $namespace ) {
            $this->_pages[$namespace] = $pages;
        } else {
            $this->_pages = $pages;
        }
    }

    public function getContainer($namspace = null)
    {
        $container = new Zend_Navigation();
        $nav = new Navigation_Service();
        $container->addPages($nav->getNavigation($namspace));
        //$container->addPages($this->getPages($namspace));

        return $container;
    }




}