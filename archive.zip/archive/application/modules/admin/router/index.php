<?php
$router = Zend_Controller_Front::getInstance()->getRouter();


$router->addRoute('admin_mass-action', new Zend_Controller_Router_Route(
    '/:module/mass/:controller',
    array(
        'controller' => 'admin',
        'action' => 'mass',
    ),
    array(
        'controller' => '.*',
        'module' => '.*'
    )
));

$router->addRoute( 'admin_save-query', new Zend_Controller_Router_Route(
    '/:module/@save-query',
    array(
        'controller' => 'admin',
        'action' => 'save-query',
    ),
    array(
        'modele' => '.*'
    )
) );



$router->addRoute('admin_cms-share-elements', new Zend_Controller_Router_Route(
    '/@cms-share-elements',
    array(
        'module' => 'admin',
        'controller' => 'index',
        'action' => 'cms-share-elements'
    )
));



Zend_Controller_Front::getInstance()->setRouter($router);


