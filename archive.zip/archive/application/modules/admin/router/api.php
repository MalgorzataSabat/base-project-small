<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('api', new Zend_Controller_Router_Route(
    '/@api',
    array(
        'module' => 'admin',
        'controller' => 'api',
        'action' => 'index'
    )
));

$router->addRoute('api_new', new Zend_Controller_Router_Route(
    '/@api/@new',
    array(
        'module' => 'admin',
        'controller' => 'api',
        'action' => 'new'
    )
));

$router->addRoute('api_edit', new Zend_Controller_Router_Route(
    '/@api/@edit/:id_api_service',
    array(
        'module' => 'admin',
        'controller' => 'api',
        'action' => 'edit'
    ),
    array(
        'id_api_service' => '\d+'
    )
));

$router->addRoute('api_show', new Zend_Controller_Router_Route(
    '/@api/@show/:id_api_service',
    array(
        'module' => 'admin',
        'controller' => 'api',
        'action' => 'show'
    ),
    array(
        'id_api_service' => '\d+'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);

