<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_session', new Zend_Controller_Router_Route(
    '/@session',
    array(
        'module' => 'admin',
        'controller' => 'session',
        'action' => 'index',
    )
));

$router->addRoute('admin_session_delete', new Zend_Controller_Router_Route(
    '/@session/@delete/:id',
    array(
        'module' => 'admin',
        'controller' => 'session',
        'action' => 'delete',
    ),
    array(
        'id' => '.*'
    )
));

$router->addRoute('admin_session_delete-all', new Zend_Controller_Router_Route(
    '/@session/@delete-all/:with_me',
    array(
        'module' => 'admin',
        'controller' => 'session',
        'action' => 'delete-all',
        'with_me' => 1
    ),
    array(
        'with_me' => '(0|1)'
    )
));



Zend_Controller_Front::getInstance()->setRouter($router);


