<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_email_send_index', new Zend_Controller_Router_Route(
    '/@email-send',
    array(
        'module' => 'admin',
        'controller' => 'email-send',
        'action' => 'index',
    )
));

$router->addRoute('admin_email_send_show', new Zend_Controller_Router_Route(
    '/@email-send/@show/:id_email_send',
    array(
        'module' => 'admin',
        'controller' => 'email-send',
        'action' => 'show',
    ),
    array(
        'id_email_send' => '\d+'
    )
));

$router->addRoute('admin_email_send_show_html', new Zend_Controller_Router_Route(
    '/@email-send/@show-html/:id_email_send',
    array(
        'module' => 'admin',
        'controller' => 'email-send',
        'action' => 'show-html',
    ),
    array(
        'id_email_send' => '\d+'
    )
));

$router->addRoute('admin_email_send_send', new Zend_Controller_Router_Route(
    '/@email-send/@send/:id_email_send',
    array(
        'module' => 'admin',
        'controller' => 'email-send',
        'action' => 'send',
    ),
    array(
        'id_email_send' => '\d+'
    )
));

$router->addRoute('admin_email_send_delete', new Zend_Controller_Router_Route(
    '/@email-send/@delete/:id_email_send',
    array(
        'module' => 'admin',
        'controller' => 'email-send',
        'action' => 'delete',
    ),
    array(
        'id_email_send' => '\d+'
    )
));

$router->addRoute('admin_email_send_mass_delete', new Zend_Controller_Router_Route(
    '/@email-send/@mass-delete',
    array(
        'module' => 'admin',
        'controller' => 'email-send-mass',
        'action' => 'delete',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
