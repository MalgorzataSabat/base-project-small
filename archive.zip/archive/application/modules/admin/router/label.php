<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_label', new Zend_Controller_Router_Route(
    '/@label',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'index',
    )
));

$router->addRoute('admin_label_new', new Zend_Controller_Router_Route(
    '/@label/@new',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'new',
    )
));

$router->addRoute('admin_label_edit', new Zend_Controller_Router_Route(
    '/@label/@edit/:id_label',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'edit',
    ),
    array(
        'id_label' => '\d+'
    )
));

$router->addRoute('admin_label_delete', new Zend_Controller_Router_Route(
    '/@label/@delete/:id_label',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'delete',
    ),
    array(
        'id_label' => '\d+'
    )
));

$router->addRoute('admin_label_export', new Zend_Controller_Router_Route(
    '/@label/@export',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'export',
    )
));

$router->addRoute('admin_label_import', new Zend_Controller_Router_Route(
    '/@label/@import',
    array(
        'module' => 'admin',
        'controller' => 'label',
        'action' => 'import',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


