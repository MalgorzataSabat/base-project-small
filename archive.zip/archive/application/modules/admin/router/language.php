<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_language', new Zend_Controller_Router_Route(
    '/@languages',
    array(
        'module' => 'admin',
        'controller' => 'language',
        'action' => 'index',
    )
));

$router->addRoute('admin_language_new', new Zend_Controller_Router_Route(
    '/@language/@new',
    array(
        'module' => 'admin',
        'controller' => 'language',
        'action' => 'new',
    )
));

$router->addRoute('admin_language_edit', new Zend_Controller_Router_Route(
    '/@language/@edit/:id_language',
    array(
        'module' => 'admin',
        'controller' => 'language',
        'action' => 'edit',
    ),
    array(
        'id_language' => '\d+'
    )
));

$router->addRoute('admin_language_delete', new Zend_Controller_Router_Route(
    '/@language/@delete/:id_language',
    array(
        'module' => 'admin',
        'controller' => 'language',
        'action' => 'delete',
    ),
    array(
        'id_language' => '\d+'
    )
));



Zend_Controller_Front::getInstance()->setRouter($router);


