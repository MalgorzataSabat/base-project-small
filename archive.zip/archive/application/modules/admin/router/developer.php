<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_developer', new Zend_Controller_Router_Route(
    '/@developer',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'index',
    )
));

$router->addRoute('admin_developer_create-service', new Zend_Controller_Router_Route(
    '/developer/create-service/:id_service_to',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'create-service'
    ),
    array(
        'id_service_to' => '\d+'
    )
));


$router->addRoute('admin_developer_test-list', new Zend_Controller_Router_Route(
    '/@developer/test-list',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'test-list',
    )
));

$router->addRoute('admin_developer_test-form', new Zend_Controller_Router_Route(
    '/@developer/test-form',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'test-form',
    )
));


$router->addRoute('admin_developer_adminer', new Zend_Controller_Router_Route(
    '/@developerer',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'adminer',
    )
));

$router->addRoute('admin_developer_start-adminer', new Zend_Controller_Router_Route(
    '/@developer/@start-adminer',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'start-adminer',
    )
));

$router->addRoute('admin_developer_create-layouts-from-base', new Zend_Controller_Router_Route(
    '/@developer/@create-layouts-from-base',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'create-layouts-from-base'
    )
));

$router->addRoute('admin_developer_create-layout', new Zend_Controller_Router_Route(
    '/@developer/@create-layout',
    array(
        'module' => 'admin',
        'controller' => 'developer',
        'action' => 'create-layout'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


