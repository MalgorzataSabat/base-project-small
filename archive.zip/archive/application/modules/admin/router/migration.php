<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_migration_acl-resource', new Zend_Controller_Router_Route(
    '/migration/acl-resource',
    array(
        'module' => 'admin',
        'controller' => 'migration',
        'action' => 'acl-resource',
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);


