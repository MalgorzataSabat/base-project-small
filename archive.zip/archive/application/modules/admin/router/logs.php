<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_logs_index', new Zend_Controller_Router_Route(
    '/@logs',
    array(
        'module' => 'admin',
        'controller' => 'logs',
        'action' => 'index',
    )
));

$router->addRoute('admin_logs_logs', new Zend_Controller_Router_Route(
    '/@logs/@file/:file',
    array(
        'module' => 'admin',
        'controller' => 'logs',
        'action' => 'logs',
    ),
    array(
        'file' => '(.*)',
    )
));

$router->addRoute('admin_logs_delete', new Zend_Controller_Router_Route(
    '/@logs/@delete/:file',
    array(
        'module' => 'admin',
        'controller' => 'logs',
        'action' => 'delete',
    ),
    array(
        'file' => '(.*)',
    )
));


$router->addRoute('admin_logs_user', new Zend_Controller_Router_Route(
    '/@logs/@user',
    array(
        'module' => 'admin',
        'controller' => 'logs',
        'action' => 'user',
    )
));



Zend_Controller_Front::getInstance()->setRouter($router);


