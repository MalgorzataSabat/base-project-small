<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_modules', new Zend_Controller_Router_Route(
    '/@modules',
    array(
        'module' => 'admin',
        'controller' => 'modules',
        'action' => 'index',
    )
));

$router->addRoute('admin_modules_show', new Zend_Controller_Router_Route(
    '/@modules/@show/:modulename',
    array(
        'module' => 'admin',
        'controller' => 'modules',
        'action' => 'show',
    ),
    array(
        'modulename' => '(.*)',
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);


