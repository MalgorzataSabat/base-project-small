<?php

$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('service_index', new Zend_Controller_Router_Route(
    '/_service',
    array(
        'module' => 'admin',
        'controller' => 'service',
        'action' => 'index'
    )
));

$router->addRoute('service_new', new Zend_Controller_Router_Route(
    '/_service/@new',
    array(
        'module' => 'admin',
        'controller' => 'service',
        'action' => 'new'
    )
));

$router->addRoute('service_edit', new Zend_Controller_Router_Route(
    '/_service/@edit/:id_service',
    array(
        'module' => 'admin',
        'controller' => 'service',
        'action' => 'edit'
    ), array(
        'id_service' => '\d+'
    )
));

$router->addRoute('service_show', new Zend_Controller_Router_Route(
    '/_service/@show/:id_service',
    array(
        'module' => 'admin',
        'controller' => 'service',
        'action' => 'show'
    ), array(
        'id_service' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);