<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_setting_clear-cache', new Zend_Controller_Router_Route(
    '/@setting/@clear-cache',
    array(
        'module' => 'admin',
        'controller' => 'setting',
        'action' => 'clear-cache',
    )
));

$router->addRoute('admin_setting_list', new Zend_Controller_Router_Route(
    '/@setting/@list',
    array(
        'module' => 'admin',
        'controller' => 'setting',
        'action' => 'list',
    )
));

$router->addRoute('admin_setting_edit', new Zend_Controller_Router_Route(
    '/@setting/@edit/:type',
    array(
        'module' => 'admin',
        'controller' => 'setting',
        'action' => 'edit',
    ),
    array(
        'type' => '.*'
    )
));

$router->addRoute('admin_setting_set_template', new Zend_Controller_Router_Route(
    '/@setting/@edit/@template/:name/:type',
    array(
        'module' => 'admin',
        'controller' => 'setting',
        'action' => 'set-template',
    ),
    array(
        'name' => '.*',
        'type' => '.*'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);


