<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('admin_cron', new Zend_Controller_Router_Route(
    '/@cron',
    array(
        'module' => 'admin',
        'controller' => 'cron',
        'action' => 'index',
    )
));

$router->addRoute('admin_cron_run', new Zend_Controller_Router_Route(
    '/@cron/@run/:id_cron',
    array(
        'module' => 'admin',
        'controller' => 'cron',
        'action' => 'run',
    ),
    array(
        'id_cron' => '\d+',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


