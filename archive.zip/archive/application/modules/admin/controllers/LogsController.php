<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Marek Skotarek
 * Date: 18.07.2013
 * Time: 20:15
 * To change this template use File | Settings | File Templates.
 */

class Admin_LogsController extends Base_Controller_Action
{
    private $_fileList;

    public function postDispatch()
    {
        $this->_fileList = scandir( APPLICATION_DATA . DS . 'logs/' );
        $this->view->fileList = $this->_fileList;

        parent::postDispatch();
    }

    public function indexAction()
    {

    }

    public function logsAction()
    {
        $dir = APPLICATION_DATA . DS . 'logs/';
        $fileName = $this->_getParam('file');
        $read = 2097152;

        if ( file_exists($dir.$fileName) ) {
            $size = filesize($dir.$fileName);
            $fromRead = ($size > $read) ? ($size - $read) : 0;
            $content = file_get_contents($dir.$fileName, null, null, $fromRead, $read);
            $this->view->content = $content;
            $this->view->title = $fileName;
            $this->view->size = $size;
        }
        $this->view->placeholder('page-title')->set($this->view->translate($fileName));
    }

    public function deleteAction()
    {
        $dir = APPLICATION_DATA . DS . 'logs/';
        $fileName = $this->_getParam('file');

        if ( file_exists($dir.$fileName) ){
            unlink($dir.$fileName);
        }

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'admin_logs_index');
    }
}