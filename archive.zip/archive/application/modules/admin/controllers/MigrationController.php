<?php

class Admin_MigrationController extends Base_Controller_Action
{

    /**
     * Action clear and create new ACL Resource with support parents
     * and create ACL Resource Items with relation do ACL Resource
     *
     * @date 2015-06-06
     *
     */
    public function aclResourceAction()
    {
        var_dump('Wczytywanie zasobów wyłaczone - wprowadzane są przez formularz ACL');
        exit();

        $loadResourceItem = $this->_getResourcesFromModules();

        Doctrine_Query::create()->delete('AclResource')->execute();
        Doctrine_Query::create()->delete('AclResourceItem')->execute();

        foreach($loadResourceItem as $v1){
            $idr1 = $this->_addResource($v1['name']);
            foreach($v1['controllers'] as $v2){
                $idr2 = $this->_addResource($v2['name'], $idr1);
                foreach($v2['actions'] as $v3){
                    $this->_addResource($v3['name'], $idr2);
                }
            }
        }


        var_dump('DONE');
        exit();

    }


    /**
     * @param $resource
     * @param null $id_parent
     * @return int
     */
    private function _addResource($resource, $id_parent = null)
    {
        $aclResource = new AclResource();
        $aclResource->name = $resource;
        $aclResource->id_parent = $id_parent;
        $aclResource->save();

        $aclResourceItem = new AclResourceItem();
        $aclResourceItem->name = $resource;
        $aclResourceItem->Resource = $aclResource;
        $aclResourceItem->save();

        return $aclResource->getId();
    }


    /**
     * @return array
     */
    private function _getResourcesFromModules()
    {
        $frontController = Zend_Controller_Front::getInstance();
        $modules = $frontController->getControllerDirectory();
        $result = array();

        foreach($modules as $module => $path){
            $result[$module] = array(
                'name' => $module,
                'controllers' => array()
            );

            if (is_dir($path)) foreach (scandir($path) as $file) {
                if ($file{0} !== '.' && strpos($file, '.php') === strlen($file) - 4) {
                    $controller = Base::camelToDash(substr($file, 0, -14));
                    $controller_resource_name = $module.'_'.$controller;
                    $result[$module]['controllers'][$controller_resource_name] = array(
                        'name' => $controller_resource_name,
                        'actions' => array()
                    );

                    require_once $path . '/' . $file;

                    $class_name = ($module === 'default' ? '' : Base::dashToCamel($module) . '_') . substr($file, 0, -4);
                    foreach (get_class_methods($class_name) as $method) {
                        if (substr($method,-6) === 'Action') {
                            $action = Base::camelToDash(substr($method, 0, -6));
                            $action_resource_name = $module.'_'.$controller.'_'.$action;
                            $result[$module]['controllers'][$controller_resource_name]['actions'][$action_resource_name] = array(
                                'name' => $action_resource_name,
                            );
                        }
                    }
                }
            }
        }

        return $result;
    }
}