<?php

class Admin_ModulesController extends Base_Controller_Action
{
    public function init()
    {
        parent::init();
        $this->view->moduleList = array_filter(Base_Module::getModulesVersion());
    }

    public function indexAction()
    {

    }

    public function showAction()
    {
        $this->view->changelog = Base_Module::getModuleChangelog($this->getParam('modulename'));
        $this->view->modulename = $this->getParam('modulename');
    }
}