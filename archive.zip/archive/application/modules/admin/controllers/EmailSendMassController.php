<?php

class Admin_EmailSendMassController extends Base_Controller_Action
{
    
    private $_items = array();


    public function deleteAction()
    {
        if ( $this->_request->isPost() ) {
            $ids = (array) explode(',',$this->getParam('massItems'));
            $all = (bool)$this->getParam('massItemAllPage');
            $this->_items = $this->_getItems($ids, $all);

            if(count($this->_items)){
                Doctrine_Query::create()->delete('EmailSend')
                    ->whereIn('id_email_send', $this->_items)
                    ->execute();
            }

            $this->_helper->viewRenderer('delete-ajax-result');
        } else {
            $this->forward403('Post request method is required');
        }
    }
    
    private function _getItems($ids, $all)
    {
        if($all){
            $filter = new Admin_Form_Filter_EmailSend();
            $dataQuery = $filter->getValuesQuery(true);
            $dataQuery['coll_key'] = 'id_email_send';
            $query = EmailSend::getQuery($dataQuery);
            $query->select('id_email_send');

            $result = $query->execute();

            $ids = array_keys($result);
        }

        if(empty($ids)){
            $this->forward403('Mass Action not selected items');
        }


        $this->_items = $ids;

        return $this->_items;
    }
}