<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 12.01.2018
 * Time: 10:35
 */

class Admin_ServiceController extends Base_Controller_Action
{

    /**
     * @var $_model Service
     */
    private $_model = null;

    /**
     * @var Admin_Form_ServiceFilter
     */
    private $_formFilter;

    /**
     * @var array
     */
    private $_dataQuery = array();

    /**
     * @var Service_Form_Service
     */
    private $_serviceForm;


    public function indexAction()
    {
        $this->_formFilter = new Admin_Form_ServiceFilter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = Service::getQuery($this->_dataQuery);

        $this->view->serviceList = $this->_helper->paging($query);
        $this->view->formFilter = $this->_formFilter;
    }

    public function newAction()
    {
        $this->_model = new Service();

        $this->_formService();
        if($this->_model['id_service'] && $this->_serviceForm->getValue('email'))
        {

            $this->_createUser();
        }
        $this->view->model = $this->_model;
    }

    public function editAction()
    {
        $this->_model = Service::findRecord($this->_getParam('id_service'));
        $this->forward403Unless($this->_model);

        $this->_formService();
        $this->view->model = $this->_model;
    }

    private function _formService()
    {
        $this->_serviceForm = new Admin_Form_Service(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ($this->_request->isPost() && $this->_serviceForm->isValid($this->_request->getPost()))
        {

            $this->_model->save();


            if ($this->_request->isXmlHttpRequest()) {
                $this->_helper->viewRenderer('form-ajax-result');
            } else {
                $this->_flash()->success->addMessage('label_cms_save_success');
                $this->_redirector()->gotoRouteAndExit(array(), 'service_index');
            }
        }

        $this->view->form = $this->_serviceForm;
    }

    public function showAction()
    {
        $this->_model = Service::findRecord($this->_getParam('id_service'));
        $this->forward403Unless($this->_model);

        $this->view->service = $this->_model;
    }

    private function _createUser()
    {
        $username = explode('@', $this->_serviceForm->getValue('email'));

        // create user
        $user = new User();
        $user->id_service = $this->_model['id_service'];
        $user->role = 'admin';
        $user->email = $this->_serviceForm->getValue('email');
        $user->name = $username[0];
        $user->surname = $username[1];
        $user->setPassword('Demo1@3-17');
        $user->token = Base::getHash();

        $userEmail = new UserEmail();
        $userEmail->id_service = $user->id_service;
        $userEmail->email = $this->_serviceForm->getValue('email');
        $userEmail->is_active = 1;
        $user->Emails->add($userEmail);

        $user->save();
    }


}