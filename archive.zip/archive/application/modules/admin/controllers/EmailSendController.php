<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-01-13
 * Time: 12:55
 */

class Admin_EmailSendController extends Base_Controller_Action
{
    /**
     * @var EmailSend
     */
    private $_model;
    
    private $_formFilter;

    private $_dataQuery = array();

    /**
     * @var Base_Mail
     */
    private $_mail;


    public function indexAction()
    {
        $this->_formFilter = new Admin_Form_Filter_EmailSend();
        
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = EmailSend::getQuery($this->_dataQuery);
        

        // mass action
        $this->view->massActionOptions = array(
            'delete' => array(
                'url' => Base::url('admin_email_send_mass_delete'),
                'name' => $this->view->translate('mass-options_delete')
            )
        );

        $this->view->formFilter = $this->_formFilter;
        $this->view->emailSendList = $this->_helper->paging($query, array('limit' => 30, 'mode' => Doctrine::HYDRATE_RECORD));
    }

    public function showAction()
    {
        $this->_model = EmailSend::findRecord($this->getParam('id_email_send'));
        $this->forward404Unless($this->_model);

        $this->view->emailSend = $this->_model;
    }

    public function showHtmlAction()
    {
        $this->_model = EmailSend::findRecord($this->getParam('id_email_send'));
        $this->forward404Unless($this->_model);

        $html = $this->view->translate('label_cms_email-send_empty_html_view');
        if($this->_model->getHtml() && strlen($this->_model->getHtml()) > 0)
        {
            $html = $this->_model->getHtml();
        }

        $this->view->layout()->disableLayout();
        $this->view->html = $html;
    }

    public function sendAction()
    {
        $this->_model = EmailSend::findRecord($this->getParam('id_email_send'));
        $this->forward404Unless($this->_model);

        $this->_send();

        $this->_redirector()->gotoRouteAndExit(array(), 'admin_email_send_index');
    }

    public function deleteAction()
    {
        $this->_model = EmailSend::findRecord($this->getParam('id_email_send'));
        $this->forward404Unless($this->_model);

        $this->_model->delete();
        
        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'admin_email_send_index');
        }      
    }


    private function _send($mass = false)
    {
        $this->_mail = $this->_model->getMail();

        if($this->_mail instanceof Base_Mail && !$this->_model->is_sent)
        {
            $this->_mail->send(true, array('model' => $this->_model));
            if(!$mass) $this->_flash()->success->addMessage('label_cms_email-send_send_success');
        }
        else
        {
            if(!$mass) $this->_flash()->warning->addMessage('label_cms_email-send_send_error');
        }
    }
} 