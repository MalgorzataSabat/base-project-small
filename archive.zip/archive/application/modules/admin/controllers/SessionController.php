<?php

class Admin_SessionController extends Base_Controller_Action
{


    public function indexAction()
    {
        $query = Session::getQuery();
        $query->addSelect('u.name, u.surname');
        $query->leftJoin('o.User u');

        $this->view->sessionList = $this->_helper->paging($query);
    }


    public function deleteAction($records = null)
    {
        $session = Session::findRecord($this->getParam('id'));
        $this->forward404Unless($session);

        $session->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'admin_session');
    }

    public function deleteAllAction()
    {
        $sessionQuery = Doctrine_Query::create()->from('Session s');
        $with_me = $this->getParam('with_me', 1);
        if(!$with_me){
            $sessionQuery->addWhere('id != ?', session_id());
        }
        $sessionList = $sessionQuery->execute();

        foreach($sessionList as $session){ /** @var $session Session */
            $session->delete();
        }

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'admin_session');
    }





}
