<?php

class Admin_LabelController extends Base_Controller_Action
{

    /**
     * @var Label
     */
    private $_label;

    /**
     * @var $_labelFilter Admin_Form_Label_Filter
     */
    private $_labelFilter;

    public function indexAction()
    {
        $this->_labelFilter = new Admin_Form_Label_Filter();
        $data = $this->_labelFilter->getValuesQuery();

        $labelQuery = Label::getQuery($data);

        $this->view->labelList = $this->_helper->paging($labelQuery, array('limit' => 20));
        $this->view->formFilter = $this->_labelFilter;
    }


    public function newAction()
    {
        $this->_label = new Label();
        $this->_label->type = Label::TYPE_LABEL;

        $this->_formLabel();
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_label_new') );
    }


    public function editAction()
    {
        $this->_label = Label::findRecord($this->getParam('id_label'));
        $this->forward404Unless($this->_label);

        $this->_label->setFromImport(0);
        $this->_formLabel();

        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_label_edit') );
    }


    private function _formLabel()
    {
        $form = new Admin_Form_Label(array('model' => $this->_label));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){
                $this->_label->save();

                if($this->_request->isXmlHttpRequest()){
                    $this->_helper->viewRenderer('form-ajax-result');
                }else{
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit($this->_getReturnParams(), $this->_route_return);
                }
            }
        }

        $this->view->form = $form;
    }


    public function deleteAction()
    {
        $this->_label = Label::findRecord($this->getParam('id_label'));
        $this->forward404Unless($this->_label);

        $this->_label->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'admin_label');
        }
    }


    public function exportAction()
    {
        $this->view->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_labelFilter = new Admin_Form_Label_Filter();

        $data = $this->_labelFilter->getValues(true);

        $fileName = 'label_export_'.date('Y-m-d_H-i-s').'.csv';
        $this->_response->setHeader('Content-type', 'application/csv');
        $this->_response->setHeader('Content-Disposition', 'attachment;charset=utf-8; filename="'.$fileName.'"');

        $fp = fopen('php://output', 'w');
        $labelList = Label::getQuery($data)->execute();
        foreach($labelList as $label){ /** @var Label $label */
            $row = array(
                'label' => $label['label'],
                'id_language' => $label['id_language'],
                'type' => $label['type'],
                'value' => $label['value'],
                'module' => $label['module']
            );

            fputcsv($fp, $row, ';');
        }

        fclose($fp);
    }

    public function importAction()
    {
        $form = new Admin_Form_Label_Import();
        if($this->_request->isPost() && $form->isValid($this->_request->getPost())){
            $upload = new Zend_File_Transfer_Adapter_Http();
            $files = $upload->getFileInfo();

            $fp = fopen($files['file']['tmp_name'], "r");
            while (($data = fgetcsv($fp,null,';')) !== false){
                if(count($data) !== 5) continue;
                foreach($data as $v) if(empty($v)) continue;

                $label = Doctrine_Query::create()->from('Label l')
                    ->innerJoin('l.Translations t')
                    ->where('label = ? AND t.id_language = ? AND l.type = ?', array($data[0], $data[1], $data[2]))
                    ->fetchOne();

                if(!$label){
                    $label = new Label();
                    $label->setLabel($data[0]);
                    $label->setType($data[2]);
                }
                $label->setFromImport(1);
                $label->setValue($data[3], $data[1]);
                $label->setModule($data[4]);
                $label->save();
            }

            fclose($fp);
            $this->_flash()->success->addMessage('label_cms_save_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'admin_label');
        }


        $this->view->form = $form;
        $this->_helper->viewRenderer('admin/form', null, array('noController' => true));
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_label_import') );
    }
}
