<?php
/**
 * Created by PhpStorm.
 * User: Dawid Przygodzki
 * Date: 2015-04-28
 * Time: 12:23
 */

class Admin_CronController extends Base_Controller_Action
{


    public function indexAction()
    {
        $this->view->cronList = Cron::getList(array('is_active' => ''));
    }


    public function runAction()
    {
        $cron = Cron::findRecord($this->_getParam('id_cron'));
        $this->forward404Unless($cron);

        $service = new $cron['service'];
        $service->cron();

        Cron::updateExecutionTime($cron['service']);
        $this->view->cron = $cron;
    }

} 