<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Admin_ApiController extends Base_Controller_Action
{

    /**
     * @var $_model Client
     */
    private $_model     = null;
    private $_formFilter;
    private $_dataQuery = array();


    public function indexAction()
    {
        $this->_formFilter = new Admin_Form_ApiFilter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = ApiService::getQuery($this->_dataQuery);

        
        
        $this->view->apiList = $this->_helper->paging($query);
        $this->view->formFilter = $this->_formFilter;
    }

    public function newAction()
    {
        $this->_model = new ApiService();
        
        $this->_formApi();
    }

    public function editAction()
    {
        $id_api_service = $this->_getParam('id_api_service');
        $this->_model = ApiService::findRecord($id_api_service);
        $this->forward403Unless($this->_model);

        $this->_formApi();
    }

    private function _formApi()
    {
        $form = new Admin_Form_Api(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');
        
        if ( $this->_request->isPost() ) {
            
            if ( $form->isValid($this->_request->getPost()) ) {
                $this->_model->save();

                if ($this->_request->isXmlHttpRequest()) {
                    $this->_helper->viewRenderer('form-ajax-result');
                } else {
                    $this->_flash()->success->addMessage('label_cms_save_success');
                    $this->_redirector()->gotoRouteAndExit(array(), 'api');
                }
            }
        }

        $this->view->form = $form;
        $this->view->model = $this->_model;
    }
    
    public function showAction()
    {
        $id_client = $this->_getParam('id_client');
        $this->_model = Client::find($id_client, array(
            'addUserCreated' => '', 'addAddressCountry' => '', 'addAddressProvince' => ''
        ));

        $this->forward403Unless($this->_model);

        $nav = Admin_Navigation::_();
        $pages = $nav->getPages('breadcrumb');
        $pages['client']['pages']['show']['label'] = $this->_model['name'];
        $pages['client']['pages']['show']['params']['id_client'] = $id_client;
        $nav->setPages($pages, 'breadcrumb');

        $this->view->model = $this->_model;
    }

    
}