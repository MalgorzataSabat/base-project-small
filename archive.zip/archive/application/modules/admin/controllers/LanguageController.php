<?php

class Admin_LanguageController extends Base_Controller_Action
{

    /**
     * @var Language
     */
    private $_language;

    public function indexAction()
    {
        $this->view->languageList = $this->_helper->paging(Language::getQuery());
    }


    public function newAction()
    {
        $this->_language = new Language();
        $this->_form($this->_language, 'Admin_Form_Language');;
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_language_new') );
    }

    public function editAction()
    {
        $this->_language = Language::findRecord($this->getParam('id_language'));
        $this->forward404Unless($this->_language);

        $this->_form($this->_language, 'Admin_Form_Language');
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_language_edit') );
    }


    public function deleteAction($records = null)
    {
        $this->_language = Language::findRecord($this->getParam('id_language'));
        $this->forward404Unless($this->_language);
        $this->forward403If($this->_language['is_main']);

        $this->_language->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'admin_language');
    }


}
