<?php

class Admin_SettingController extends Base_Controller_Action
{

    /**
     * @var Doctrine_Collection
     */
    private $_settingList;

    /**
     * @var array
     */
    private $_settingTypes;

    public function clearCacheAction()
    {
        Base_Cache::clean();
    }

    public function preDispatch()
    {
        parent::preDispatch();
        $this->_settingTypes = Setting::getSettingTypes();
        unset($this->_settingTypes[Setting::SETTING_FORM_CLASS]);
        $this->view->settingTypes = $this->_settingTypes;
    }

    public function listAction()
    {
        $this->_settingList = Setting::getSettings();
    }


    public function editAction()
    {
        $type = $this->getParam('type');
        $this->forward404Unless(isset($this->_settingTypes[$type]));

        $form = new Admin_Form_Setting(array('type' => $type));

        if($this->_request->isPost() && $form->isValid($this->_request->getPost())){
            $this->_flash()->success->addMessage('label_cms_save_success');
            $this->_redirector()->gotoRouteAndExit();
        }

        if($type == 'template')
        {
            $templates = Setting::getTemplates();
            $templatesFrontend = Setting::getSetting('template.frontend');
            $templatesBackend = Setting::getSetting('template.backend');

            if(in_array($templatesFrontend, array_keys($templates['frontend']))){
                $templates['frontend'][$templatesFrontend]['active'] = true;
            }
            else{
                $templates['frontend'][Setting::DEFAULT_TEMPLATE]['active'] = true;
            }

            if(in_array($templatesBackend, array_keys($templates['backend']))){
                $templates['backend'][$templatesBackend]['active'] = true;
            }
            else{
                $templates['backend'][Setting::DEFAULT_BACKEND_TEMPLATE]['active'] = true;
            }

            $this->view->templates = $templates;
            $this->_helper->viewRenderer('admin/template', null, array('noController' => true));
            $this->view->placeholder('page-title')->set($this->view->translate('admin_setting_page-title_template'));
        }
        else
        {
            $this->view->form = $form;
            $this->_helper->viewRenderer('admin/form', null, array('noController' => true));
            $this->view->placeholder('page-title')->set($this->view->translate('admin_setting_page-title'));
        }
    }


    public function setTemplateAction()
    {
        $name = $this->getParam('name');
        $type = $this->getParam('type');

        $templates = Setting::getTemplates();

        $update = Doctrine_Query::create()->update('Setting');

        if($type == 'frontend' || $type == 'backend')
        {
            if(in_array($name, array_keys($templates[$type])))
            {
                $update->set('value', '?', $name)->where('key = ?', array('template.'.$type))->execute();
            }
        }

        $this->_redirector()->gotoRouteAndExit(array('type' => 'template'), 'admin_setting_edit');
    }
}
