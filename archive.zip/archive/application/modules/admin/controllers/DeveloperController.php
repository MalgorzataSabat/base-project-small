<?php

class Admin_DeveloperController extends Base_Controller_Action {


    public function createServiceAction()
    {
        $adminService = new Admin_Service();
        $adminService->create($this->getParam('id_service_to'));


        exit();
    }


    public function testListAction()
    {

    }

    public function testFormAction()
    {
        $form = new Admin_Form_Developer_FormTest();

        if ( $this->_request->isPost()){
            if($form->isValid( $this->_request->getPost())){


            }
        }


        $this->view->form = $form;
    }



    public function indexAction()
    {


        if($this->hasParam('mode')){
            switch ($this->getParam('mode')){
                case 'dev-on': {
                    setcookie(COOKIE_DEV, true, 0, '/');
                    break;
                }
                case 'dev-off':{
                    setcookie(COOKIE_DEV, false, 0, '/');
                    break;
                }
                case 'cache-on': {
                    setcookie(COOKIE_NOCACHE, false, 0, '/');
                    break;
                }
                case 'cache-off':{
                    setcookie(COOKIE_NOCACHE, true, 0, '/');
                    break;
                }
                case 'zfdebug-on': {
                    setcookie(COOKIE_ZFDEBUG, true, 0, '/');
                    break;
                }
                case 'zfdebug-off':{
                    setcookie(COOKIE_ZFDEBUG, false, 0, '/');
                    break;
                }
            }
            $this->_redirector()->gotoRouteAndExit();
        }

//        var_dump('test');
//        exit();




    }


    public function adminerAction(){}

    public function startAdminerAction()
    {
        $this->_helper->viewRenderer->setNoRender();
        $this->_helper->layout()->disableLayout();

        $tmp = getcwd();
        $adminer_dir = ROOT_PATH . DS . 'library'  .DS . 'adminer';
        chdir($adminer_dir);
        include $adminer_dir . DS  .'index.php';
        chdir($tmp);
    }


    public function createLayoutsFromBaseAction()
    {
        exit();

        Base_Layout::disableLayout();
        Base_Layout::disableView();

        $data = Base_Layout::getRegistredLayouts();

        foreach($data as $module => $v){
            foreach($v as $filename => $vv){
                $layout = Layout::getRecord(array(
                    'module' => $module,
                    'filename' => $filename,
                    'hydrate' => Doctrine::HYDRATE_RECORD,
                ));

                if(!$layout){
                    $layout = new Layout();
                    $layout->module = $module;
                    $layout->filename = $filename;
                }

                $layout->placeholders = json_encode($vv['placeholders']);
                $layout->save();
            }
        }
    }

    public function createLayoutAction()
    {
        $module = 'Page';
        $filename = 'layout';


        $layout = Layout::getRecord(array(
            'module' => $module,
            'filename' => $filename,
            'hydrate' => Doctrine::HYDRATE_RECORD,
        ));


        Base_Layout::disableLayout();
        Base_Layout::disableView();

        $placeholders = array(
            'left' => array(
                'widgets' => array(
                  0 => array(
                      '_class' => 'Page_Widget_Nav', // 'TextPage_Widget_Nav',
                      'title' => 'test',
                      'id_page' => '11', // 'id_text_page' => '3',
                      'fix' => '1',
                    ),
                ),
            ),
            'main' => array(
              'widgets' => array(
                  0 => array (
                      '_class' => 'Page_Widget_Wysiwyg',
                      'html' => '<p>treść HTML z layotu</p>',
                  ),
                  1 => array (
                      '_class' => 'Page_Widget_Contact'
                    ),
                )),
        );





        $layout->module = $module;
        $layout->filename = $filename;
        $layout->placeholders = json_encode($placeholders);
//        var_dump($layout->toArray());
//        exit();

        $layout->save();
    }

}