--
-- Struktura tabeli dla tabeli `field`
--

DROP TABLE IF EXISTS `field`;
CREATE TABLE IF NOT EXISTS `field` (
  `id_field` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator pola',
  `hash` char(32) NOT NULL COMMENT 'Identyfikator hash pola',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `assign` varchar(255) NOT NULL COMMENT 'Pole przypisane do objektu/modułu',
  `key` varchar(255) NOT NULL COMMENT 'Klucz, wartośc wystemowa',
  `type` varchar(255) NOT NULL COMMENT 'Typ pola',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa pola',
  `order` smallint(5) UNSIGNED NOT NULL COMMENT 'Numer pola',
  `options` text NOT NULL COMMENT 'Opcje pola',
  PRIMARY KEY (`id_field`),
  UNIQUE KEY `hash` (`hash`),
  KEY `id_service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Zdefiniowane pola';

--
-- Zrzut danych tabeli `field`
--

INSERT INTO `field` (`id_field`, `hash`, `id_service`, `assign`, `key`, `type`, `name`, `order`, `options`) VALUES
(1, '4a7c86ff7b8c656341610e54bf18bcce', 2, 'module.1', '', 'float', 'Wartość', 1, '[]'),
(2, '4b962e10fc6f16a771e86d44005627a6', 2, 'module.1', '', 'dictionary.name', 'Status', 2, '[]'),
(3, '84412c662b98d0d0a19b5692099f83db', 2, 'module.1', '', 'user.fullname', 'Przypisane do', 4, '[]'),
(4, '899dca9d0dd6fbd559dcf2fabdc10a05', 2, 'module.1', '', 'tag.name', 'Tagi', 5, '[]'),
(5, '5e4e0c85a4f808383ea2b8ea5b72c13f', 2, 'module.1', '', 'textarea', 'Opis', 6, '[]'),
(7, 'e1ad63dbb194360292c232ae52a694b4', 2, 'module.1', '', 'client.name', 'Klient', 3, '[]');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `field_meta`
--

DROP TABLE IF EXISTS `field_meta`;
CREATE TABLE IF NOT EXISTS `field_meta` (
  `id_field_meta` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `hash` char(32) NOT NULL COMMENT 'Identyfikator hash',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `id_field` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator pola',
  `object_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator objektu',
  `value` text NOT NULL COMMENT 'Wartość pola',
  PRIMARY KEY (`id_field_meta`),
  UNIQUE KEY `hash` (`hash`),
  KEY `id_service` (`id_service`),
  KEY `id_field` (`id_field`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `field_meta`
--

INSERT INTO `field_meta` (`id_field_meta`, `hash`, `id_service`, `id_field`, `object_id`, `value`) VALUES
(9, 'c17e6bfdb47662f2fcf9fac8c440fa17', 2, 1, 7, '9501.22'),
(10, '8d090aafe8facdfea4ac5ad3ff5a0302', 2, 2, 7, '249'),
(11, 'c97f84c1b56b7712fd35a006f9897e83', 2, 7, 7, '4'),
(12, '2655ffa0aba2b373e973c414e2ed7011', 2, 3, 7, '33'),
(13, 'c4f62cd5373f9db09670f84a23c86d20', 2, 4, 7, '[\"BNI\",\"deal\"]'),
(14, 'e7ecab71707f5965077ff3d12a121964', 2, 5, 7, 'OP[is dodatkowy #1 - po edycji'),
(15, '206449c6d66989c36fa450073bf91235', 2, 1, 8, '9500'),
(16, '6ecbed8d08a4b3838178c41fbb06404c', 2, 2, 8, '249'),
(17, '4fb7c5da74a803ccc490dbb7649f6a2a', 2, 7, 8, '4'),
(18, '4ef794d1eb9615f90546716756504a57', 2, 3, 8, '33'),
(19, 'ce9e48141f800aa313dc5553931a32c6', 2, 4, 8, '[\"BNI\",\"deal\"]'),
(20, 'fb80960f02dcd7047d07cc9f64ac7cf5', 2, 5, 8, 'OP[is dodatkowy #2'),
(21, '96fafc713c3b0b4b9b4ca536344eeb2b', 2, 1, 3, '152.33'),
(22, '747200af4cd0a66e2eaf3cfc05918b9d', 2, 2, 3, '248'),
(23, '5de253bb66f2573cfd54f67a82e2df31', 2, 7, 3, '2'),
(24, '233fcd2c332eb1086706ef0ddd487404', 2, 3, 3, '34'),
(25, '9188ca9981a6febe6220f7d52f5bd214', 2, 4, 3, '[\"BNI\"]'),
(26, '28ee86ba5ebee9093aa358edcf639372', 2, 5, 3, ''),
(27, '128ae08b746232ccefd0b5a77554bf40', 2, 1, 4, '15000'),
(28, '81b5266dce7b84022bb8f2d47cf7fd9e', 2, 2, 4, '248'),
(29, '0462eeab2e3994e7fab14315e51f97f5', 2, 7, 4, '10'),
(30, '927153b23cbeacedec4273088e882ea7', 2, 3, 4, '33'),
(31, 'b2391c9ba0caf5eab4dcdd08843a0500', 2, 4, 4, '[]'),
(32, 'bb3248fe8738e31ee383c89e70d81037', 2, 5, 4, '');

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `field`
--
ALTER TABLE `field`
  ADD CONSTRAINT `field_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`);

--
-- Ograniczenia dla tabeli `field_meta`
--
ALTER TABLE `field_meta`
  ADD CONSTRAINT `field_meta_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`),
  ADD CONSTRAINT `field_meta_ibfk_2` FOREIGN KEY (`id_field`) REFERENCES `field` (`id_field`) ON DELETE CASCADE;

ALTER TABLE `field` ADD `is_searchable` BOOLEAN NOT NULL DEFAULT TRUE AFTER `order`;
ALTER TABLE `field` ADD `is_display_on_list` BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'Czy pole jest wyswietane domyslnie na listach' AFTER `is_searchable`;

UPDATE `field` SET `options` = '{\"object\":\"DealStatus\"}' WHERE `field`.`id_field` = 2;

INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', 'Nowy', '1', '0', '1', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', 'Wycena', '2', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', 'Negocjacje', '3', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', 'Realizacja', '4', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', '<span class="label label-success">Wygrany</span>', '5', '0', '0', '', '', '');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '2', 'DealStatus', '<span class="label label-danger">Przegrany</span>', '6', '0', '0', '', '', '');

COMMIT;
