<?php

/**
 * Created by PhpStorm.
 * User: robert.roginski
 * Date: 07.12.2016
 * Time: 11:32
 */
class Field_Bootstrap extends Base_Application_Module_Bootstrap
{
}