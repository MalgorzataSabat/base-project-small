<?php


class Field_Meta_Service
{

    public function saveFieldValues($object_id, array $values)
    {
        foreach($values as $id_field => $value){
            $filedMeta = FieldMeta::getRecord(array('id_field' => $id_field, 'object_id' => $object_id, 'hydrate' => Doctrine::HYDRATE_RECORD));

            if(!$filedMeta){
                $filedMeta = new FieldMeta();
                $filedMeta->id_field = $id_field;
                $filedMeta->object_id = $object_id;
            }

            $filedMeta->value = $value;
            $filedMeta->save();
        }
    }

}