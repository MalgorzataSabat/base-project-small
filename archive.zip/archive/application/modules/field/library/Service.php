<?php

class Field_Service
{

    /**
     * @var $_service Field_Service
     */
    private static $_service;

    private $_fields            = null;
    private $_fieldsById        = null;
//    private $_parameterTypes        = null;
//    private $_parametersOption      = null;
//    private $_parameterWithOption   = null;
//    private $_keys                  = null;
//    private $_units                 = null;
//    private $_assignType            = null;
//
//    const TYPE_INT      = 'int';
//    const TYPE_BOOL     = 'bool';
//    const TYPE_TEXT     = 'text';
//    const TYPE_SELECT   = 'select';
//    const TYPE_MULTI    = 'multi';

    protected function __construct(){
        $this->_prepareFields();
    }


    /**
     * @return Field_Service
     */
    public static function getInstance()
    {
        if ( is_null( self::$_service ) ) {
            self::$_service = new Field_Service();
        }

        return self::$_service;
    }

    /**
     * @return Field_Service
     */
    public static function _()
    {
        return self::getInstance();
    }

    public function getFieldList($assign)
    {
        return isset($this->_fields[$assign]) ? $this->_fields[$assign] : array();
    }

    public function getFieldIds($assign)
    {
        return isset($this->_fieldsById[$assign]) ? array_keys($this->_fieldsById[$assign]) : array();
    }




    private function _prepareFields()
    {
        $cache = Zend_Registry::get('Zend_Cache');
        $cacheName = 'Fields_'.Base_Service::getId();

        $resource = $cache->load($cacheName);

        if (false == $resource) {
            $result = Field::getList(array('coll_key' => 'hash'));

            foreach ($result as $row) {
                $this->_fields[$row['assign']][$row['hash']] = $row;
                $this->_fieldsById[$row['assign']][$row['id_field']] = $row['hash'];
            }

            $resource['fields'] = $this->_fields;
            $resource['fieldsById'] = $this->_fieldsById;

            $cache->save($resource, $cacheName);
        }

        $this->_fields = $resource['fields'];
        $this->_fieldsById = $resource['fieldsById'];
    }














    public function getParameterList($assign_type = null)
    {
        if ( null === $this->_parameters ) {
            $this->_prepareParameters();
        }

        if($assign_type){
            $assignTypeList = $this->getParameterByAssignType($assign_type);

            return array_intersect_key($this->_parameters, array_flip($assignTypeList));
        }


        return $this->_parameters;
    }

    public function getParameterByKeyList($assign_type = null)
    {
        if ( null === $this->_parametersByKey ) {
            $this->_prepareParameters();
        }

        if($assign_type){
            $assignTypeList = $this->getParameterByAssignType($assign_type);

            return array_intersect_key($this->_parametersByKey, $assignTypeList);
        }

        return $this->_parametersByKey;
    }

    public function getParameterByAssignType($assign_type)
    {
        if ( null === $this->_parameters ) {
            $this->_prepareParameters();
        }

        return $this->_assignType[$assign_type];
    }

    /**
     * @param $key
     * @param $value
     * @param bool|false $unit_on
     * @return mixed
     */
    public function getValueByKey($key, $value, $unit_on = false)
    {
        return $this->getValue($this->getIdByKey($key), $value, $unit_on);
    }

    /**
     * @param $id_parameter
     * @param $value
     * @param bool|false $unit_on
     * @return mixed
     */
    public function getValue($id_parameter, $value, $unit_on = false)
    {
        return $value;
    }

    /**
     * @param $key
     * @return null
     */
    public function getParameterNameByKey($key)
    {
        return $this->getParameterName($this->getIdByKey($key));
    }

    /**
     * @param $id_parameter
     * @return null
     */
    public function getParameterName($id_parameter)
    {
        $name = null;

        if ( null === $this->_parameters ) {
            $this->_prepareParameters();
        }

        if ( isset( $this->_parameters[$id_parameter] ) ) {
            $name = $this->_parameters[$id_parameter]['name'];
        }

        return $name;
    }

    /**
     * @param $id_parameter_option
     * @return null
     */
    public function getParameterOptionName($id_parameter_option)
    {
        $name = null;
        if ( null === $this->_parametersOption ) {
            $this->_prepareParametersOption();
        }

        if ( isset( $this->_parametersOption[$id_parameter_option] ) ) {
            $name = $this->_parametersOption[$id_parameter_option];
        }

        return $name;
    }

    /**
     * @return array
     */
    public function getKeyList()
    {
        if ( null === $this->_keys ) {
            $this->_prepareParameters();
        }


        return $this->_keys;
    }

    /**
     * @return array
     */
    public function getParameterTypes()
    {
        if ( null === $this->_parameterTypes ) {
            $this->_prepareParameters();
        }


        return $this->_parameterTypes;
    }

    /**
     * @param $id
     * @return bool
     */
    public function getParameterType($id)
    {
        $types = $this->getParameterTypes();


        return isset($types[$id]) ? $types[$id] : false;
    }

    /**
     * @param $key
     * @return int
     */
    public function getIdByKey($key)
    {
        $list = $this->getKeyList();

        return isset($list[$key]) ? $list[$key] : false;
    }

    public function getParametersOptionList()
    {
        if ( null === $this->_parametersOption ) {
            $this->_prepareParametersOption();
        }

        return $this->_parametersOption;
    }

    public function getParameterWithOptionList()
    {
        if ( null === $this->_parameterWithOption ) {
            $this->_prepareParametersOption();
        }

        return $this->_parameterWithOption;
    }

    private function _prepareParametersOption()
    {
        $cache = Zend_Registry::get('Zend_Cache');
        $cacheName = 'Realestate_ParametersOption_lang_'.Base_I18n::getLangId();

        $resource = $cache->load($cacheName);

        if (false == $resource) {
            $result = RealestateParameterOption::getList(array('coll_key' => 'id_parameter_option'));
            foreach ($result as $row) {
                $this->_parametersOption[$row['id_parameter_option']] = $row['name'];
                $this->_parameterWithOption[$row['id_parameter']][$row['id_parameter_option']] = $row['name'];
            }

            $resource['parametersOption'] = $this->_parametersOption;
            $resource['parameterWithOption'] = $this->_parameterWithOption;

            $cache->save($resource, $cacheName);
        }

        $this->_parametersOption = $resource['parametersOption'];
        $this->_parameterWithOption = $resource['parameterWithOption'];
    }

    private function _prepareParameters()
    {
        $cache = Zend_Registry::get('Zend_Cache');
        $cacheName = 'Realestate_Parameters_lang_'.Base_I18n::getLangId();

        $resource = $cache->load($cacheName);

        if (false == $resource) {
            $result = RealestateParameter::getList();

            foreach ($result as $row) {
                $this->_parameters[$row['id_parameter']] = $row;
                $this->_parametersByKey[$row['key']] = $row;
                $this->_parameterTypes[$row['id_parameter']] = $row['type'];
                $this->_keys[$row['key']] = $row['id_parameter'];
                $this->_units[$row['id_parameter']] = $row['unit'];
                $this->_assignType[$row['assign_type']][$row['key']] = $row['id_parameter'];
            }

            $resource['parameters'] = $this->_parameters;
            $resource['parametersByKey'] = $this->_parametersByKey;
            $resource['parameterTypes'] = $this->_parameterTypes;
            $resource['keys'] = $this->_keys;
            $resource['unit'] = $this->_units;
            $resource['assignType'] = $this->_assignType;

            $cache->save($resource, $cacheName);
        }

        $this->_parameters = $resource['parameters'];
        $this->_parametersByKey = $resource['parametersByKey'];
        $this->_parameterTypes = $resource['parameterTypes'];
        $this->_keys = $resource['keys'];
        $this->_units = $resource['unit'];
        $this->_assignType = $resource['assignType'];
    }
}