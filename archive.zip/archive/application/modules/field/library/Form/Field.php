<?php


class Field_Form_Field extends  Field_Form_Field_Abstract
{
    /**
     * @var Base_Form_Horizontal|Base_Form_Filter
     */
    private $_form;

    public function createElement($field, $fieldOptions, $form)
    {
        $this->_form = $form;
        $fieldMethod = '_create'.ucfirst($field['type']);
        if(!method_exists($this, $fieldMethod)){
            $fieldMethod = '_createText';
        }

//        $fieldOptions['prefixPath'] = array(
//            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
//        );

        return $this->$fieldMethod($field, $fieldOptions);
    }


    private function _createFloat($field, $fieldOptions)
    {
        $type = 'text';
        if(isset($fieldOptions['searchable']) && $fieldOptions['searchable']){
            $type = 'search_Number';
            unset($fieldOptions['searchable']);
        }

        return $this->_form->createElement($type, $field['hash'], $fieldOptions);
    }


    private function _createText($field, $fieldOptions)
    {
        return $this->_form->createElement('text', $field['hash'], $fieldOptions);
    }

    private function _createTextarea($field, $fieldOptions)
    {
        $fieldOptions['rows'] = 5;

        return $this->_form->createElement('textarea', $field['hash'], $fieldOptions);
    }

    private function _createWysiwyg($field, $fieldOptions)
    {
        return $this->_form->createElement('wysiwyg', $field['hash'], $fieldOptions);
    }


}