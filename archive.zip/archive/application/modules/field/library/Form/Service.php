<?php


class Field_Form_Service
{

    private $_fields = null;

    /**
     * @var Base_Form_Horizontal
     */
    private $_form = null;

    private $_elements = array();

    /**
     * @var Base_Doctrine_Record
     */
    private $_model;

    private $_searchMode = false;

    private $_elementDecorators = null;

    public function createElements($assign, $model = false)
    {
        $queryOptions = array('assign' => $assign, 'coll_key' => 'hash');
        if($this->_searchMode){
            $queryOptions['is_searchable'] = '1';
        }

        $this->_fields = Field::getList($queryOptions);
        if(!$this->_form){
            $this->_form = new Base_Form_Horizontal();
            $this->_elementDecorators = $this->_form->defaultElementDecorators;
        }else{
            $this->_elementDecorators = array(
                array('ViewHelper'),
                array('InputGroup', array('class' => 'input-group')),
                array('ElementErrors'),
                array('Description', array('tag' => 'span', 'class' => 'help-block')),
                array('FieldSize', array('size' => 9)),
                array('Label', array('class' => 'control-label', 'size' => 3)),
                array('WrapElementFilter')
            );
        }



        $this->_model = $model;

        foreach($this->_fields as $field){
            $fieldOptions = json_decode($field['options'], true);
            $fieldOptions['label'] = $field['name'];
            $fieldOptions['decorators'] = $this->_elementDecorators;
            if(isset($this->_model[$field['hash']])){
                $fieldOptions['value'] = $this->_model[$field['hash']];
            }
            if($this->_searchMode){
                $fieldOptions['searchable'] = true;
            }

            $fieldClassName = ucfirst(explode('.',$field['type'])[0]).'_Form_Field';
            $fieldClassName = class_exists($fieldClassName) ? $fieldClassName : 'Field_Form_Field';

            $fieldClass = new $fieldClassName();
            $this->_fields[$field['hash']]['_class'] = $fieldClass;
            $this->_elements[$field['hash']] = $fieldClass->createElement($field, $fieldOptions, $this->_form);
        }

        return $this->_elements;
    }

    public function getFields()
    {
        return $this->_fields;
    }

    public function getMetaValues($values)
    {
        $result = array();
        foreach($values as $k => $v){
            if(isset($this->_fields[$k])){
                $result[$this->_fields[$k]['id_field']] = $this->_fields[$k]['_class']->getMetaValue($v);
            }
        }

        return $result;
    }

    /**
     * @return bool
     */
    public function getSearchMode()
    {
        return $this->_searchMode;
    }

    /**
     * @param $searchMode
     * @return $this
     */
    public function setSearchMode($searchMode)
    {
        $this->_searchMode = $searchMode;

        return $this;
    }

    /**
     * @return bool
     */
    public function getForm()
    {
        return $this->_form;
    }

    /**
     * @param $form
     * @return $this
     */
    public function setForm($form)
    {
        $this->_form = $form;

        return $this;
    }

}