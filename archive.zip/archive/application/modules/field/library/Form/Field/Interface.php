<?php

interface Field_Form_Field_Interface
{

    public function createElement($field, $fieldOptions, $form);

    public function getMetaValue($value);


}
