<?php

abstract class Field_Form_Field_Abstract implements Field_Form_Field_Interface
{

    public function getMetaValue($value)
    {
        return $value;
    }

}
