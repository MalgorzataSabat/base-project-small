<?php


class Department_Extractor extends Base_Extractor
{

    protected $_tables = array('department');

    protected $_data = array();

    protected $_module = 'department';

    protected $_dumpResource = array('department');

    protected $_dumpRule = array('department');

    protected $_dumpLabel = array('department');

    protected $_dumpChangelog = array('department');

    protected $_dumpSettings = array('department');

    protected $_dumpDictionary = array('');


}