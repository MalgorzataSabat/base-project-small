<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 12.02.2018
 * Time: 11:01
 */

class Department_Form_Element_Department extends Base_Form_Element_Select
{
    private $_defaultName       = 'id_department';
    private $_departmentList    = array();
    private $_departmentOptions = array();
    private $_defaultValue;

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_task_department';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        if(!isset($options['value']) || (isset($options['value']) && !$options['value'])){
            if(isset($options['use_default']) && $options['use_default'] && $this->_defaultValue){
                unset($options['use_default']);
                $options['value'] = $this->_defaultValue['id_department'];
            }
        }

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }else{
            $options['validators'][] = array('InArray', true, array(array_keys($this->_departmentOptions)));
        }

        $options['select2'] = array(
            'allowClear' => true
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    public function getClientList()
    {
        return $this->_departmentList;
    }

    private function _loadMultiOptions(&$options)
    {
        $this->_departmentOptions = array();
        $this->_departmentList = Department::getList(array('coll_key' => 'id_department'));

        foreach ($this->_departmentList as $id_department => $v) {
            $this->_departmentOptions[$id_department] = $v['name'];
            if($v['is_default'])
            {
                $this->_defaultValue = $v;
            }
        }

        $this->_departmentOptions = array('' => '') + $this->_departmentOptions;

        $options['multioptions'] = $this->_departmentOptions;
    }
}