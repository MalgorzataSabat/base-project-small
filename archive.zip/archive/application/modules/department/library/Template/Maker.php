<?php


class Department_Template_Maker extends Template_Maker_Abstract implements Template_Maker_Interface
{

    protected $_prefixKey = 'department';

    public function createKeyValues()
    {
        parent::createKeyValues();

        $this->_keyValues['$$department.logo$$'] = '';

        if($this->_data['id_logo_image']){
            $this->_keyValues['$$department.logo$$'] = '<img src="'.Image::getBase64ById($this->_data['id_logo_image']).'" style="max-width: 150px;"/>';
        }


        return $this->_keyValues;
    }

}