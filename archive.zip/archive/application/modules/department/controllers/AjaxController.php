<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Department_AjaxController extends Base_Controller_Action
{
    /**
     * @var bool|Department
     */
    private $_department = false;


    public function getAction()
    {
        $id_department = $this->getParam('id_department');
        $this->forward403Unless($id_department, 'ID Department is required');

        $this->_department = Department::find($id_department);
        $this->forward403Unless($this->_department);

        $this->_department['phone'] = $this->view->displayPhone($this->_department['phone']);
        $this->_department['nip'] = $this->view->displayNip($this->_department['nip']);


        $this->_helper->json($this->_department);
    }



}