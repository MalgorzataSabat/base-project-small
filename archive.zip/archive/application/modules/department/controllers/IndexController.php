<?php

/**
 * Description of IndexController
 *
 * @author Piotr Tarkowski
 */

class Department_IndexController extends Base_Controller_Action
{
    
    /**
     * @var $_model Department
     */
    private $_model     = null;
    
    private $_formFilter;
    
    private $_dataQuery = array();
    
    
    public function indexAction()
    {
        $this->_formFilter = new Department_Form_Filter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = Department::getQuery($this->_dataQuery);
        //var_dump($this->_formFilter);exit;
        $this->view->departmentList = $this->_helper->paging($query, array('limit' => 20));
        $this->view->formFilter = $this->_formFilter;
    }
    
    public function showAction()
    {
        $id_department = $this->_getParam('id_department');
        $this->_model = Department::find($id_department);

        $this->forward403Unless($this->_model);

        
        $this->view->model = $this->_model;
    }
    
    public function newAction()
    {
        $this->_model = new Department();

        
        $this->_formDepartment();

    }
    
    public function editAction()
    {
        $id_department = $this->_getParam('id_department');
        $this->_model = Department::findRecord($id_department);
        $this->forward403Unless($this->_model);

        $this->_formDepartment();
    }
    
    private function _formDepartment()
    {
        $form = new Department_Form_Department(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');
        
        if ( $this->_request->isPost() ) {
            
            if ( $form->isValid($this->_request->getPost()) ) {
                $this->_model->save();

                $this->_flash()->success->addMessage('label_cms_save_success');
                $this->_redirector()->gotoRouteAndExit(array(), 'department');
            }
        }

        $this->view->form = $form;
        $this->view->model = $this->_model;
    }
    
    public function archiveAction()
    {
        $id_department = $this->_getParam('id_department');
        $this->_model = Department::findRecord($id_department);
        $this->forward403Unless($this->_model);

        $this->_model->archived_at = $this->_model->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_model->save();

        if ( $this->_model->archived_at ) {
            $this->_flash()->success->addMessage('label_cms_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_cms_unarchive_success');
        }

        $this->_redirector()->gotoRouteAndExit(array(), 'department');
    }
    
    public function deleteAction()
    {
        $id_department = $this->_getParam('id_department');
        $this->_model = Department::findRecord($id_department);
        $this->forward403Unless($this->_model);

        $this->_model->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'department');
    }
}
