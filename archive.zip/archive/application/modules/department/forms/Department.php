<?php

/**
 * Description of Department
 *
 * @author Piotr Tarkowski
 */
class Department_Form_Department extends Base_Form_Horizontal
{
    
    /**
     * @var $_model Department
     */
    protected $_model;
    
    public function init()
    {
        
        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model->getName(),
            'size' => 8,
            'label-size' => 4
        ));
        
        $fields['name_short'] = $this->createElement('text', 'name_short', array(
            'label' => $this->_tlabel.'name_short',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model->getNameShort(),
            'size' => 8,
            'label-size' => 4
        ));
        
        $fields['nip'] = $this->createElement('text', 'nip', array(
            'label' => $this->_tlabel.'nip',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array(new Base_Filter_Nip),
            'value' => $this->_model->getNip(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'value' => $this->_model->getEmail(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => $this->_tlabel.'phone',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Phone),
            'value' => $this->_model->getPhone(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['bank_number'] = $this->createElement('text', 'bank_number', array(
            'label' => $this->_tlabel.'bank_number',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getBankNumber(),
            'size' => 8,
            'label-size' => 4,
        ));
        
        $fields['bank_account_name'] = $this->createElement('text', 'bank_account_name', array(
            'label' => $this->_tlabel.'bank_account_name',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getBankAccountName(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['is_default'] = $this->createElement('checkbox', 'is_default', array(
            'label' => $this->_tlabel . 'is_default',
            'value' => $this->_model->getIsDefault(),
            'size' => 8,
            'label-size' => 4,
        ));
        
        $fields['id_logo_image'] = $this->createElement('FileImage', 'id_logo_image', array(
            'label' => $this->_tlabel.'id_logo_image',
            'allowEmpty' => true,
            'required' => false,
            'validators' => array(
                array('Extension', false, 'jpg, jpeg, png, gif'),
                array('Count', false, 1),
            ),
            'size' => 8,
            'label-size' => 4
        ));
        if ( !empty($this->_model->id_logo_image) ) {
            $imageDecorator = $fields['id_logo_image']->getDecorator('FileImage');
            $imageDecorator->setOptions(array(
                'id_image' => $this->_model->id_logo_image,
                'crop' => true,
                'delete' => true
            ));
        }

        $fields['email_notify'] = $this->createElement('text', 'email_notify', array(
            'label' => $this->_tlabel.'email_notify',
            'size' => 8,
            'label-size' => 4,
            'value' => $this->_model->getEmailNotify(),
            'description' => $this->getView()->translate($this->_tlabel.'email_notify-description'),
        ));


        $field_address['id_province'] = new Address_Form_Element_Province('id_province', array(
            'label' => Base::getFiledNameLabel('department.id_province'),
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('Null'),
            'value' => $this->_model['id_province'],
            'decorators' => $this->_elementDecorators,
            'size' => 8,
            'label-size' => 4,
        ));

        $field_address['street'] = $this->createElement('text', 'street', array(
            'label' => $this->_tlabel.'street',
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getStreet(),
            'size' => 8,
            'label-size' => 4,
        ));

        $field_address['street_no'] = $this->createElement('text', 'street_no', array(
            'label' => Base::getFiledNameLabel('department.street_no'),
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model['street_no'],
            'size' => 4,
            'label-size' => 4,
        ));
        $field_address['street_no']->removeDecorator('WrapElement');

        $field_address['flat_no'] = $this->createElement('text', 'flat_no', array(
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model['flat_no'],
            'placeholder' => Base::getFiledName('department.flat_no', 'placeholder'),
            'size' => 4,
        ));
        $field_address['flat_no']->removeDecorator('WrapElement');
        $field_address['flat_no']->removeDecorator('Label');
        $this->addHtmlTag(array($field_address['street_no'], $field_address['flat_no']), array('class' => 'form-group'));

        $field_address['city'] = $this->createElement('text', 'city', array(
            'label' => $this->_tlabel.'city',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getCity(),
            'size' => 8,
            'label-size' => 4,
        ));
        
        $field_address['post_code'] = $this->createElement('text', 'post_code', array(
            'label' => $this->_tlabel.'post_code',
            'allowEmpty' => false,
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getPostCode(),
            'size' => 8,
            'label-size' => 4,
        ));


        $this->addDisplayGroup(
            $fields,
            'main',
            array(
                'legend' => $this->_tlabel.'main'
            )
        );
        $this->addDisplayGroup($field_address, 'address', array(
            'legend' => 'Dane adresowe'
        ));
        
        $group_main = $this->getDisplayGroup('main');
        $group_address = $this->getDisplayGroup('address');
        
        $this->addHtmlTag(array($group_main), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_address), array('class' => 'col-md-6'));
        
        $this->addHtmlTag(array($group_main, $group_address), array('class' => 'row'));
        
        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array( $save));
        $this->addElements(array($save));

        $this->addHtmlTag(array($group_main, $save), array('class' => 'well'));
    }

    public function postIsValid($data)
    {
        parent::postIsValid($data);

        if($this->_model->is_default == 1)
        {
            $departmentQuery = Department::getQuery()
                ->addWhere('o.is_default = 1');

            if(!$this->_model->isNew()){
                $departmentQuery->addWhere('o.id_department <> ?', $this->_model->getId());
            }

            $departmentList = $departmentQuery->execute(array(), Doctrine::HYDRATE_RECORD);

            foreach($departmentList as $k => $department){
                $department['is_default'] = 0;
            }

            $departmentList->save();
        }

        return true;
    }
}
