<?php

/**
 * Description of Filter
 *
 * @author Piotr Tarkowski
 */
class Department_Form_Filter extends Base_Form_Filter
{
    
    protected $_sortCols        = array(
        'id_department' => 'o.id_department',
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'archived_at' => 'o.archived_at',
        'name_short' => 'o.name_short',
        'name' => 'o.name',
        'nip' => 'o.nip',
        'email' => 'o.email',
        'phone' => 'o.phone',
        'street' => 'o.street',
        'post_code' => 'o.post_code',
        'city' => 'o.city',
    );

    protected $_avalibleCols    = array(
        'id_department' => 'filter_department-column_id_department',
        'created_at' => 'filter_department-column_created_at',
        'archived_at' => 'filter_department-column_id_archived_at',
        'updated_at' => 'filter_department-column_id_updated_at',
        'name' => 'filter_department-column_name',
        'name_short' => 'filter_department-column_name_short',
        'id_logo_image' => 'filter_department-column_id_logo_image',
        'nip' => 'filter_department-column_nip',
        'email' => 'filter_department-column_email',
        'phone' => 'filter_department-column_phone',
        'street' => 'filter_department-column_street',
        'post_code' => 'filter_department-column_post_code',
        'city' => 'filter_department-column_city',
        
    );

    protected $_fieldsDisplay   = array(
        'search'
    );

    protected $_defaultCols     = array (
        'name', 'name_short', 'nip', 'city', 'street', 'post_code'
    );
    
    public function init()
    {
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => $this->_tlabel.'search',
        ));
        
        $this->_searchElements['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
        ));

        $this->_searchElements['phone'] = $this->createElement('text', 'phone', array(
            'label' => $this->_tlabel.'phone',
            'filters' => array(new Base_Filter_Phone),
        ));
        
        $this->_searchElements['nip'] = $this->createElement('text', 'nip', array(
            'label' => $this->_tlabel.'nip',
            'filters' => array(new Base_Filter_Nip),
        ));
        
        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' => $this->_tlabel . 'id_user_created'
        ));
        
        $this->_searchElements['city'] = $this->createElement('text', 'city', array(
            'label' => $this->_tlabel . 'city'
        ));

        $this->_searchElements['street'] = $this->createElement('text', 'street', array(
            'label' => $this->_tlabel . 'street'
        ));
        
        $this->_searchElements['post_code'] = $this->createElement('text', 'post_code', array(
            'label' => $this->_tlabel . 'post_code'
        ));
        
        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => $this->_tlabel . 'created_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $optionsArchive = array(
            '' => '',
            0 => 'label_archive_all',
            1 => 'label_archive_only'
        );

        $this->_searchElements['archived_at'] = $this->createElement('select', 'archived_at', array(
            'label' => $this->_tlabel.'archived_at',
            'multiOptions' => $optionsArchive,
        ));
    }
    
}
