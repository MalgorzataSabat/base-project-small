ALTER TABLE `department` ADD `street_no` VARCHAR(255) NOT NULL COMMENT 'Numer domu' AFTER `street`, ADD `flat_no` VARCHAR(255) NOT NULL COMMENT 'Numer lokalu' AFTER `street_no`;

ALTER TABLE `department` ADD `id_province` TINYINT UNSIGNED NULL DEFAULT NULL COMMENT 'Województwo' AFTER `nip`, ADD `county` VARCHAR(255) NOT NULL COMMENT 'Powiat' AFTER `id_province`, ADD `commune` VARCHAR(255) NOT NULL COMMENT 'Gmina' AFTER `county`, ADD INDEX (`id_province`);
ALTER TABLE `department` ADD `post_office` VARCHAR(255) NOT NULL COMMENT 'Poczta' AFTER `city`;

SET @idAclResource = (SELECT id_acl_resource FROM acl_resource WHERE name = 'department_read');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclResource, 'department_ajax_get');

ALTER TABLE `department` ADD `id_tax_office` VARCHAR(8) NULL DEFAULT NULL COMMENT 'Identyfikator Urzędu Skarbowego' AFTER `email_notify`;

delete FROM `setting` WHERE `key` LIKE '%invoice.sell%';
