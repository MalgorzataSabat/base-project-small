ALTER TABLE `department` ADD `hash` CHAR(32) NOT NULL AFTER `id_department`;
update `department` SET `hash` = MD5(CONCAT("dagfdfg",`id_department`));
ALTER TABLE `department` ADD UNIQUE(`hash`);


