-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id_department` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `id_service` int(10) unsigned NOT NULL COMMENT 'Identyfikator serwisu',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data ostatniej modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `id_user_created` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator użytkownika który dodał spółkę',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa spółki',
  `name_short` varchar(50) DEFAULT NULL COMMENT 'Skrócona nazwa spółki',
  `id_logo_image` int(10) unsigned DEFAULT NULL,
  `nip` varchar(255) NOT NULL COMMENT 'Nr NIP spółki',
  `street` varchar(255) NOT NULL COMMENT 'Ulica',
  `post_code` varchar(6) NOT NULL COMMENT 'Kod pocztowy',
  `city` varchar(255) NOT NULL COMMENT 'Miasto',
  `bank_number` varchar(255) NOT NULL COMMENT 'Nr konta bankowego',
  `bank_account_name` varchar(255) NOT NULL COMMENT 'Nazwa banku',
  `phone` varchar(32) DEFAULT NULL COMMENT 'Telefon',
  `email` varchar(255) DEFAULT NULL COMMENT 'Adres email',
  PRIMARY KEY (`id_department`),
  KEY `logo` (`id_logo_image`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `department_ibfk_1` FOREIGN KEY (`id_logo_image`) REFERENCES `image` (`id_image`) ON DELETE SET NULL,
  CONSTRAINT `department_ibfk_2` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  CONSTRAINT `department_ibfk_3` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
-- Dump OBJECT: 
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'department','Spółki','');
SET @resParentId54834 = LAST_INSERT_ID();
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54834,'department_read','Przeglądanie','');
SET @resParentId54835 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54835,'department');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54835,'department_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54835,'department_index_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54835,'department_index_show');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54834,'department_write','Zarządzanie','');
SET @resParentId54836 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54836,'department_index_new');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54836,'department_index_edit');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54836,'department_index_archive');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54836,'department_index_delete');
-- Dump MODULE: department
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'admin', 'department');
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'department'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('0001.20170830173014.csv','department','2017-08-30 15:30:14',2),('0001.sql','department','2017-12-18 10:15:35',1),('0002.20170901133825.csv','department','2017-09-01 11:38:25',2),('0003.20170902211632.csv','department','2017-09-03 08:45:26',2),('0004.20171106161032.csv','department','2017-11-06 15:10:32',2),('_install.sql','department','2017-09-03 08:45:20',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_department_list','label','2017-08-30 16:18:58','2017-08-30 16:18:58','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_list-add-button','label','2017-08-30 16:19:49','2017-08-30 16:19:49','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj nową spółkę');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_search','label','2017-08-30 16:20:05','2017-08-30 16:20:05','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szukaj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_email','label','2017-08-30 16:20:27','2017-08-30 16:20:27','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Email');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_phone','label','2017-08-30 16:20:45','2017-08-30 16:20:45','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_nip','label','2017-08-30 16:20:55','2017-08-30 16:20:55','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_id_user_created','label','2017-08-30 16:21:23','2017-08-30 16:21:23','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Stworzony przez');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_city','label','2017-08-30 16:21:35','2017-08-30 16:21:35','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_street','label','2017-08-30 16:21:53','2017-08-30 16:21:53','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_post_code','label','2017-08-30 16:22:10','2017-08-30 16:22:10','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_created_at','label','2017-08-30 16:22:24','2017-08-30 16:22:24','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_archived_at','label','2017-08-30 16:22:35','2017-08-30 16:22:35','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwalne');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_name','label','2017-08-30 16:23:08','2017-08-30 16:23:08','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_name_short','label','2017-08-30 16:23:22','2017-08-30 16:28:47','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Skrócona nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_nip','label','2017-08-30 16:23:40','2017-08-30 16:23:40','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_city','label','2017-08-30 16:23:56','2017-08-30 16:23:56','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_street','label','2017-08-30 16:24:08','2017-08-30 16:24:08','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_post_code','label','2017-08-30 16:24:32','2017-08-30 16:24:32','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_id_department','label','2017-08-30 16:24:48','2017-08-30 16:24:48','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_created_at','label','2017-08-30 16:24:59','2017-08-30 16:24:59','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_id_archived_at','label','2017-08-30 16:25:13','2017-08-30 16:25:13','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data archiwizacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_id_updated_at','label','2017-08-30 16:25:34','2017-08-30 16:25:34','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_id_logo_image','label','2017-08-30 16:25:45','2017-08-30 17:21:19','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Logo');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_email','label','2017-08-30 16:26:03','2017-08-30 16:26:03','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Email');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_department-column_phone','label','2017-08-30 16:26:15','2017-08-30 16:26:15','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_id_department','label','2017-08-30 16:26:40','2017-08-30 16:26:40','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_updated_at','label','2017-08-30 16:27:19','2017-08-30 16:27:19','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_name','label','2017-08-30 16:28:07','2017-08-30 16:28:07','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_filter_name_short','label','2017-08-30 16:28:29','2017-08-30 16:28:29','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Skrócona nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_name','label','2017-08-30 16:29:15','2017-08-30 16:29:15','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_name_short','label','2017-08-30 16:29:45','2017-08-30 16:29:45','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Skrócona nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_nip','label','2017-08-30 16:30:17','2017-08-30 16:30:17','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_city','label','2017-08-30 16:30:28','2017-08-30 16:30:28','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_street','label','2017-08-30 16:30:42','2017-08-30 16:30:42','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_post_code','label','2017-08-30 16:30:58','2017-08-30 16:30:58','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_id_department','label','2017-08-30 16:31:28','2017-08-30 16:31:28','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_created_at','label','2017-08-30 16:31:40','2017-08-30 16:31:40','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_archived_at','label','2017-08-30 16:31:56','2017-08-30 16:31:56','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data archiwizacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_updated_at','label','2017-08-30 16:32:18','2017-08-30 16:32:18','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_id_logo_image','label','2017-08-30 16:32:40','2017-08-30 17:21:27','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Logo');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_email','label','2017-08-30 16:32:50','2017-08-30 16:32:50','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Email');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_department_index_list_phone','label','2017-08-30 16:33:02','2017-08-30 16:33:27','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_department_show','label','2017-08-30 16:35:06','2017-08-30 16:40:14','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_name_short','label','2017-08-30 16:35:44','2017-08-30 16:35:44','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Skrócona nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_name','label','2017-08-30 16:35:58','2017-08-30 16:35:58','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_nip','label','2017-08-30 16:36:09','2017-08-30 16:36:09','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_bank_account_name','label','2017-08-30 16:36:23','2017-08-30 16:36:23','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa banku');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_bank_number','label','2017-08-30 16:36:52','2017-08-30 16:40:46','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nr konta bankowego');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_phone','label','2017-08-30 16:37:01','2017-08-30 16:37:01','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_email','label','2017-08-30 16:37:11','2017-08-30 16:37:11','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Email');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_city','label','2017-08-30 16:37:27','2017-08-30 16:37:27','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_post_code','label','2017-08-30 16:37:37','2017-08-30 16:37:37','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_street','label','2017-08-30 16:37:47','2017-08-30 16:37:47','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_panel_department-tab','label','2017-08-30 16:38:28','2017-08-30 16:38:28','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_panel_department-address','label','2017-08-30 16:38:59','2017-08-30 16:38:59','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_panel_title','label','2017-08-30 16:39:41','2017-08-30 16:39:41','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_main','label','2017-08-30 16:42:19','2017-08-30 16:42:19','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dane spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_name','label','2017-08-30 16:42:36','2017-08-30 16:42:36','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_name_short','label','2017-08-30 16:42:48','2017-08-30 16:42:48','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Skrócona nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_id_logo_image','label','2017-08-30 16:43:21','2017-08-30 17:21:35','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Logo');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_bank_number','label','2017-08-30 16:43:39','2017-08-30 16:43:39','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nr konta bankowego');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_bank_account_name','label','2017-08-30 16:43:52','2017-08-30 16:43:52','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa banku');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_street','label','2017-08-30 16:44:04','2017-08-30 16:44:04','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_city','label','2017-08-30 16:44:20','2017-08-30 16:44:20','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_post_code','label','2017-08-30 16:44:34','2017-08-30 16:44:34','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_nip','label','2017-08-30 16:44:47','2017-08-30 16:44:47','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_email','label','2017-08-30 16:44:58','2017-08-30 16:44:58','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Email');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_phone','label','2017-08-30 16:45:08','2017-08-30 16:45:08','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_department_edit','label','2017-08-30 16:45:34','2017-08-30 16:45:34','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('button_department_admin_list','label','2017-08-30 16:46:08','2017-08-30 16:46:08','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista spółek');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_department_new','label','2017-08-30 16:46:20','2017-08-30 16:46:20','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nawa spółka');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_created_at','label','2017-08-30 16:47:26','2017-08-30 16:47:26','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_department_new','label','2017-08-30 17:00:22','2017-08-30 17:00:22','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nawa spółka');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_department','label','2017-08-30 17:00:32','2017-09-03 10:45:26','department','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_department_edit','label','2017-08-30 17:01:02','2017-08-30 17:01:02','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_department_show','label','2017-08-30 17:01:19','2017-08-30 17:01:19','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły spółki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_form_department_address','label','2017-09-01 13:12:22','2017-09-01 13:12:22','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dane kontaktowe');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_id_logo_image','label','2017-09-01 13:18:23','2017-09-01 13:18:23','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Logo');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('department_show_panel_address_title','label','2017-09-01 13:20:09','2017-09-01 13:20:09','department','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dane kontaktowe');
