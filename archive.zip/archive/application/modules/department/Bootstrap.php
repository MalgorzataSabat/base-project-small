<?php


class Department_Bootstrap extends Base_Application_Module_Bootstrap {

}