<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('department', new Zend_Controller_Router_Route(
    '/@department',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('department_new', new Zend_Controller_Router_Route(
    '/@department/@new',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'new'
    )
));

$router->addRoute('department_edit', new Zend_Controller_Router_Route(
    '/@department/@edit/:id_department',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_department' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('department_show', new Zend_Controller_Router_Route(
    '/@department/@show/:id_department',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_department' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('department_delete', new Zend_Controller_Router_Route(
    '/@department/@delete/:id_department',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_department' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('department_archive', new Zend_Controller_Router_Route(
    '/@department/@archive/:id_department',
    array(
        'module' => 'department',
        'controller' => 'index',
        'action' => 'archive'
    ),
    array(
        'id_department' => '((\d+)|([0-9a-f]{32}))'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
