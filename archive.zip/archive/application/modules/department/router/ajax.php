<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('department_ajax_get', new Zend_Controller_Router_Route(
    '/@department/ajax/get/:id_department',
    array(
        'module' => 'department',
        'controller' => 'ajax',
        'action' => 'get',
        'id_department' => null,
    ),
    array(
        'id_department' => '((\d+)|([0-9a-f]{32}))'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
