<?php

class Bill_Form_AssignTask extends Base_Form_Horizontal
{

    protected $_data;

    protected $_idClient = array();

    /**
     * @param $data
     */
    protected function setData($data)
    {
        $this->_data = $data;
    }

    protected function setIdClient($idClient)
    {
        $this->_idClient = $idClient;
    }

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['value'] = $this->createElement('hidden', 'value', array('value' => join(',',$this->_data['value'])));
        $fields['value']->removeDecorator('WrapElement');
        $fields['all'] = $this->createElement('hidden', 'all', array('value' => $this->_data['all']));
        $fields['all']->removeDecorator('WrapElement');

        $fields['id_bill'] = new Bill_Form_Element_Select('id_bill', array(
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'id_client' => $this->_idClient,
            'id_status' => array('type' => 'open', 'value' => ''),
        ));

        $idBillValue = null;
        $multiOptions = $fields['id_bill']->getMultiOptions();
        isset(array_keys($multiOptions)[0]) && $idBillValue = array_keys($multiOptions)[0];
        $idBillValue && $fields['id_bill']->setValue($idBillValue);

        $fields['id_bill_item'] = new Bill_Form_Element_Item('id_bill_item', array(
            'value' => $this->_model['id_bill_item'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'id_client' => $this->_idClient,
            'id_bill' => $idBillValue,
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax form_bill_task-assign');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

    public function isValid($data)
    {
        $_data = $data[$this->getElementsBelongTo()];

        $idBillItemElement = $this->getElement('id_bill_item');
//        var_dump(get_class_methods($idBillItemElement));
//        var_dump($idBillItemElement);
//        exit();
//
//        var_dump($_data['id_bill']);

        $idBillItemElement->loadMultiOptions(array('id_bill' => $_data['id_bill']));


        return parent::isValid($data);
    }

}