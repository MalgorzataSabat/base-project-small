<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 16:32
 */

class Bill_Form_Bill extends Base_Form_Horizontal
{

    /**
     * @var $_model Bill
     */
    protected $_model = null;

    public function init()
    {
        $this->setAction(Base::url());
        $fields = array();
        $fields_period = array();
        $fields_desc = array();

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => Base::getFiledNameLabel('bill.name'),
            'value' => $this->_model['name'],
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
        ));

        $vAlreadyTakenBillOptions = array('model' => 'Bill', 'column' => 'number');
        if(!$this->_model->isNew()){
            $vAlreadyTakenBillOptions['params'][] = array('id_bill', '!=', $this->_model->getId());
        }

        $vAlreadyTakenBill = new Base_Validate_AlreadyTaken($vAlreadyTakenBillOptions);

        $fields['number'] = $this->createElement('text', 'number', array(
            'label' => Base::getFiledNameLabel('bill.number'),
            'value' => $this->_model['number'],
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
                array($vAlreadyTakenBill, true),
            ),
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
        ));

        $fields['id_user'] = new User_Form_Element_User('id_user', array(
            'label' => Base::getFiledNameLabel('bill.id_user'),
            'value' => $this->_model['id_user'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['id_client'] = new Client_Form_Element_Client('id_client', array(
            'label' => Base::getFiledNameLabel('bill.id_client'),
            'value' => $this->_model['id_client'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

//        if(Setting::getSetting('bill.contract_type_on')){
//            $fields['id_contract_type'] = new Dictionary_Form_Element_Select('id_contract_type', array(
//                'label' => 'field_contract_type',
//                'object' => 'ContractType',
//                'value' => $this->_model['id_contract_type'],
//                'required' => false,
//                'allowEmpty' => true,
//                'label-size' => 4,
//                'size' => 8,
//                'decorators' => $this->_elementDecorators,
//                'filters' => array('Null'),
//            ));
//        }

        $fields['id_agreement'] = new Agreement_Form_Element_Select('id_agreement', array(
            'label' => Base::getFiledNameLabel('bill.id_agreement'),
            'value' => $this->_model['id_agreement'],
            'required' => false,
            'allowEmpty' => true,
            'label-size' => 4,
            'size' => 8,
            'id_client' => $this->_model['id_client'],
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['id_project'] = new Project_Form_Element_Project('id_project', array(
            'label' => Base::getFiledNameLabel('bill.id_project'),
            'value' => $this->_model['id_project'],
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'id_client' => $this->_model['id_client'],
            'label-size' => 4,
            'size' => 8,
        ));

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => Base::getFiledNameLabel('bill.id_status'),
            'value' => $this->_model['id_status'],
            'object' => 'BillStatus',
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['tags'] = new Tag_Form_Element_Tag('tags', array(
            'value' => !empty($this->_model['tags']) ? json_decode($this->_model['tags']) : array(),
            'size' => 8,
            'label-size' => 4,
            'allowEmpty' => true,
            'required' => false,
            'select2' => array(),
            'data-tags' => true,
            'data-token-separators' => "[',']",
            'multiple' => 'multiple',
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'model' => 'Bill',
        ));


        $fields_period['is_period'] = $this->createElement('checkbox', 'is_period', array(
            'text' => Base::getFiledName('bill.is_period', 'text'),
            'description' => Base::getFiledNameLabel('bill.is_period', 'desc'),
            'checked' => $this->_model['is_period'],
            'checkedValue' => 1,
            'uncheckedValue' => 0,
            'allowEmpty' => true,
            'required' => false,
            'size' => 12,
//            'offset' => 4,
        ));

        $periodRangeValue = $this->_model['period_range'] ? $this->_model['period_range'] : '1 month';
        $fields_period['period_range'] = $this->createElement('select', 'period_range', array(
            'label' => Base::getFiledNameLabel('bill.period_range'),
            'value' => $periodRangeValue,
            'multiOptions' => Bill::$periodOptions,
            'size' => 8,
            'label-size' => 4,
        ));

        $fields_period['period_end'] = $this->createElement('DateTimePicker', 'period_end', array(
            'label' => Base::getFiledNameLabel('bill.period_end'),
            'value' => $this->_model['period_end'],
            'description' => Base::getFiledNameLabel('bill.period_end', 'desc'),
            'allowEmpty' => true,
            'datetime-format' => 'date',
            'filters' => array('Null'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            ),
            'size' => 8,
            'label-size' => 4,
        ));
        $this->addHtmlTag(array( $fields_period['period_range'] ,  $fields_period['period_end'] ), array('class' => 'bill_period_fields'), 'billPeriodFields');



        $fields_desc['desc'] = $this->createElement('wysiwyg', 'desc', array(
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model['desc'],
            'data-small' => true,
            'size' => 12,
        ));


        $this->addDisplayGroup($fields, 'main', array(
            'legend' => $this->_tlabel.'group_main'
        ));

        $this->addDisplayGroup($fields_period, 'main_period', array(
            'legend' => $this->_tlabel.'group_period'
        ));

        $this->addDisplayGroup($fields_desc, 'main_adv', array(
            'legend' => $this->_tlabel.'group_adv'
        ));

        $group_main = $this->getDisplayGroup('main');
        $group_period = $this->getDisplayGroup('main_period');
        $group_adv = $this->getDisplayGroup('main_adv');

        $this->addHtmlTag(array($group_main), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_period, $group_adv), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_main, $group_adv), array('class' => 'row'));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array( $save));
        $this->addElements(array($save));
    }


    public function render(Zend_View_Interface $view = null)
    {
        $isPeriodValue = $this->getValue('is_period');

        if(!$isPeriodValue){
            $billPeriodFieldsDeco = $this->getElement('period_range')->getDecorator('billPeriodFields');
            $billPeriodFieldsDeco->setOption('style', 'display:none;');
        }

        return parent::render($view);
    }


    /**
     * @param array $data
     * @return bool
     */
    public function isValid($data)
    {
        $_data = $data[$this->getElementsBelongTo()];

        $idAgreementElement = $this->getElement('id_agreement');
        if ($idAgreementElement) {
            $idAgreementElement->loadMultiOptions(array('id_client' => $_data['id_client']));
        }

        return parent::isValid($data);
    }


}