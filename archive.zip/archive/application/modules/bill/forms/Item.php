<?php

class Bill_Form_Item extends  Base_Form_Horizontal
{

    /**
     * @var $_model BillItem
     */

    protected $_model = null;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => Base::getFiledNameLabel('bill_item.name'),
            'value' => $this->_model['name'],
            'filters' => array('StringTrim'),
            'decorators' => $this->_elementDecorators,
            'allowEmpty' => false,
            'required' => true,
        ));

        $fields['is_default'] = $this->createElement('checkbox', 'is_default', array(
            'label' => Base::getFiledNameLabel('bill_item.is_default'),
            'text' => Base::getFiledName('bill_item.is_default', 'text'),
            'description' => Base::getFiledName('bill_item.is_default', 'desc'),
            'checked' => $this->_model['is_default'],
            'checkedValue' => 1,
            'uncheckedValue' => 0,
            'allowEmpty' => true,
            'required' => false,
        ));

        $fields['calc_strategy'] = new Bill_Form_Element_CalcStrategyRadio('calc_strategy', array(
            'label' => Base::getFiledNameLabel('bill_item.calc_strategy'),
            'value' => $this->_model['calc_strategy'],
            'decorators' => $this->_elementDecorators,
            'allowEmpty' => false,
            'required' => true,
            'inline' => true,
        ));

        $fields['price_sum'] = $this->createElement('text', 'price_sum', array(
            'label' => Base::getFiledNameLabel('bill_item.price_sum'),
            'value' => $this->_model['price_sum'],
            'filters' => array('StringTrim','Float'),
            'decorators' => $this->_elementDecorators,
        ));
        $this->addHtmlTag(array($fields['price_sum']), array('class' => 'calcStrategyFieldsRow calcStrategyFieldsRow'.BillItem::CALC_STATEGY_AMOUNT),
            'row_calc-strategy_fields');


        $this->addDisplayGroup(
            $fields,
            'main'
        );

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

//        $this->setAttrib('id', $this->getElementsBelongTo());
//        $this->setAttrib('class', $this->getAttrib('class') . ' ajax');
//        $this->setAttrib('data-overbox-replace', true);
    }


    /**
     * @param Zend_View_Interface|null $view
     * @return string
     */
    public function render(Zend_View_Interface $view = null)
    {

        $displayCalcStrategyFieldsRow1 = 'none';

        $calc_strategy_value = $this->getValue('calc_strategy');
        if(BillItem::CALC_STATEGY_AMOUNT == $calc_strategy_value){
            $displayCalcStrategyFieldsRow1 = 'block';
        }

        $priceSumElement = $this->getElement('price_sum');
        $priceSumElement->getDecorator('row_calc-strategy_fields')->setOption('style', 'display:'.$displayCalcStrategyFieldsRow1);

        return parent::render($view);
    }


    /**
     * @param array $data
     * @return bool
     */
    public function isValid($data)
    {
        $this->populate($data);

        $calc_strategy_value = $this->getValue('calc_strategy');

        if(BillItem::CALC_STATEGY_AMOUNT == $calc_strategy_value){
            $this->getElement('price_sum')->setRequired(true)->setAllowEmpty(false);
        }

        return parent::isValid($data);
    }

    public function postIsValid($data)
    {
        parent::postIsValid($data);

        $this->_model->save();

        // domyślnia może byc tylko jedna pozycja w rozliczeniu
        if($this->_model['is_default']){
            Doctrine_Query::create()->update('BillItem')
                ->set('is_default', '0')
                ->where('(is_default = 1 && id_bill = ? && id_bill_item != ?)', array($this->_model['id_bill'], $this->_model['id_bill_item']))
                ->execute();
        }

        return true;
    }





}