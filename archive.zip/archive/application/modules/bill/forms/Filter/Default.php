<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 23.09.2016
 * Time: 10:45
 */
class Bill_Form_Filter_Default extends Bill_Form_Filter
{

    protected $_forceClear = 1;

    protected $_defaultCols  = array (
        'number', 'name', 'id_status', 'id_user', 'price_sum', 'id_invoice', 'id_agreement'
    );

    protected function _getQueryFormClass()
    {
        return array_values(class_parents($this))[0];
    }

    public function init()
    {
        parent::init();

        $this->_searchElements['id_status']->setValue(array(
            'type' => 'all',
            'value' => '',
        ));

    }

}