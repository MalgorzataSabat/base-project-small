<?php

class Bill_Form_Filter extends Base_Form_Filter
{

    protected $_version = 2;

    protected $_sortCols = array(
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'id_user_created' => 'o.id_user_created',
        'id_user' => 'o.id_user',
        'id_client' => 'o.id_client',
        'id_project' => 'o.id_project',
        'id_status' => 'o.id_status',
        'id_invoice' => 'o.id_invoice',
        'name' => 'o.name',
        'count' => 'o.count',
        'price' => 'o.price',
        'price_sum' => 'o.price_sum',
    );

    protected $_avalibleCols    = array(
        'created_at' => 'index.datetime',
        'updated_at' => 'index.datetime',
        'id_user_created' => 'user.user',
        'id_user' => 'user.user',
        'id_client' => 'client.client',
        'id_project' => 'project.project',
        'id_status' => 'dictionary.dictionary',
        'id_invoice' => 'invoice.invoice',
        'id_agreement' => 'agreement.agreement',
        'number' => 'bill.bill',
        'name' => 'index.text',
        'count' => 'index.float',
        'price' => 'index.price',
        'price_sum' => 'index.price',
        'tags' => 'index.tags',
        'is_period' => 'index.boolean',
        'period_range' => 'bill.period_range',
        'period_end' => 'index.date',
    );

    protected $_fieldsDisplay   = array(
        'search', 'id_client', 'id_status'
    );

    protected $_defaultCols  = array (
        'number', 'name', 'id_client', 'id_status', 'id_user', 'price_sum'
    );

    public function init()
    {
        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => Base::getFiledNameLabel('search'),
        ));

        $this->_searchElements['id_client'] = new Client_Form_Element_Client(null, array(
            'searchable' => true,
        ));
        $this->_searchElements['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => 'field_status',
            'object' => 'BillStatus',
            'searchable' => array('type' => 'dictionary'),
            'value' => array(
                'type' => 'open',
                'value' => '',
            )
        ));

        $this->_searchElements['id_user'] = new User_Form_Element_User(null, array(
            'label' => 'field_user-serach',
            'searchable' => true,
            'select2' => true,
        ));

        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' => 'field_user_created',
            'searchable' => true,
            'select2' => true,
        ));

        $this->_searchElements['id_agreement'] = new Agreement_Form_Element_Select('id_agreement', array(
            'label' => Base::getFiledNameLabel('agreement.id_agreement'),
            'searchable' => true,
        ));

        $this->_searchElements['id_project'] = new Project_Form_Element_Project('id_project', array(
            'searchable' => true,
        ));

        $this->_searchElements['invoice'] = $this->createElement('text', 'invoice', array(
            'label' => Base::getFiledNameLabel($this->_filedName.'id_invoice'),
            'searchable' => array('type' => 'select'),
        ));

        $this->_searchElements['count'] = $this->createElement('search_Number', 'count', array(
            'label' => Base::getFiledNameLabel($this->_filedName.'count'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));

        $this->_searchElements['price'] = $this->createElement('search_Number', 'price', array(
            'label' => Base::getFiledNameLabel($this->_filedName.'price'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));

        $this->_searchElements['price_sum'] = $this->createElement('search_Number', 'price_sum', array(
            'label' => Base::getFiledNameLabel($this->_filedName.'price_sum'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));


        $this->_searchElements['tags'] = new Tag_Form_Element_Tag('tags', array(
            'select2' => array(),
            'multiple' => 'multiple',
            'model' => 'Bill',
        ));

        $this->_searchElements['is_period'] = new Base_Form_Element_YesNo('is_period', array(
            'label' => Base::getFiledNameLabel('bill.is_period'),
        ));

        $this->_searchElements['period_range'] = $this->createElement('select', 'period_range', array(
            'label' => Base::getFiledNameLabel($this->_filedName.'period_range'),
            'multiOptions' => Bill::$periodOptions,
        ));

        $this->_searchElements['period_end'] = $this->createElement('search_Date', 'period_end', array(
            'label' => Base::getFiledNameLabel('bill.period_end'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => Base::getFiledNameLabel('created_at'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['updated_at'] = $this->createElement('search_Date', 'updated_at', array(
            'label' => Base::getFiledNameLabel('updated_at'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['archived_at'] = new Base_Form_Element_ArchivedAt();
    }

    public function populate(array $data)
    {
        $idProjectElement = $this->getElement('id_project');
        $idProjectElement->loadMultiOptions(array('id_client' => $data['id_client']['value']));

        $idAgreementElement = $this->getElement('id_agreement');
        if($idAgreementElement){
            $idAgreementElement->loadMultiOptions(array('id_client' => $data['id_client']['value']));
        }

        return parent::populate($data);
    }


}