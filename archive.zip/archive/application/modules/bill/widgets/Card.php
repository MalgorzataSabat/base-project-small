<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Bill_Widget_Card extends Base_Widget_Abstract
{
    public      $name = 'label_bill_widget_card';
    public      $_renderView = 'card.phtml';

    /**
     * @var Bill
     */
    protected   $_bill;

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }

    public function renderWidget()
    {
        if(!isset($this->params['bill'])){
            $this->_renderView = null;
            return;
        }

        if($this->params['bill'] instanceof Bill)
        {
            $this->_bill = $this->params['bill'];

        } elseif(is_array($this->params['bill'])) {
            $this->_bill = $this->params['bill'];
        } else {
            $this->_bill = Bill::find($this->params['bill']);
        }

        $this->view->bill = $this->_bill;
    }
}