<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Bill_Widget_Finance extends Bill_Widget_Card
{
    public      $name = 'label_bill_widget_finance';
    public      $_renderView = 'finance.phtml';


}