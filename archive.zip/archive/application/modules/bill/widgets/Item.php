<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Bill_Widget_Item extends Base_Widget_Abstract
{
    public      $name = 'label_bill_widget_item';
    public      $_renderView = 'item.phtml';

    /**
     * @var Bill
     */
    protected   $_bill;

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }

    public function renderWidget()
    {
        if(!isset($this->params['bill'])){
            $this->_renderView = null;
            return;
        }

        if($this->params['bill'] instanceof Bill)
        {
            $this->_bill = $this->params['bill'];

        } elseif(is_array($this->params['bill'])) {
            $this->_bill = $this->params['bill'];
        } else {
            $this->_bill = Bill::find($this->params['bill']);
        }


        $queryOptions = array(
            'id_bill' => $this->_bill['id_bill']
        );

        $billItemList = BillItem::getQuery($queryOptions)
            ->leftJoin('o.Tasks t')->addSelect('t.*')
            ->leftJoin('t.AgreementItem ai')->addSelect('ai.*')
            ->execute();

        $this->view->bill = $this->_bill;
        $this->view->billItemList = $billItemList;
    }
}