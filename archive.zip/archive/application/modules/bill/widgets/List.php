<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Bill_Widget_List extends Base_Widget_Abstract
{
    public      $name = 'label_bill_widget_list';

    public      $_renderView = 'list-table-main';

    protected $_usePagging = false;

    protected $_useMultiOptions = false;

    protected $_useFilterChange = false;

    protected $_useAddButton = false;

    /**
     * @var Agreement_Form_Filter
     */
    protected $_filter = null;

    protected $_massActionOptions = array();



    public function renderWidget()
    {
        $acl = Base_Acl::_();
        if(!$acl->hasAccess('bill')){
            $this->_renderView = null;
            return ;

        }

        $pagingOptions = array('view' => $this->view);
        isset($this->params['filter']) && $this->_filter = $this->params['filter'];
        !$this->_filter && $this->_filter = new Bill_Form_Filter_Default();
        $paging = Zend_Controller_Action_HelperBroker::getStaticHelper('paging');
        isset($this->params['usePagging']) && $this->params['usePagging'] && $this->_usePagging = $this->params['usePagging'];
        isset($this->params['useMultiOptions']) && $this->_useMultiOptions = $this->params['useMultiOptions'];
        isset($this->params['useFilterChange']) && $this->_useFilterChange = $this->params['useFilterChange'];
        isset($this->params['useAddButton']) && $this->_useAddButton = $this->params['useAddButton'];

        $dataQuery =  $this->_filter->getValuesQuery(true);
        isset($this->params['id_client']) && $dataQuery['id_client'] = $this->params['id_client'];
        isset($this->params['id_project']) && $dataQuery['id_project'] = $this->params['id_project'];

        $query = Bill::getQuery($dataQuery);

        if($this->_usePagging){
            $billList = $paging->direct($query, $pagingOptions);
        }else{
            $billList = $query->execute();
        }

        if($this->_useMultiOptions){
            if($this->view->hasAccess('export_bill')){
                $this->_massActionOptions['export'] = array(
                    'url' => Base::url('export', array('object' => 'bill')),
                    'name' => $this->view->translate('mass-options_export')
                );
            }
        }

        $addButtonParams = array();
        isset($this->params['id_client']) && $addButtonParams['id_client'] = $this->params['id_client'];
        isset($this->params['id_project']) && $addButtonParams['id_project'] = $this->params['id_project'];

        $this->view->billList = $billList;
        $this->view->filter = $this->_filter;
        $this->view->usePagging = $this->_usePagging;
        $this->view->useFilterChange = $this->_useFilterChange;
        $this->view->useAddButton = $this->_useAddButton;
        $this->view->addButtonParams = $addButtonParams;
        $this->view->massActionOptions = $this->_massActionOptions;
    }
}