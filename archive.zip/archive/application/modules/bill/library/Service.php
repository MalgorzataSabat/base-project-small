<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 30.11.2017
 * Time: 12:52
 */

class Bill_Service
{
    private $_id_bill = null;

    private $_id_bill_item = null;

    private $_task_list = array();

    public function __construct($options = array())
    {
        if( isset($options['id_bill']) ) { $this->setIdBill($options['id_bill']); }
        if( isset($options['id_bill_item']) ) { $this->setIdBillItem($options['id_bill_item']); }
        if( isset($options['task_list']) ) { $this->setTaskList($options['task_list']); }

    }

    /**
     * @param $id_bill
     * @return $this
     */
    public function setIdBill($id_bill)
    {
        $this->_id_bill = $id_bill;

        return $this;
    }

    /**
     * @param $id_bill_item
     * @return $this
     */
    public function setIdBillItem($id_bill_item)
    {
        $this->_id_bill_item = $id_bill_item;

        return $this;
    }

    /**
     * @param $task_list
     * @return $this
     */
    public function setTaskList($task_list)
    {
        $this->_task_list = $task_list;

        return $this;
    }


    public function assignTask()
    {
        if(!$this->_id_bill || !$this->_id_bill_item || !$this->_task_list){
            throw new Exception('Data assign are required');
        }

        $taskIds = array_keys($this->_task_list);

        if($taskIds){
            $idBillListUpdate = array($this->_id_bill);

            // pobieramy zadania, aby przygotować listę rozliczeń do których ewentualnie taski mogą już być przypisane
            $taskList = Task::getQuery()
                ->whereIn('o.id_task', $taskIds)
                ->addWhere('o.id_bill != ""')
                ->execute();

            foreach($taskList as $task){
                $idBillListUpdate[] = $task['id_bill'];
            }

            $idBillListUpdate = array_filter(array_unique($idBillListUpdate));

            $update = Doctrine_Query::create()
                ->update('Task t')
                ->whereIn('id_task', $taskIds)
                ->set('id_bill', $this->_id_bill)
                ->set('id_bill_item', $this->_id_bill_item)
                ->execute();

            foreach($idBillListUpdate as $id_bill){
                self::recalculateBillPrice($id_bill);
            }
        }
    }

    public static function recalculateBillPrice($id_bill)
    {
        $billItemList = BillItem::getQuery(array(
            'id_bill' => $id_bill,
            'hydrate' => Doctrine::HYDRATE_RECORD,
            'order' => 'o.id_bill_item DESC'
        ))
            ->leftJoin('o.Tasks t')->addSelect('t.*')
            ->leftJoin('t.AgreementItem ai')->addSelect('ai.*')
            ->execute();


        $bill = Bill::getQuery(array(
            'id' => $id_bill,
            'hydrate' => Doctrine::HYDRATE_RECORD,
            'checkAccess' => false,
        ))
            ->leftJoin('o.Agreement a')->addSelect('a.*')
            ->leftJoin('o.Client c')->addSelect('c.*')
            ->fetchOne();

        if(!$billItemList || !$bill) return;

        $billCount = 0;
        $billPrice = 0;
        $billPriceSum = 0;
        $hourMax = 0;
        $hourRateAmount = Setting::getSetting('client.dafault_hour-rate');


        if(isset($bill['Agreement'])){
            $hourMax = (float) $bill['Agreement']['subscription_hour_max'];
        }

        if(isset($bill['Agreement']) && $bill['Agreement']['hour_rate'] > 0){
            $hourRateAmount = $bill['Agreement']['hour_rate'];
        }elseif(isset($bill['Client']) && $bill['Client']['finance_hour_rate'] > 0){
            $hourRateAmount = $bill['Client']['finance_hour_rate'];
        }

        foreach($billItemList as $billItem){

            $itemCount = 0;
            $itemPrice = 0;
            $itemPriceSum = 0;
            $itemPriceSumAdd = 0;
            $itemCountExtra = 0;

            if($billItem['calc_strategy'] == BillItem::CALC_STATEGY_AMOUNT){
                $itemPriceSum = $billItem['price_sum'];
            }elseif($billItem['calc_strategy'] == BillItem::CALC_STATEGY_AGREEMENT && isset($bill['Agreement'])){
                $itemPriceSum = $bill['Agreement']['subscription_amount'];
            }

            foreach($billItem['Tasks'] as $task){
                $itemCount+= $task['time_enity'];

                if($billItem['calc_strategy'] == BillItem::CALC_STATEGY_TASK)
                {
                    $itemPriceSumAdd+= $task['finance_amount'];
                }
                elseif(!isset($task['AgreementItem']) || !$task['AgreementItem']
                    || $task['AgreementItem']['calc_strategy'] != AgreementItem::CALC_STATEGY_NO_LIMIT)
                {
                    $itemCountExtra+= $task['time_enity'];
                }
            }

            if($billItem['calc_strategy'] == BillItem::CALC_STATEGY_AGREEMENT){

                if($itemCountExtra > $hourMax){
                    $itemCountExtra = $itemCountExtra - $hourMax;
                }else{
                    $itemCountExtra = 0;
                }

                $itemPriceSumAdd = $itemCountExtra * $hourRateAmount;
            }

            $itemPriceSum+= $itemPriceSumAdd;

            if($itemCount && $itemPriceSum){
                $itemPrice = $itemPriceSum/$itemCount;
            }

            $billCount+= $itemCount;
            $billPriceSum+= $itemPriceSum;

            // nalezy wyczyścić relacje np: Do tasków ponieważ je też próbuje zapisać
            // a zapis taska powoduje w postSave wywołanie tej metody
            $billItem->clearRelated();
            $billItem->count = $itemCount;
            $billItem->price = $itemPrice;
            $billItem->price_sum = $itemPriceSum;

            if($billItem['calc_strategy'] == BillItem::CALC_STATEGY_AGREEMENT) {
                $billItem->package_count_max = $hourMax;
                $billItem->package_count = $itemCount - $itemCountExtra;
                $billItem->package_count_out = $itemCountExtra;
                $billItem->package_price = $itemPriceSum - $itemPriceSumAdd;
                $billItem->package_price_out = $itemPriceSumAdd;
                if($hourMax){
                    $billItem->package_percent = ($itemCount/$hourMax)*100;
                }else{
                    $billItem->package_percent = 0;
                }
            }else{
                $billItem->package_count = 0;
                $billItem->package_count_out = $itemCount;
                $billItem->package_price = 0;
                $billItem->package_price_out = $itemPriceSum;
                $billItem->package_percent = 0;
            }

            $billItem->save();

            if(
                $billItem['calc_strategy'] == BillItem::CALC_STATEGY_AGREEMENT &&
                $billItem['package_percent'] > Setting::getSetting('bill.item_agreement_alert_percent') &&
                !$billItem['package_alert']
            ){
                self::sendAgreementUsedAlert($billItem);
            }
            elseif($billItem['package_alert'])
            {
                // nie wysyłamy lub ilość godzin się zmniejszyła
                $billItem->package_alert = null;
                $billItem->save();
            }
        }

        if($billCount && $billPriceSum){
            $billPrice = $billPriceSum/$billCount;
        }

        $bill->clearRelated();
        $bill->count = $billCount;
        $bill->price = $billPrice;
        $bill->price_sum = $billPriceSum;
        $bill->save();
    }

    public static function sendAgreementUsedAlert($billItem)
    {
        if(!($billItem instanceof BillItem)){
            $billItem = BillItem::findRecord($billItem);
        }

        if(!$billItem){ return false; }

        $client = Client::getQuery(array('archived_at' => ''))
            ->innerJoin('o.Bills b')
            ->addWhere('b.id_bill = ?', array($billItem['id_bill']))
            ->fetchOne();

        if(!$client){ return false; }

        $emailsAlert = array();

        $client['id_user_owner'] && $emailsAlert[] = User::getEmailById($client['id_user_owner']);

        $clientAssignUsers = json_decode($client['assign_users'], true);
        foreach($clientAssignUsers as $id_user){
            $emailsAlert[] = User::getEmailById($id_user);
        }

        $emailsAlert = array_unique(array_filter($emailsAlert));

        if(!$emailsAlert){ return; }

        $view = Base_Layout::getView();
        $view->billItem = $billItem;
        $view->client = $client;
        $view->bill = Bill::getQuery(array('id' => $billItem['id_bill'], 'checkAccess' => false))
            ->addSelect('a.*')
            ->leftJoin('o.Agreement a')
            ->leftJoin('o.Project p')
            ->fetchOne();

        $mail = new Base_Mail();
        $mail->setSubject('Alert wykorzystania pakietu umowy '.$billItem['count'].'h z '.$billItem['package_count_max'].'h; '.$client['short_name']);
        $mail->setBodyTemplate('bill/__mail_alert_package.phtml');

        $mail->addTo($emailsAlert);
        $mail->send();

        $billItem->package_alert = date('YmdHis');
        $billItem->save();
    }


    public static function syncTaskStatus($bill)
    {
        if(!is_array($bill) && !($bill instanceof Bill)){
            $bill = Bill::find($bill);
        }

        if(!$bill){
            return;
        }

        $taskStatusSyncDef = Setting::getSetting('bill.task_status_sync');
        $taskStatusSyncDef && $taskStatusSyncDef = (array) @json_decode($taskStatusSyncDef, true);
        $taskStatusList = Dictionary::getListByObject('TaskStatus');

        if(!isset($taskStatusSyncDef[$bill['id_status']])){
            return ;
        }

        $taskList = Task::getList(array('hydrate' => Doctrine::HYDRATE_RECORD, 'id_bill' => $bill['id_bill']));
        $id_task_status_new = $taskStatusSyncDef[$bill['id_status']];

        foreach($taskList as $task){
            if(isset($taskStatusList[$id_task_status_new]) && $id_task_status_new != $task['id_status']){
                $task['id_status'] = $id_task_status_new;
                $task->save();

            }
        }
    }


    public static function createCloneBillItems($bill, $billFrom)
    {
        $billItemCloneList = BillItem::getList(array('id_bill' => $billFrom['id_bill']));

        foreach($billItemCloneList as $billItemClone){
            $billItem = new BillItem();
            $billItem['id_bill'] = $bill['id_bill'];
            $billItem['id_service'] = $bill['id_service'];
            $billItem['name'] = $billItemClone['name'];
            $billItem['is_default'] = $billItemClone['is_default'];
            $billItem['calc_strategy'] = $billItemClone['calc_strategy'];
            $billItem['id_unit'] = $billItemClone['id_unit'];

            if($billItem['calc_strategy'] == BillItem::CALC_STATEGY_AMOUNT){
                $billItem['price_sum'] = $billItemClone['price_sum'];
            }

            $billItem->save();
        }

        self::recalculateBillPrice($bill['id_bill']);
    }


}