<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 26.01.2018
 * Time: 17:33
 */

class Bill_Loader extends Base_Loader_List
{



    public function _getQuery($options = array())
    {
        $this->_filter = new Bill_Form_Filter();
        $dataQuery = $this->_filter->getValuesQuery(true);
        $query = Bill::getQuery($dataQuery);

        if($this->getValue()){
            $query->whereIn('o.hash', $this->getValue());
        }

        return $query;
    }

    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $query = $this->_getQuery();

        if($select){
            $query->select($select);
        }

        $this->_result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        return $this->_result;
    }
}