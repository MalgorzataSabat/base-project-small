<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:46
 */

class Bill_Widget_Loader extends Base_Widget_Loader
{


    public function getParamsByWidget($widget)
    {
        $params = array();

        if($widget == 'Bill_Widget_Card')
        {
            $params = array('bill' => $this->_model);
        }

        elseif($widget == 'Bill_Widget_Finance')
        {
            $params = array('bill' => $this->_model);
        }

        elseif($widget == 'Bill_Widget_Item')
        {
            $params = array('bill' => $this->_model);
        }

        elseif($widget == 'Client_Widget_Card')
        {
            if(isset($this->_model['Client']) && is_array($this->_model['Client'])){
                $params = array('client' => $this->_model['Client']);
            }else{
                $params = array('client' => $this->_model['id_client']);
            }
        }

        elseif($widget == 'Document_Widget_Channel')
        {
            $params = array(
                'channel' => 'Bill',
                'object_id' => $this->_model['id_bill']
            );
        }

        elseif($widget == 'Note_Widget_Note')
        {
            $params = array(
                'channel' => 'Bill',
                'object_id' => $this->_model['id_bill']
            );
        }

        elseif($widget == 'Log_Widget_Timeline')
        {
            $params = array(
                'model' => 'Bill',
                'id_object' => $this->_model['id_bill']
            );
        }

        return $params;
    }



}
