<?php

/**
 * @see Zend_Acl_Resource_Interface
 */
require_once 'Zend/Acl/Resource/Interface.php';


/**
 * @category   Zend
 * @package    Zend_Acl
 * @copyright  Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Bill_Acl_Resource extends Base_Acl_Resource
{

    /**
     * @return bool|Bill
     */
    protected function loadModelFromRequest()
    {
        $request = Zend_Controller_Front::getInstance()->getRequest();

        $id_bill = $request->getParam('id_bill');

        if($id_bill){
            return Bill::find($id_bill);
        }

        return false;
    }

}
