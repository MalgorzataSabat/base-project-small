<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 30.11.2017
 * Time: 14:04
 */

class Bill_Form_Element_Select extends Base_Form_Element_Select
{
    private $_defaultName       = 'id_bill';

    private $_options = array();

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_bill';
        }

        $this->_options = $options;

        $options['select2'] = array(
            'allowClear' => true
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        $options['data-url-load-list'] = Base::url('bill_ajax_get-list');

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $this->_options) ) {
            $this->loadMultiOptions($this->_options);
        }
    }


    public function loadMultiOptions($options)
    {
        $multiOptions = array();
        $queryOptions = array();

        $isRequired = $this->isRequired();
        if(!$isRequired){
            $multiOptions[] = '';
        }

        isset($options['id_client']) && $queryOptions['id_client'] = $options['id_client'];
        isset($options['id_status']) && $queryOptions['id_status'] = $options['id_status'];

        $billList = Bill::getList($queryOptions);

        foreach($billList as $bill){
            $value = $bill['number'].': '. $bill['name'];
            if($bill['id_client']){ $value.= ' // '.Client::getNameById($bill['id_client']); }

            $multiOptions[$bill['id_bill']] = $value;
        }

        $this->setMultiOptions($multiOptions);

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }
    }
}