<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 30.11.2017
 * Time: 14:04
 */

class Bill_Form_Element_CalcStrategyRadio extends Base_Form_Element_Radio
{
    private $_defaultName       = 'calc_strategy';

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = Base::getFiledNameLabel('bill_item.calc_strategy');
        }

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }
    }


    private function _loadMultiOptions($options)
    {
        $multiOptions = array(
            BillItem::CALC_STATEGY_TASK => 'label_bill_item_calc_strategy_'.BillItem::CALC_STATEGY_TASK,
            BillItem::CALC_STATEGY_AMOUNT => 'label_bill_item_calc_strategy_'.BillItem::CALC_STATEGY_AMOUNT,
            BillItem::CALC_STATEGY_AGREEMENT => 'label_bill_item_calc_strategy_'.BillItem::CALC_STATEGY_AGREEMENT,
        );

        $this->setMultiOptions($multiOptions);
    }
}