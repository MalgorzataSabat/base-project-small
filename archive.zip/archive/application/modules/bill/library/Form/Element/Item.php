<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 30.11.2017
 * Time: 14:04
 */

class Bill_Form_Element_Item extends Base_Form_Element_Select
{
    private $_defaultName = 'id_bill_item';

    private $_options = array();

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        $this->_options = $options;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_bill_item';
        }

        $options['select2'] = array(
            'allowClear' => true
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        $options['data-url-load-list'] = Base::url('bill_ajax_get-bill-item-list');

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $this->_options) ) {
            $this->loadMultiOptions($this->_options);
        }
    }


    public function loadMultiOptions($options = array())
    {
        $multiOptions = array();
        $queryOptions = array();

        isset($options['id_bill']) && $queryOptions['id_bill'] = $options['id_bill'];

        $billItemList = BillItem::getList($queryOptions);

        foreach($billItemList as $billItem){
            $multiOptions[$billItem['id_bill_item']] = $billItem['name'];
        }

        $this->setMultiOptions($multiOptions);
    }
}