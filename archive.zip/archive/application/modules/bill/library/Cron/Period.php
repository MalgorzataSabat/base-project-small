<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 22.01.2018
 * Time: 15:22
 */

class Bill_Cron_Period
{
    /**
     * @var Zend_Log
     */
    protected $_log;

    public function __construct()
    {
        set_time_limit(180);
        ini_set("memory_limit","512M");

        $logFile = APPLICATION_DATA.DS.'logs/cron/'.date( 'Y-m-d' ) . "_bill-period.html";
        $this->_log = new Zend_Log();
        $this->_log->addWriter( new Zend_Log_Writer_Stream($logFile));
        $this->_log->info( '-------------------------------<br/>' );
    }

    public function cron()
    {
        $billPeriodList = Bill::getQuery(array(
            'hydrate' => Doctrine::HYDRATE_RECORD,
            'checkAccess' => false,
        ))
            ->addSelect('DATEDIFF(NOW(), o.period_date_next) as period_date_diff')
            ->addWhere('o.is_period = 1 AND o.id_bill_period_next IS NULL AND o.period_date_next IS NOT NULL')
            ->addHaving('period_date_diff >= 0 AND period_date_diff < 60') // tylko przez kilka dni po zakładamy kontynuacje zadania
            ->limit(25)
            ->execute();

//        var_dump($billPeriodList->toArray());
//        exit();

        $numberService = new Bill_Number();
        $billStatusDefault = Dictionary::getDefault('BillStatus');

        foreach($billPeriodList as $billPeriod)
        {
            $bill = new Bill();
            $bill['id_service'] = $billPeriod['id_service'];
            $bill['id_user'] = $billPeriod['id_user'];
            $bill['id_user_created'] = $billPeriod['id_user_created'];
            $bill['id_client'] = $billPeriod['id_client'];
            $bill['id_project'] = $billPeriod['id_project'];
            $bill['id_status'] = $billStatusDefault['id_dictionary'];
            $bill['id_contract_type'] = $billPeriod['id_contract_type'];
            $bill['id_agreement'] = $billPeriod['id_agreement'];
            $bill['number'] = $numberService->getNextNumber();
            $bill['name'] = $billPeriod['name'];
            $bill['desc'] = $billPeriod['desc'];
            $bill['tags'] = $billPeriod['tags'];
            $bill['is_period'] = $billPeriod['is_period'];
            $bill['period_range'] = $billPeriod['period_range'];
            $bill['period_end'] = $billPeriod['period_end'];

            $bill->save();

            $billPeriod['id_bill_period_next'] = $bill['id_bill'];
            $billPeriod->save();

            Bill_Service::createCloneBillItems($bill, $billPeriod);

            $this->_log->info( 'Bill Period create id: (' . $billPeriod['id_bill'] . ') => FROM: ('.$bill['id_bill'].')<br/>' );
        }

    }
}