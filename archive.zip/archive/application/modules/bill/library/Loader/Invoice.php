<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:45
 */

class Bill_Loader_Invoice extends Bill_Loader
{
    private $_list = array();

    private $_listIds = array();

    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $query = $this->_getQuery();

        $query->leftJoin('o.Items i')->addSelect('i.*');

        $this->_list = $query->execute(array(), Doctrine::HYDRATE_RECORD);
        $id_unit = Dictionary::getDefault('InvoiceUnit');
        $id_tax = Dictionary::getDefault('Tax');

        foreach($this->_list as $bill){
            $this->_listIds[] = $bill['hash'];

            foreach($bill['Items'] as $billItem){
                $item = array(
                    'name' => $billItem['name'],
                    'id_unit' => $id_unit['id_dictionary'],
                    'price' => $billItem['price_sum'],
                    'count' => 1,
                    'id_tax' => $id_tax['id_dictionary'],
                );

                $this->_result[] = array('0' => $item);
            }
        }


        return $this->_result;
    }

    public function getList()
    {
       return $this->_list;
    }

    public function getListIds()
    {
        return $this->_listIds;
    }
}