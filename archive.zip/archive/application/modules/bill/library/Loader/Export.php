<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:45
 */

class Bill_Loader_Export extends Bill_Loader
{
    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $query = $this->_getQuery();

        $query->addSelect("concat(uc.name, ' ',uc.surname) as id_user_created");
        $query->leftJoin('o.UserCreated uc');

        $query->addSelect("concat(u.name, ' ',u.surname) as id_user");
        $query->leftJoin('o.User u');

        $query->addSelect("c.name as id_client");
        $query->leftJoin('o.Client c');

        $query->addSelect("p.name as id_project");
        $query->leftJoin('o.Project p');

        $query->addSelect('s.name as id_status');
        $query->leftJoin('o.Status s');

        $query->addSelect("i.number as id_invoice");
        $query->leftJoin('o.Invoice i');

        $query->addSelect('ct.name as id_contract_type');
        $query->leftJoin('o.ContractType ct');

        if ($select) {
            $query->select($select);
        }

        $result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        $dataQuery = $this->_filter->getValuesQuery(true);

        foreach($dataQuery['column'] as $column){
            $this->_labels[$column] =  Base::getFiledName('bill.'.$column);
        }

        foreach($result as $k => $data){
            foreach ($dataQuery['column'] as $column) {
                switch($column){
                    case 'count':{}
                    case 'price':{}
                    case 'price_sum':{
                        $this->_result[$k][$column] = number_format($data[$column], 2, ',', '');
                        break;
                    }
                    case 'tags':{
                        $this->_result[$k][$column] = join(', ', json_decode($data[$column], true));
                        break;
                    }
                    default:{
                        $this->_result[$k][$column] = trim(strip_tags($data[$column]));
                    }
                }
            }
        }

        unset($result);

        return $this->_result;
    }
}