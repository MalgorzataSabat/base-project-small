<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 13:29
 */

class Bill_Number extends Base_Number
{
    protected $_formatKey = 'bill.number_format';

    protected $_colName = 'number';



    protected function _getRecords()
    {
        return Bill::getQuery(array('archived_at' => '', 'checkAccess' => false))
            ->select('o.number')
            ->addWhere('o.number REGEXP ?', $this->_searchSql)
            ->execute();
    }


}