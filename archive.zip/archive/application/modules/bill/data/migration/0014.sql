ALTER TABLE `bill_item` ADD `is_default` BOOLEAN NOT NULL AFTER `name`;
ALTER TABLE `bill_item` CHANGE `is_default` `is_default` TINYINT(1) NOT NULL COMMENT 'Czy jest to wartość domyślna. Do tego wpisu będą automatycznie przypisywane zadania.';


