SET @idAclBillRead = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_read');
SET @idAclBillWrite = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillRead, 'bill_ajax_get-list');

DELETE FROM `acl_resource_item` WHERE `name` = 'bill_index_assing-task';
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_assign-task');
