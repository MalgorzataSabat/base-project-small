INSERT INTO `layout` (`id_layout`, `id_service`, `type`, `id_layout_template`, `id_user`, `name`, `data_map`, `is_default`, `is_public`) VALUES (NULL, NULL, 'bill_card', '12', NULL, 'Karta rozliczenia', '{\"main\":{\"widgets\":{\"1522745660\":{\"_class\":\"Bill_Widget_Card\"}}},\"right\":{\"widgets\":{\"1522745668\":{\"_class\":\"Bill_Widget_Finance\"}}}}', '1', '1');

SET @idAclExport = (SELECT id_acl_resource FROM acl_resource WHERE name = 'export');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`) VALUES (@idAclExport, 'export_bill', 'Eksport rozliczeń');
