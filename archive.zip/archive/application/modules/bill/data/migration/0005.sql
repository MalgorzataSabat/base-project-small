ALTER TABLE task DROP FOREIGN KEY task_bill_item;
ALTER TABLE `bill_item` CHANGE `id_bill_item` `id_bill_item` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator elementu rachunku';
ALTER TABLE `task` ADD CONSTRAINT `task_bill_item` FOREIGN KEY (`id_bill_item`) REFERENCES `bill_item`(`id_bill_item`) ON DELETE SET NULL ON UPDATE RESTRICT;

SET @idAclBillWrite = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_assing-task');
INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'bill.max_task_assign', '100');
