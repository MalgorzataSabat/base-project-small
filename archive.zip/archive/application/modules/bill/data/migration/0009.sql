SET @idAclBillRead = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillRead, 'bill_index_clone');
