INSERT INTO `layout_template` (`id_layout_template`, `id_service`, `is_default`, `is_system`, `name`, `filename`, `data_map`) VALUES (NULL, NULL, '0', '0', 'Layout podzielony (2 x 6 kolumn) + 12 kolumn', 'dashboard-2x6+12', '{\"main\":[],\"right\":[],\"bottom\":[]}');
update `layout` set `id_layout_template` = 13 WHERE `type` = 'bill_card';

UPDATE `layout` SET `data_map` = '{\"main\":{\"widgets\":{\"1522745660\":{\"_class\":\"Bill_Widget_Card\"}}},\"right\":{\"widgets\":{\"1522745668\":{\"_class\":\"Bill_Widget_Finance\"}}},\"bottom\":{\"widgets\":{\"1522745668\":{\"_class\":\"Bill_Widget_Item\"}}}}' WHERE `type` = 'bill_card';

SET @idAclBillWrite = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_item_new');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_item_edit');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_item_archive');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_item_delete');

ALTER TABLE `bill_item` ADD `calc_strategy` TINYINT UNSIGNED NOT NULL COMMENT 'Stratega liczenia: 0 -brak; 1 - stawka godzinowa; 2 - stawka kwotowa ' AFTER `name`;

INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'bill.default_item_calc_strategy', '1');

