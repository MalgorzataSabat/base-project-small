INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'bill.contract_type_on', '0');
ALTER TABLE `bill` ADD `id_contract_type` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Rodzaj umowy' AFTER `id_invoice`, ADD INDEX (`id_contract_type`);

