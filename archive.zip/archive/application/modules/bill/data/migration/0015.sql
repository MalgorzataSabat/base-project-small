ALTER TABLE `bill`  ADD `is_period` BOOLEAN NOT NULL COMMENT 'Czy jest to rozliczenie cykliczne'  AFTER `price_sum`,  ADD `period_range` DATE NULL DEFAULT NULL COMMENT 'Okres rozliczenia cyklicznego'  AFTER `is_period`,  ADD `period_end` DATE NULL DEFAULT NULL COMMENT 'Koniec okredu cykliczego; NULL - bez daty zakończenia, bezterminowo'  AFTER `period_range`,  ADD `id_bill_period_next` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator następnego wystawionego rozliczenia'  AFTER `period_end`;
ALTER TABLE `bill` CHANGE `period_range` `period_range` VARCHAR(255) NULL DEFAULT NULL COMMENT 'Okres rozliczenia cyklicznego';

INSERT INTO `cron` (`id_cron`, `service`, `is_active`, `description`, `last_execution_at`, `frequency`) VALUES (NULL, 'Bill_Cron_Period', '1', 'Cykliczność rozliczeń', CURRENT_TIMESTAMP, '7200');
ALTER TABLE `bill` ADD `period_date_next` DATE NULL DEFAULT NULL COMMENT 'Data założenia następnego rozliczenia' AFTER `period_end`;
ALTER TABLE `bill` ADD INDEX(`id_bill_period_next`);

ALTER TABLE `bill` ADD CONSTRAINT `bill_period_next` FOREIGN KEY (`id_bill_period_next`) REFERENCES `bill`(`id_bill`) ON DELETE SET NULL ON UPDATE RESTRICT;
