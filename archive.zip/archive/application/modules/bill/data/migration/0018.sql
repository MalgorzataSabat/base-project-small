SET @idAclBill = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES (@idAclBill, 'bill_full', 'Pełna lista rozliczeń', 'bill');
