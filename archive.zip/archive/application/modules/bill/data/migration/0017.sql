INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'bill.item_agreement_alert_percent', '75');
ALTER TABLE `bill_item` ADD `package_count_max` DOUBLE(6,2) NULL DEFAULT NULL COMMENT 'Maksymalna ilość godzin w pakiecie' AFTER `package_count_out`;
