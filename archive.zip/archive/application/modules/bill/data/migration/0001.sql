CREATE TABLE IF NOT EXISTS `bill` (
  `id_bill` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator rachunku',
  `hash` char(32) NOT NULL COMMENT 'Hash',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia rachunku',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data ostatniej modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `id_user_created` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator użytkownika który dodał rachunek',
  `id_user` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator przypisanego użytkownika',
  `id_client` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator klienta',
  `id_project` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator projektu',
  `id_status` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator statusu',
  `id_invoice` int(255) UNSIGNED DEFAULT NULL COMMENT 'Idantyfikator faktury',
  `number` varchar(255) NOT NULL COMMENT 'Numer rachunku',
  `name` varchar(255) NOT NULL COMMENT 'Tytuł rachunku',
  `desc` text NOT NULL COMMENT 'Opis rachunku',
  `count` double(10,2) NOT NULL COMMENT 'Ilość, np: przepracowanych godzin',
  `price` double(10,2) NOT NULL COMMENT 'Cena jednostkowa, np: średnia stawka',
  `price_sum` double(10,2) NOT NULL COMMENT 'Wartość rachunku',
  PRIMARY KEY (`id_bill`),
  UNIQUE KEY `hash` (`hash`),
  KEY `id_service` (`id_service`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `id_project` (`id_project`),
  KEY `id_status` (`id_status`),
  KEY `id_invoice` (`id_invoice`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Baza danych rachunków';

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL,
  ADD CONSTRAINT `bill_invoice` FOREIGN KEY (`id_invoice`) REFERENCES `invoice` (`id_invoice`) ON DELETE SET NULL,
  ADD CONSTRAINT `bill_project` FOREIGN KEY (`id_project`) REFERENCES `project` (`id_project`) ON DELETE SET NULL,
  ADD CONSTRAINT `bill_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`) ON DELETE CASCADE,
  ADD CONSTRAINT `bill_status` FOREIGN KEY (`id_status`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  ADD CONSTRAINT `bill_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  ADD CONSTRAINT `bill_user_created` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL;


CREATE TABLE IF NOT EXISTS `bill_item` (
  `id_bill_item` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator elementu rachunku',
  `hash` char(32) NOT NULL COMMENT 'Hash',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia rachunku',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data ostatniej modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `id_bill` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator rachunku',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa elementu',
  `count` double(10,2) NOT NULL COMMENT 'Ilość',
  `id_unit` int(10) UNSIGNED DEFAULT NULL COMMENT 'Jednostka',
  `price` double(10,2) NOT NULL COMMENT 'Cena jednostkowa',
  `price_sum` double(10,2) NOT NULL COMMENT 'Suma wartości',
  UNIQUE KEY `hash` (`hash`),
  KEY `id_bill_item` (`id_bill_item`),
  KEY `id_service` (`id_service`),
  KEY `id_bill` (`id_bill`),
  KEY `id_unit` (`id_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `bill_item`
--
ALTER TABLE `bill_item`
  ADD CONSTRAINT `bill_item_bill` FOREIGN KEY (`id_bill`) REFERENCES `bill` (`id_bill`) ON DELETE CASCADE,
  ADD CONSTRAINT `bill_item_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`) ON DELETE CASCADE,
  ADD CONSTRAINT `bill_item_unit` FOREIGN KEY (`id_unit`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL;

ALTER TABLE `task` ADD `id_bill` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator rachunku' AFTER `finance_amount`, ADD `id_bill_item` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator elementu rachunku' AFTER `id_bill`;
ALTER TABLE `task` ADD INDEX(`id_bill`);
ALTER TABLE `task` ADD INDEX(`id_bill_item`);

ALTER TABLE `task` ADD CONSTRAINT `task_bill` FOREIGN KEY (`id_bill`) REFERENCES `bill`(`id_bill`) ON DELETE SET NULL ON UPDATE RESTRICT; ALTER TABLE `task` ADD CONSTRAINT `task_bill_item` FOREIGN KEY (`id_bill_item`) REFERENCES `bill_item`(`id_bill_item`) ON DELETE SET NULL ON UPDATE RESTRICT;

INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'bill.return_route', 'bill_show');

INSERT INTO `acl_resource` (`id_acl_resource`, `id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (NULL, NULL, 'bill', 'Rachunki', 'bill', '', '', '', '');

SET @idAclBill = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`) VALUES (@idAclBill, 'bill_read', 'Przeglądanie');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`) VALUES (@idAclBill, 'bill_write', 'Zarządzanie');

SET @idAclBillRead = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_read');
SET @idAclBillWrite = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillRead, 'bill_index_index');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillRead, 'bill_index_show');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_new');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_edit');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_archive');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillWrite, 'bill_index_delete');

ALTER TABLE `bill` ADD `tags` TEXT NOT NULL COMMENT 'Tagi' AFTER `price_sum`;
