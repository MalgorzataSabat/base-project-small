ALTER TABLE `bill_item` CHANGE `calc_strategy` `calc_strategy` TINYINT(3) UNSIGNED NOT NULL COMMENT 'Stratega liczenia: 0 -brak; 1 - stawka godzinowa; 2 - stawka kwotowa; 3 - wg umowy';
SET @idAclBillRead = (SELECT id_acl_resource FROM acl_resource WHERE name = 'bill_write');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclBillRead, 'bill_index_recalculate');


