ALTER TABLE `bill` ADD `id_agreement` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfikator umowy' AFTER `id_contract_type`, ADD INDEX (`id_agreement`);
ALTER TABLE `bill` ADD CONSTRAINT `bill_agreement` FOREIGN KEY (`id_agreement`) REFERENCES `agreement`(`id_agreement`) ON DELETE SET NULL ON UPDATE RESTRICT;

