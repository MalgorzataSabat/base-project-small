<?php

class Bill_IndexController extends Base_Controller_Action
{
    /**
     * @var Bill
     */
    private $_bill;

    /**
     * @var Bill
     */
    private $_billCloneFrom;

    /**
     * @var array
     */
    private $_taskList;

    private $_assignTaskIdClient = null;

    private $_assignTaskError = null;

    private $_assignTaskWarning = array();

    public function indexAction()
    {
        $formFilter = new Bill_Form_Filter();
        $dataQuery = $formFilter->getValuesQuery(true);

        $query = Bill::getQuery($dataQuery);

        $this->view->massActionOptions = array();
        if($this->view->hasAccess('export_bill')){
            $this->view->massActionOptions['export'] = array(
                'url' => Base::url('export', array('object' => 'bill')),
                'name' => $this->view->translate('mass-options_export')
            );
        }

        if($this->view->hasAccess('invoice_write')){
            $this->view->massActionOptions['invoice'] = array(
                'url' => Base::url('invoice_new'),
                'name' => $this->view->translate('mass-options_invoice_create')
            );
        }

        $this->view->billList = $this->_helper->paging($query);
        $this->view->formFilter = $formFilter;
    }

    public function showAction()
    {
        $this->_bill = Bill::find($this->getParam('id_bill'));
        $this->forward404Unless($this->_bill);

        $layoutService = new Layout_Service('bill_card');
        $layoutService->setLoader('Bill_Widget_Loader', array(
            'model' => $this->_bill
        ));

        $this->view->layoutService = $layoutService;
        $this->view->bill = $this->_bill;
    }

    public function newAction()
    {
        $this->_bill = new Bill();
        $this->_bill['id_user'] = Base_Auth::getUserId();
        $this->_bill['id_client'] = $this->getParam('id_client');
        $this->_bill['id_project'] = $this->getParam('id_project');

        $numberService = new Bill_Number();
        $this->_bill['number'] = $numberService->getNextNumber();

        $this->_formBill();
    }

    public function editAction()
    {
        $this->_bill = Bill::findRecord($this->getParam('id_bill'));
        $this->forward404Unless($this->_bill);

        $this->_formBill();
    }

    public function cloneAction()
    {
        $this->_billCloneFrom = Bill::findRecord($this->getParam('id_bill'));
        $this->forward404Unless($this->_billCloneFrom);

        $numberService = new Bill_Number();

        $this->_bill = new Bill();
        $this->_bill['id_user'] = Base_Auth::getUserId();
        $this->_bill['id_client'] = $this->_billCloneFrom['id_client'];
        $this->_bill['id_project'] = $this->_billCloneFrom['id_project'];
        $this->_bill['id_agreement'] = $this->_billCloneFrom['id_agreement'];
        $this->_bill['id_contract_type'] = $this->_billCloneFrom['id_contract_type'];
        $this->_bill['number'] = $numberService->getNextNumber();
        $this->_bill['name'] = $this->_billCloneFrom['name'];
        $this->_bill['desc'] = $this->_billCloneFrom['desc'];
        $this->_bill['tags'] = $this->_billCloneFrom['tags'];
        $this->_bill['is_period'] = $this->_billCloneFrom['is_period'];
        $this->_bill['period_range'] = $this->_billCloneFrom['period_range'];
        $this->_bill['period_end'] = $this->_billCloneFrom['period_end'];

        $this->_formBill();
    }


    private function _formBill()
    {
        $this->_helper->viewRenderer('form');

        $form = new Bill_Form_Bill(array('model' => $this->_bill));
        if ( $this->_request->isPost() && $form->isValid( $this->_request->getPost())){

            $this->_bill->save();

            if($this->_billCloneFrom){
                Bill_Service::createCloneBillItems($this->_bill, $this->_billCloneFrom);
            }

            Bill_Service::syncTaskStatus($this->_bill);

            $this->_flash()->success->addMessage('label_save_success');

            $returnUrl = $this->_getReturnUrl();
            $this->_redirector()->gotoUrlAndExit($returnUrl);
        }

        $this->view->model = $this->_bill;
        $this->view->form = $form;
    }

    public function recalculateAction()
    {
        $this->_bill = Bill::findRecord($this->getParam('id_bill'));
        $this->forward404Unless($this->_bill);

        if(Dictionary::getIsClosedById($this->_bill['id_status'])){
            $this->_flash()->warning->addMessage('Rozliczenie jest już zamknięte. Przeliczenie dostępne jest tylko dla otwartych rozliczeń.');
            $this->_gotoReturnUrl();
        }

        Bill_Service::recalculateBillPrice($this->_bill['id_bill']);

        $this->_flash()->success->addMessage('Wartość rozliczenia została przeliczona.');
        $this->_gotoReturnUrl();
    }


    public function assignTaskAction()
    {
        if($this->_request->isPost() && $this->hasParam('Bill_Form_AssignTask')){
            $formParams = $this->_getParam('Bill_Form_AssignTask');
            $idValue = (array) array_filter(explode(',',$formParams['value']));
            $allValue = $formParams['all'];
        }else{
            $idValue = $this->_getParam('massItems', $this->getParam('id_task'));
            $idValue = (array) array_filter(explode(',',$idValue));
            $allValue = $this->getParam('massItemAllPage', 0);
        }

        $options = array('value' => $idValue, 'all' => $allValue);
        $form = false;

        $taskLoader = new Task_Loader($options);
        $this->_taskList = $taskLoader->getResult();

        $this->_validateAssignTask($this->_taskList);

        if($this->_assignTaskError){
            $this->_helper->viewRenderer('assign-task-error');
        }else{
            $formOptions = array(
                'data' => $options,
                'idClient' => $this->_assignTaskIdClient,
            );

            $form = new Bill_Form_AssignTask($formOptions);

            if($this->_request->isPost() && $this->hasParam('Bill_Form_AssignTask') && $form->isValid($this->_request->getPost())){

                $billService = new Bill_Service(array(
                    'id_bill' => $form->getValue('id_bill'),
                    'id_bill_item' => $form->getValue('id_bill_item'),
                    'task_list' => $this->_taskList,
                ));
                $billService->assignTask();

                $this->_bill = Bill::find($form->getValue('id_bill'));
                $returnUrl = $this->_getReturnUrl(null, null, 'bill.return_assign_route');

                if ($this->_request->isXmlHttpRequest()) {
                    $this->view->returnUrl = $returnUrl;
                    $this->_helper->viewRenderer('assign-ajax-result');
                } else {
                    $this->_redirector()->gotoUrlAndExit($returnUrl);
                }
            }

        }

        $this->view->taskList = $this->_taskList;
        $this->view->assignTaskError = $this->_assignTaskError;
        $this->view->assignTaskWarning = $this->_assignTaskWarning;
        $this->view->assignTaskIdClient = $this->_assignTaskIdClient;
        $this->view->form = $form;
    }

    private function _validateAssignTask()
    {
        if(!count($this->_taskList)){
            $this->_assignTaskError = 'error_assign_bill_to_task_empty';
            return false;
        }

        if(count($this->_taskList) > Setting::getSetting('bill.max_task_assign')){
            $this->_assignTaskError = 'error_assign_bill_to_task_too_much';
            return false;
        }

        $assignTaskBill = array();
        $assignTaskClient = array();
        foreach($this->_taskList as $task){
            $assignTaskClient[] = $task['id_client'];
            $assignTaskBill[] = $task['id_bill'];
        }

        $assignTaskClient = array_unique(array_filter($assignTaskClient));
        $assignTaskBill = array_unique(array_filter($assignTaskBill));

        if(count($assignTaskClient) > 1){
            $this->_assignTaskError = 'error_assign_bill_to_task_client_more';
            return false;
        }

        if($assignTaskClient){
            $this->_assignTaskIdClient = array_values($assignTaskClient)[0];
        }


        $queryOptions = array(
            'id_client' => $this->_assignTaskIdClient,
            'id_status' => array('type' => 'open', 'value' => ''),
        );
        $billList = Bill::getList($queryOptions);

        if(!$billList){
            $this->_assignTaskError = 'error_assign_bill_to_task_no_open_bill';
            return false;
        }

        if(count($assignTaskBill)){
            $this->_assignTaskWarning[] = 'warning_assign_bill_to_task_has_bill';
        }

        return true;
    }


    public function archiveAction()
    {
        $this->_bill = Bill::findRecord($this->_getParam('id_bill'));
        $this->forward403Unless($this->_bill);

        $this->_bill->archived_at = $this->_bill->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_bill->save();

        Doctrine_Query::create()
            ->update('Task o')
            ->set('o.id_bill_item', 'NULL')
            ->set('o.id_bill', 'NULL')
            ->where('o.id_bill = ?', $this->_bill['id_bill'])
            ->execute();

        if ( $this->_bill->archived_at ) {
            $this->_flash()->success->addMessage('label_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_unarchive_success');
        }

        $this->_gotoReturnUrl();
    }

    public function deleteAction()
    {
        $this->_bill = Bill::findRecord($this->_getParam('id_bill'));
        $this->forward403Unless($this->_bill);

        $id_bill = $this->_bill['id_bill'];
        $this->_bill->delete();

        Doctrine_Query::create()
            ->update('Task o')
            ->set('o.id_bill_item', 'NULL')
            ->set('o.id_bill', 'NULL')
            ->where('o.id_bill = ?', $id_bill)
            ->execute();

        $this->_flash()->success->addMessage('label_delete_success');

        $this->_gotoReturnUrl();
    }

    protected function _getReturnUrl($route = 'bill', $params = array(), $key = 'bill.return_route')
    {
        Setting::getSetting($key) && $route = Setting::getSetting($key);
        !$route && $route = 'bill';

        if(isset($this->_bill) && $this->_bill){
            $params['id_bill'] = $this->_bill['hash'];
        }

        return Base::url($route, $params);
    }
}