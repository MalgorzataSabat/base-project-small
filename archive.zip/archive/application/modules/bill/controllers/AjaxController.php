<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Bill_AjaxController extends Base_Controller_Action
{

    public function getListAction()
    {
        $queryOptions = array();
        if(($id_client = $this->getParam('id_client'))){
            $queryOptions['id_client'] = $id_client;
        }

        $billList = Bill::getList($queryOptions);

        $this->_helper->json($billList);
    }

    public function getBillItemListAction()
    {
        $queryOptions = array();
        if(($id_bill = $this->getParam('id_bill'))){
            $queryOptions['id_bill'] = $id_bill;
        }

        $billItemList = BillItem::getList($queryOptions);

        $this->_helper->json($billItemList);
    }



}