<?php

class Bill_ItemController extends Base_Controller_Action
{
    /**
     * @var BillItem
     */
    private $_billItem;

    /**
     * @var Bill
     */
    private $_bill;


    public function newAction()
    {
        $this->_bill = Bill::find($this->_getParam('id_bill'));
        $this->forward404Unless($this->_bill);

        $this->_billItem = new BillItem();
        $this->_billItem['id_bill'] = $this->_bill['id_bill'];
        $this->_billItem['calc_strategy'] = Setting::getSetting('bill.default_item_calc_strategy');

        $this->_formBill();
    }

    public function editAction()
    {
        $this->_billItem = BillItem::findRecord($this->getParam('id_bill_item'));
        $this->forward404Unless($this->_billItem);

        $this->_bill = $this->_billItem->Bill;

        $this->_formBill();
    }


    private function _formBill()
    {
        $this->_helper->viewRenderer('form');

        $form = new Bill_Form_Item(array('model' => $this->_billItem));
        if ( $this->_request->isPost() && $form->isValid( $this->_request->getPost())){

            Bill_Service::recalculateBillPrice($this->_billItem['id_bill']);

            $this->_flash()->success->addMessage('label_save_success');

            if ($this->_request->isXmlHttpRequest()) {
                $this->_helper->viewRenderer('form-ajax-result');
            } else {
                $returnUrl = $this->_getReturnUrl();
                $this->_redirector()->gotoUrlAndExit($returnUrl);
            }
        }

        $this->view->model = $this->_billItem;
        $this->view->form = $form;
    }

    public function archiveAction()
    {
        $this->_billItem = BillItem::findRecord($this->getParam('id_bill_item'));
        $this->forward404Unless($this->_billItem);

        $this->_bill = $this->_billItem->Bill;
        $this->_billItem->archived_at = $this->_billItem->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_billItem->save();

        Doctrine_Query::create()
            ->update('Task o')
            ->set('o.id_bill_item', 'NULL')
            ->set('o.id_bill', 'NULL')
            ->where('o.id_bill_item = ?', $this->_billItem['id_bill_item'])
            ->execute();

        Bill_Service::updateBillPrice($this->_bill['id_bill']);

        if ( $this->_billItem->archived_at ) {
            $this->_flash()->success->addMessage('label_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_unarchive_success');
        }

        $this->_gotoReturnUrl();
    }

    public function deleteAction()
    {
        $this->_billItem = BillItem::findRecord($this->getParam('id_bill_item'));
        $this->forward404Unless($this->_billItem);

        $this->_bill = $this->_billItem->Bill;
        $this->_billItem->delete();

        Doctrine_Query::create()
            ->update('Task o')
            ->set('o.id_bill_item', 'NULL')
            ->set('o.id_bill', 'NULL')
            ->where('o.id_bill_item = ?', $this->_billItem['id_bill_item'])
            ->execute();

        Bill_Service::recalculateBillPrice($this->_bill['id_bill']);

        $this->_flash()->success->addMessage('label_delete_success');

        $this->_gotoReturnUrl();
    }

    protected function _getReturnUrl($route = 'bill', $params = array())
    {
        Setting::getSetting('bill.return_route') && $route = Setting::getSetting('bill.return_route');
        !$route && $route = 'bill';

        if(isset($this->_bill) && $this->_bill){
            $params['id_bill'] = $this->_bill['hash'];
        }

        return Base::url($route, $params);
    }

}