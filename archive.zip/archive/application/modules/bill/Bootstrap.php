<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 13:57
 */

class Bill_Bootstrap extends Base_Application_Module_Bootstrap
{

    public function _initWidget()
    {
        if(DEV){
            Base_Widget::registerWidget('Bill_Widget_Card');
            Base_Widget::registerWidget('Bill_Widget_Finance');
            Base_Widget::registerWidget('Bill_Widget_Item');
            Base_Widget::registerWidget('Bill_Widget_List');
        }
    }

}