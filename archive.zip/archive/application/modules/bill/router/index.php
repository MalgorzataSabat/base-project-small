<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('bill', new Zend_Controller_Router_Route(
    '/@bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('bill_assign-task', new Zend_Controller_Router_Route(
    '/@bill/assign-task',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'assign-task'
    )
));


$router->addRoute('bill_show', new Zend_Controller_Router_Route(
    '/@bill/@show/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_new', new Zend_Controller_Router_Route(
    '/@bill/@new',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'new'
    )
));

$router->addRoute('bill_edit', new Zend_Controller_Router_Route(
    '/@bill/@edit/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_clone', new Zend_Controller_Router_Route(
    '/@bill/@clone/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'clone'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_recalculate', new Zend_Controller_Router_Route(
    '/@bill/@recalculate/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'recalculate'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));


$router->addRoute('bill_archive', new Zend_Controller_Router_Route(
    '/@bill/@archive/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'archive'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_delete', new Zend_Controller_Router_Route(
    '/@bill/@delete/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);