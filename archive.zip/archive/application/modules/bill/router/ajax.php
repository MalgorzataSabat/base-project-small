<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('bill_ajax_get-list', new Zend_Controller_Router_Route(
    '/@bill/ajax/get-list',
    array(
        'module' => 'bill',
        'controller' => 'ajax',
        'action' => 'get-list',
    )
));

$router->addRoute('bill_ajax_get-bill-item-list', new Zend_Controller_Router_Route(
    '/@bill/ajax/get-bill-item-list',
    array(
        'module' => 'bill',
        'controller' => 'ajax',
        'action' => 'get-bill-item-list',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
