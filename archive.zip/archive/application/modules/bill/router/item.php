<?php
$router = Zend_Controller_Front::getInstance()->getRouter();


$router->addRoute('bill_item_new', new Zend_Controller_Router_Route(
    '/@bill/@bill-item/@new/:id_bill',
    array(
        'module' => 'bill',
        'controller' => 'item',
        'action' => 'new'
    ),
    array(
        'id_bill' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_item_edit', new Zend_Controller_Router_Route(
    '/@bill/@bill-item/@edit/:id_bill_item',
    array(
        'module' => 'bill',
        'controller' => 'item',
        'action' => 'edit'
    ),
    array(
        'id_bill_item' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_item_archive', new Zend_Controller_Router_Route(
    '/@bill/@bill-item/@archive/:id_bill_item',
    array(
        'module' => 'bill',
        'controller' => 'item',
        'action' => 'archive'
    ),
    array(
        'id_bill_item' => '([0-9a-f]{32})',
    )
));

$router->addRoute('bill_item_delete', new Zend_Controller_Router_Route(
    '/@bill/@bill-item/@delete/:id_bill_item',
    array(
        'module' => 'bill',
        'controller' => 'item',
        'action' => 'delete'
    ),
    array(
        'id_bill_item' => '([0-9a-f]{32})',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);