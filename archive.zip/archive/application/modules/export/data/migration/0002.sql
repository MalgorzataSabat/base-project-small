SET @id_acl_resource_export = (SELECT `id_acl_resource` FROM `acl_resource` WHERE `name` = 'export');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES (@id_acl_resource_export, 'export_invoice', 'Eksport faktur', 'export');


