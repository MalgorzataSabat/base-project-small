INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES ( NULL, 'export', 'Eksport', 'export');
SET @id_acl_resource_export = LAST_INSERT_ID();

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES ( @id_acl_resource_export, 'export_client', 'Eksport', 'export');
SET @id_acl_resource_export_client = LAST_INSERT_ID();
INSERT INTO `acl_resource_item` (`id_acl_resource`, `name`) VALUES (@id_acl_resource_export_client, 'export_index_index');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES ( @id_acl_resource_export, 'export_person', 'Eksport', 'export');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`) VALUES ( @id_acl_resource_export, 'export_task', 'Eksport', 'export');

INSERT INTO `acl_rule` (`id_acl_rule`, `is_allow`, `role`, `resource`) VALUES (NULL, '1', 'admin', 'export');