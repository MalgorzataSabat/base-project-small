<?php


abstract class Export_Exporter_Abstract implements Export_Exporter_Interface
{

    protected $_data = array();
    protected $_dataLabels = array();


    /**
     * @return array
     */
    public function getData()
    {
        return $this->_data;
    }

    /**
     * @param $data
     * @return $this
     */
    public function setData($data)
    {
        $this->_data = $data;

        return $this;
    }

    /**
     * @return array
     */
    public function getLabels()
    {
        return $this->_dataLabels;
    }

    /**
     * @param $data
     * @return $this
     */
    public function setLabels($data)
    {
        $this->_dataLabels = $data;

        return $this;
    }


}