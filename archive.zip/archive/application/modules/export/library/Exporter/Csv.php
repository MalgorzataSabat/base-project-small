<?php


class Export_Exporter_Csv extends Export_Exporter_Abstract
{
    private $_separator = ';';

    public function export()
    {
        $filename = 'export.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename='. $filename);
//        header('Pragma: no-cache');
//        header("Expires: 0");
        //return fopen('php://output', 'w');
        $fp = fopen('php://output', 'w');
        //$fp = $this->setHeader();
        if($this->_dataLabels){
            fputcsv($fp, $this->_dataLabels, $this->_separator);
        }

        foreach ($this->getData() as $fields) {
            fputcsv($fp, $fields, $this->_separator);

        }
        fclose($fp);
        exit();
    }

    public function setSeparator($separator)
    {
        $this->_separator = $separator;
        return $this;
    }
}