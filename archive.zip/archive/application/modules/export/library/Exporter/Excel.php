<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 05.03.2018
 * Time: 10:07
 */

class Export_Exporter_Excel extends Export_Exporter_Abstract
{
    public function export()
    {
        header('Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="export_'.date('Y-m-d_H-i').'.xlsx"');
        header('Cache-Control: max-age=0');
        $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        PhpOffice\PhpSpreadsheet\Settings::setLocale('pl');

        $colNumber = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        $i = 0;
        foreach($this->_dataLabels as $key => $name){
            $sheet->setCellValue($colNumber[$i].'1', $name);
            $i++;
        }

        $rowNumber = 2;
        foreach($this->getData() as $data)
        {
            $colValue = array_values($data);
            for($i = 0;$i < count($colValue);$i++)
            {
                $sheet->setCellValue($colNumber[$i].$rowNumber, $colValue[$i]);
            }
            $rowNumber++;
        }

        $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
}