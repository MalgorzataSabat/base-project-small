<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 02.03.2018
 * Time: 11:11
 */

class Export_Exporter_Xml extends Export_Exporter_Abstract
{

    public function export()
    {
        $name = 'export_'.date('Y-m-d_H-i').'.xml';
        header('Content-Disposition: attachment;filename=' . $name);
        header('Content-Type: text/xml');

        $XML = new SimpleXMLElement("<records></records>");
        $XML->addAttribute('count', count($this->getData()));
        foreach($this->getData() as $v){
            $xmlProduct = $XML->addChild('record');
            foreach($v as $kk => $vv){
                $xmlProduct->addChild($kk, $vv);
            }
        }

        echo $XML->asXML();
        exit;
    }

}