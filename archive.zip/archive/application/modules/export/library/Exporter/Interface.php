<?php

interface Export_Exporter_Interface
{

    public function export();

}
