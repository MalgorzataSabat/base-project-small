<?php

class Export_Service
{

    private $_data = null;
    private $_dataLabels = null;

    /**
     * @var Export_Loader_Abstract
     */
    private $_loader;

    private $_format = 'csv';

    private $_encoding  = 'utf8';

    private $_separator = ';';

    private $_object;

    public function setLoader($loaderClass, $options = array())
    {
        if(!class_exists($loaderClass)){
            throw new Exception('Loader Not Exists: '.$loaderClass);
        }

        $this->_loader = new $loaderClass($options);
    }


    /**
     * @param $encoding
     * @return $this
     */
    public function setEncoding($encoding)
    {
        $this->_encoding = $encoding;

        return $this;
    }

    /**
     * @param $format
     * @return $this
     */
    public function setFormat($format)
    {
        $this->_format = $format;

        return $this;
    }

    public function setSeparator($separator)
    {
        $this->_separator = $separator;
        return $this;
    }

    public function setObject($object)
    {
        $this->_object = $object;
    }


    public function execute()
    {
        $this->_data = $this->_loader->getResult();
        $this->_dataLabels = $this->_loader->getLabels();

        if($this->_encoding != 'utf8'){
            $this->_changeEncoding();
        }

        $exporterClass = 'Export_Exporter_'.ucfirst($this->_format);
        $exporter = new $exporterClass();

        if($this->_format == 'csv') {
            $exporter->setSeparator($this->_separator);
        }

        $exporter->setData($this->_data);
        $exporter->setLabels($this->_dataLabels);

        $exporter->export();


        // export done and exit;

    }

    private function _changeEncoding()
    {
        foreach($this->_dataLabels as $k => $data)
        {
            $this->_dataLabels[$k] = iconv('utf-8', $this->_encoding, $data);

        }

        foreach($this->_data as $k => $v){
            foreach($v as $kk => $vv){
                $this->_data[$k][$kk] = iconv('utf-8', $this->_encoding, $vv);
            }
        }
    }

}