<?php

class Export_IndexController extends Base_Controller_Action
{

	/**
	 * @var Export_Form_Format
	 */
	private $_form;

	public function indexAction()
	{
		$object = strtolower($this->getParam('object'));
        if(!$this->_acl->hasAccess('export_'.$object)){
            $this->forward403('Brak dostępu do zasobu.');
        }

		$this->_form = new Export_Form_Format(array('data' => array(
			'ids' => $this->getParam('massItems'),
			'all' => $this->getParam('massItemAllPage'),
		)));

		$url = '';

		if ( $this->_request->isPost() && $this->hasParam($this->_form->getElementsBelongTo())
			&& $this->_form->isValid($this->_request->getPost())) {
			$ids = (array) explode(',', $this->_form->getValue('ids'));
			$all = (bool) $this->_form->getValue('all');
			$format = $this->_form->getValue('format');
			$encoding = $this->_form->getValue('encoding');
			$separator = $this->_form->getValue('separator');

			$exportService = new Export_Service();
			$loaderClass = ucfirst($object).'_Loader_Export';
			$loaderOptions = array('value' => $ids, 'all' => $all, 'dataQuery' => $this->getParam('dataQuery'));

			$exportService->setLoader($loaderClass, $loaderOptions);
			$exportService->setFormat($format);
			$exportService->setEncoding($encoding);
            $exportService->setSeparator($separator);
            $exportService->setObject($object);
			$exportService->execute();

            $this->_helper->viewRenderer('form-ajax-result');
			//exit();

		}

		$this->view->url = $url;
		$this->view->form = $this->_form;
		$this->view->countItems = $this->getParam('countItems');
		$this->view->placeholder( 'page-title' )->set( $this->view->translate('page-title_export') );
	}

}
