<?php


class Export_Form_Format extends Base_Form_Horizontal
{

    protected $_data;

    protected function setData($data)
    {
        $this->_data = $data;
    }

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['ids'] = $this->createElement('hidden', 'ids', array('value' => $this->_data['ids']));
        $fields['ids']->setDecorators(array('ViewHelper'));
        $fields['all'] = $this->createElement('hidden', 'all', array('value' => $this->_data['all']));
        $fields['all']->setDecorators(array('ViewHelper'));

        $fields['format'] = $this->createElement('radio', 'format', array(
            'label' => $this->_tlabel.'format',
            'allowEmpty' => false,
            'required' => true,
            'label-size' => 4, 'size' => 8,
            'inline' => true,
            'value' => 'csv',
            'multiOptions' => array(
                'csv' => 'CSV',
                'xml' => 'XML',
                'excel' => 'Excel'
            ),
            'class' => 'format ',
        ));

        $fields['encoding'] = $this->createElement('select', 'encoding', array(
            'label' => $this->_tlabel.'encoding',
            'allowEmpty' => false,
            'required' => true,
            'label-size' => 4, 'size' => 8,
            'inline' => true,
            'value' => 'windows-1250',
            'multiOptions' => array(
                'utf8' => 'UTF-8',
                'windows-1250' => 'Windows-1250',
                'iso-8859-2' => 'ISO-8859-2'
            ),
            'class' => 'encoding ',
        ));

        $fields['separator'] = $this->createElement('select', 'separator', array(
            'label' => $this->_tlabel.'separator',
            'allowEmpty' => false,
            'required' => true,
            'label-size' => 4, 'size' => 8,
            'inline' => true,
            'multiOptions' => array(
                ';' => ';',
                ',' => ',',
            ),
            'class' => 'separator ',
        ));

        $this->addDisplayGroup($fields, 'main');

        /***** SUBMIT FIELDS ******/
        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'primary'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

//        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
        //$this->setAttrib('data-replace', '#'.$this->getElementsBelongTo());
    }
}