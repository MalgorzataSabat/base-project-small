<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('export', new Zend_Controller_Router_Route(
    '/export/:object',
    array(
        'module' => 'export',
        'controller' => 'index',
        'action' => 'index'
    ),
    array(
        'object' => '.*'
    )
));



Zend_Controller_Front::getInstance()->setRouter($router);
