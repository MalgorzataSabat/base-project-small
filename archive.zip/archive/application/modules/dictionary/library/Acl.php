<?php
class Dictionary_Acl
{
    /**
     * @var Base_Acl
     */
    protected $_acl;

    /**
     * @param $acl Base_Acl
     */
    public function __construct($acl)
    {
        $this->_acl = $acl;
    }


    public function loadAcl()
    {
        $dictionaryList = Dictionary::getList();

        $this->_acl->addResource('dictionaryItem');
        $this->_acl->allow(Base_Auth::MAIN_ROLE_LOGIN, array('dictionaryItem'));

        $_res = array();
        foreach($dictionaryList as $dictionary){
            if(!array_key_exists($dictionary['object'], $_res)){
                $_res[$dictionary['object']] = $dictionary['object'];
                $this->_acl->addResource('dictionaryItem.'.$dictionary['object'], 'dictionaryItem');
            }

            $this->_acl->addResource('dictionaryItem.'.$dictionary['object'].'.'.$dictionary['id_dictionary'], 'dictionaryItem.'.$dictionary['object']);
        }


        return $this->_acl;
    }


}