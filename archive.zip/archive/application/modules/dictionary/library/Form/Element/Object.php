<?php

/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2017-06-06
 * Time: 17:57
 */
class Dictionary_Form_Element_Object extends Base_Form_Element_Select
{
    private $_defaultName       = 'object';


    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_dictionary_object';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    private function _loadMultiOptions(&$options)
    {
        $multiOptions = array();
        if(!isset($options['required']) || !$options['required']){
            $multiOptions[''] = '';
        }

        $objectList = json_decode(Setting::getSetting(Dictionary::SETTING_OBJECT), true);

        foreach ($objectList as $v) {
            $multiOptions[$v] = $v;
        }

        $options['multioptions'] = $multiOptions;

        $options['validators'][] = array('InArray', true, array(array_keys($multiOptions)));

    }
}