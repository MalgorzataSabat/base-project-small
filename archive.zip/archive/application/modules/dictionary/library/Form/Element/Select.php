<?php

/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2017-06-06
 * Time: 17:57
 */
class Dictionary_Form_Element_Select extends Base_Form_Element_Select
{
    protected $_defaultName   = 'id_dictionary';
    protected $_defaultValue  = null;
    protected $_list          = null;

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_dictionary';
        }

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $options) ) {
            $this->loadMultiOptions($options);
        }

        if(!isset($options['value']) || (isset($options['value']) && !$options['value'])){
            if(isset($options['use_default']) && $options['use_default'] && $this->_defaultValue){
                unset($options['use_default']);
                $this->setValue($this->_defaultValue['id_dictionary']);
            }
        }
    }

    public function loadMultiOptions($options)
    {
        $multiOptions = array();
        if(!isset($options['required']) || !$options['required']){
            $multiOptions[''] = '';
        }

        $queryOptions = array();
        isset($options['object']) && $queryOptions['object'] = $options['object'];
        isset($options['id_parent']) && $queryOptions['id_parent'] = $options['id_parent'];

        $this->_list = Dictionary::getList($queryOptions);

        foreach ($this->_list as $v) {
            $multiOptions[$v['id_dictionary']] = strip_tags($v['name']);
            if($v['is_default']){
                $this->_defaultValue = $v;
            }
        }

        $this->setMultiOptions($multiOptions);

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }
    }
}