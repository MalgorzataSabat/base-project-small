<?php

/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2017-06-06
 * Time: 17:57
 */
class Dictionary_Form_Element_Select_Tax extends Dictionary_Form_Element_Select
{
    protected $_defaultName       = 'id_tax';

    /**
     * @param $options
     * @throws Zend_Form_Exception
     */
    public function loadMultiOptions($options)
    {
        parent::loadMultiOptions($options);

        $taxData =  array();

        foreach($this->_list as $k => $v){
            $taxData[$v['id_dictionary']] = $v;
        }

        $this->setAttrib('data-tax', json_encode($taxData));
    }
}