<?php

class Dictionary_Form_Field extends  Field_Form_Field_Abstract
{

    public function createElement($field, $fieldOptions, $form)
    {
        if(!isset($fieldOptions['object'])){
            if(strstr($field['assign'], 'module')){
                $id_module = explode('.',$field['assign'])[1];
                if($id_module){
                    $fieldOptions['object'] = ucfirst(Module::getSlugById($id_module));
                }
            }else{
                $fieldOptions['object'] = ucfirst($field['assign']);
            }
        }



        $fieldOptions['filters'] = array('Null');

        return new Dictionary_Form_Element_Select($field['hash'], $fieldOptions);
    }


}