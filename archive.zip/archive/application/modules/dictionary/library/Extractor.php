<?php


class Dictionary_Extractor extends Base_Extractor
{

    protected $_tables = array('dictionary');

    protected $_data = array();

    protected $_module = 'dictionary';

    protected $_dumpResource = array('dictionary');

    protected $_dumpLabel = array('dictionary');

    protected $_dumpChangelog = array('dictionary');

    protected $_dumpSettings = array('dictionary');

    protected $_dumpDictionary = array();

    protected $_dumpRule = array('dictionary');

}