<?php

/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2017-06-06
 * Time: 18:02
 */
class Dictionary_Form_Filter extends Base_Form_Filter
{

    protected $_tabColumnOn = false;

    protected $_fieldsDisplay   = array(
        'name', 'object'
    );

    protected $_defaultCols     = array (
        'object', 'name', 'name', 'order', 'is_closed', 'is_default', 'class', 'style'
    );

    public function init()
    {
        $this->_searchElements['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
        ));

        $this->_searchElements['object'] = new Dictionary_Form_Element_Object(null, array(
            'decorators' => $this->_elementDecorators,
        ));

    }
}