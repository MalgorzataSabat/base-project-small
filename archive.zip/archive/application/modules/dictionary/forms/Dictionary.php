<?php

class Dictionary_Form_Dictionary extends Base_Form_Horizontal
{

    /**
     * @var $_model Dictionary
     */
    protected $_model;

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['name'] = $this->createElement( 'text', 'name', array(
            'label' => $this->_tlabel.'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'value' => $this->_model['name'],
        ));

        $fields['object'] = new Dictionary_Form_Element_Object('object', array(
            'decorators' => $this->_elementDecorators,
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'value' => $this->_model['object'],
        ));

        $fields['order'] = $this->createElement('text', 'order', array(
            'label' => $this->_tlabel.'order',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'value' => $this->_model['order'],
        ));

        $fields['is_default'] = $this->createElement('checkbox', 'is_default', array(
            'label' => $this->_tlabel.'is_default',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'checked' => $this->_model['is_default'],
        ));

        $fields['class'] = $this->createElement('text', 'class', array(
            'label' => $this->_tlabel.'class',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'value' => $this->_model['class'],
        ));

        $fields['style'] = $this->createElement('text', 'style', array(
            'label' => $this->_tlabel.'style',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'value' => $this->_model['style'],
        ));

        $fields['data'] = $this->createElement('text', 'data', array(
            'label' => $this->_tlabel.'data',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
            ),
            'value' => $this->_model['data'],
        ));


        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }


}