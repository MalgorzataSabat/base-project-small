<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('dictionary', new Zend_Controller_Router_Route(
    '/@dictionary',
    array(
        'module' => 'dictionary',
        'controller' => 'index',
        'action' => 'index',
    )
));

$router->addRoute('dictionary_new', new Zend_Controller_Router_Route(
    '/@dictionary/@new',
    array(
        'module' => 'dictionary',
        'controller' => 'index',
        'action' => 'new',
    )
));

$router->addRoute('dictionary_edit', new Zend_Controller_Router_Route(
    '/@dictionary/@edit/:id_dictionary',
    array(
        'module' => 'dictionary',
        'controller' => 'index',
        'action' => 'edit',
    ),
    array(
        'id_dictionary' => '\d+'
    )
));

$router->addRoute('dictionary_delete', new Zend_Controller_Router_Route(
    '/@dictionary/@delete/:id_dictionary',
    array(
        'module' => 'dictionary',
        'controller' => 'index',
        'action' => 'delete',
    ),
    array(
        'id_dictionary' => '\d+'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);


