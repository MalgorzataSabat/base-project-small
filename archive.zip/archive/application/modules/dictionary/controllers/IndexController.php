<?php
/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 2017-06-06
 * Time: 17:34
 */

class Dictionary_IndexController extends Base_Controller_Action
{

    /**
     * @var Dictionary
     */
    private $_model;

    public function indexAction()
    {
        $formFilter = new Dictionary_Form_Filter();
        $dataQuery = $formFilter->getValuesQuery(true);
        $dataQuery['order'] = 'o.object ASC, o.order ASC';

        $dictionaryList = Dictionary::getList($dataQuery);

        $this->view->dictionaryList = $dictionaryList;
        $this->view->formFilter = $formFilter;
    }

    public function newAction()
    {
        $this->_model = new Dictionary();

        $this->_formDictionary();
        $this->view->placeholder( 'page-title' )->set('Nowy element słownika');
    }

    public function editAction()
    {
        $this->_model = Dictionary::findRecord($this->getParam('id_dictionary'));
        $this->forward404Unless($this->_model);

        $this->_formDictionary();
        $this->view->placeholder( 'page-title' )->set('Edycja elementu słownika');
    }


    private function _formDictionary()
    {
        $this->_helper->viewRenderer('form');
        $form = new Dictionary_Form_Dictionary(array('model' => $this->_model));

        if ( $this->_request->isPost() && $form->isValid( $this->_request->getPost())){
            $this->_model->save();

            if($this->_request->isXmlHttpRequest()){
                $this->_helper->viewRenderer('form-ajax-result');
            }else{
                $this->_flash()->success->addMessage('label_cms_save_success');
                $this->_redirector()->gotoRouteAndExit(array(), 'dictionary');
            }
        }

        $this->view->model = $this->_model;
        $this->view->form = $form;

    }

    public function deleteAction()
    {
        $this->_model = Dictionary::findRecord($this->getParam('id_dictionary'));
        $this->forward404Unless($this->_model);

        $this->_model->delete();

        if($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer('delete-ajax-result');
        }else{
            $this->_flash()->success->addMessage('label_cms_delete_success');
            $this->_redirector()->gotoRouteAndExit(array(), 'dictionary');
        }
    }


}