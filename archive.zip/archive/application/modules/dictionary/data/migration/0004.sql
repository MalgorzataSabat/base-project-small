ALTER TABLE `dictionary` ADD `id_parent` INT UNSIGNED NULL DEFAULT NULL AFTER `id_service`, ADD INDEX (`id_parent`);
ALTER TABLE `dictionary` CHANGE `id_parent` `id_parent` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT 'Identyfiaktor rodzica/zależności';
ALTER TABLE `dictionary` ADD CONSTRAINT `dictionary_parent` FOREIGN KEY (`id_parent`) REFERENCES `dictionary`(`id_dictionary`) ON DELETE CASCADE ON UPDATE RESTRICT;

SET @taskTypeParentId = (SELECT `id_dictionary` FROM `dictionary` WHERE object = 'TaskType' AND `id_service` = 1 AND `name` = 'urlop');
INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `id_parent`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', @taskTypeParentId, 'TaskTypeSub', 'urlop', '1', '0', '1', '', '', ''), (NULL, '1', @taskTypeParentId, 'TaskTypeSub', 'L4', '2', '0', '0', '', '', '');
UPDATE `setting` SET `value` = '[\"PersonStatus\",\"TaskStatus\", \"TaskType\", \"TaskTypeSub\",\"ClientStatus\",\"TaskPriority\",\"Tax\",\"InvoiceUnit\",\"InvoicePayMethod\",\"InvoicePayTermDay\",\"InvoiceCorrectionReason\",\"Currency\",\"ProjectStatus\",\"DealStatus\",\"BillStatus\",\"ContractType\",\"AgreementStatus\",\"AgreementService\"]' WHERE `setting`.`key` = 'dictionary.objects';

