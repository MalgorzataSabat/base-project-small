-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dictionary` (
  `id_dictionary` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `id_service` int(10) unsigned NOT NULL COMMENT 'Identyfikator serwisu',
  `object` varchar(32) NOT NULL COMMENT 'Objekt statusu',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa statusu',
  `order` tinyint(3) unsigned NOT NULL COMMENT 'Kolejność wyświetlania',
  `is_closed` tinyint(1) NOT NULL COMMENT 'Czy status zamknięty',
  `is_default` tinyint(1) NOT NULL COMMENT 'Czy jest to status domyślny',
  `class` varchar(255) NOT NULL COMMENT 'Klasa css',
  `style` varchar(255) NOT NULL COMMENT 'Style css',
  `data` text NOT NULL COMMENT 'Dodatkowe informacje/ustawienia',
  PRIMARY KEY (`id_dictionary`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `dictionary_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8 COMMENT='Tabela zawiera listę słownikową, np: statusów';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'dictionary','Słownik','');
SET @resParentId54856 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary_index_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary_index_new');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary_index_edit');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54856,'dictionary_index_delete');
-- Dump MODULE: dictionary
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'admin', 'dictionary');
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'dictionary'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('0001.20170718095956.csv','dictionary','2017-07-19 19:31:34',2),('0001.sql','dictionary','2017-12-18 10:19:03',1),('_install.sql','dictionary','2017-07-08 08:25:36',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_dictionary','label','2017-06-06 21:02:26','2017-06-20 12:55:05','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Słownik');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('page-title_dictionary_list','label','2017-06-06 21:02:55','2017-06-20 12:55:22','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista słownikowa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_filter_name','label','2017-06-06 21:03:11','2017-06-20 12:55:31','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa słownika');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_dictionary_object','label','2017-06-06 21:03:33','2017-06-20 12:55:39','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Objekt');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_filter_object','label','2017-06-06 21:04:15','2017-06-20 12:55:45','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Objekt');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_dictionary_list','label','2017-06-06 21:04:30','2017-06-20 12:56:06','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista słownikowa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary_add-new','label','2017-06-06 21:05:06','2017-06-20 12:56:38','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj nowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_id_dictionary','label','2017-06-06 21:05:18','2017-06-20 13:00:27','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_object','label','2017-06-06 21:05:31','2017-06-20 12:56:57','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Objekt');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_name','label','2017-06-06 21:05:44','2017-06-20 12:57:06','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_order','label','2017-06-06 21:05:58','2017-06-20 12:57:13','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kolejność');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_is_closed','label','2017-06-06 21:06:18','2017-06-20 12:57:19','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy zamknięty?');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_is_default','label','2017-06-06 21:06:33','2017-06-20 12:57:25','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy domyślny?');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_class','label','2017-06-06 21:06:44','2017-06-20 12:57:32','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klasa CSS');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_dictionary-list_style','label','2017-06-06 21:07:08','2017-06-20 12:57:39','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Styl CSS');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_name','label','2017-06-06 21:08:14','2017-06-20 12:57:59','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_order','label','2017-06-06 21:08:26','2017-06-20 12:58:10','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kolejność na liście');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_is_default','label','2017-06-06 21:08:38','2017-06-20 12:58:20','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Czy domyślny?');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_class','label','2017-06-06 21:08:54','2017-06-20 12:58:28','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klasa CSS');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_style','label','2017-06-06 21:09:06','2017-06-20 12:58:35','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Styl CSS');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_dictionary','label','2017-06-17 11:39:11','2017-06-20 12:59:31','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Wartość');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('module_name-dictionary','label','2017-06-17 12:01:03','2017-06-20 12:59:43','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Słownik');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_status','label','2017-06-20 13:34:52','2017-06-20 13:34:52','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('dictionary_form_dictionary_data','label','2017-06-20 20:37:20','2017-06-20 20:37:20','dictionary','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodatkowe informacje/ustawienia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filed_status','label','2017-07-15 17:18:31','2017-07-19 21:31:34','dictionary','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `setting` (`key`, `value`) VALUES ('dictionary.objects', '[\"PersonStatus\",\"TaskStatus\",\"ClientStatus\",\"TaskPriority\",\"Tax\",\"InvoiceUnit\",\"InvoicePayMethod\",\"InvoicePayTermDay\",\"Currency\",\"ProjectStatus\"]');
