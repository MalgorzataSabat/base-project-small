<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 09.03.2018
 * Time: 13:57
 */

class Agreement_Bootstrap extends Base_Application_Module_Bootstrap
{

    public function _initWidget()
    {
        if(DEV){
            Base_Widget::registerWidget('Agreement_Widget_Card');
            Base_Widget::registerWidget('Agreement_Widget_List');
        }
    }

}