<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('agreement_ajax_get-list', new Zend_Controller_Router_Route(
    '/@agreement/ajax/get-list',
    array(
        'module' => 'agreement',
        'controller' => 'ajax',
        'action' => 'get-list',
    )
));

$router->addRoute('agreement_ajax_get-list-item', new Zend_Controller_Router_Route(
    '/@agreement/ajax/get-list-item',
    array(
        'module' => 'agreement',
        'controller' => 'ajax',
        'action' => 'get-list-item',
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);
