<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('agreement', new Zend_Controller_Router_Route(
    '/@agreement',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('agreement_show', new Zend_Controller_Router_Route(
    '/@agreement/@show/:id_agreement',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_agreement' => '([0-9a-f]{32})',
    )
));

$router->addRoute('agreement_new', new Zend_Controller_Router_Route(
    '/@agreement/@new',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'new'
    )
));

$router->addRoute('agreement_edit', new Zend_Controller_Router_Route(
    '/@agreement/@edit/:id_agreement',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_agreement' => '([0-9a-f]{32})',
    )
));

$router->addRoute('agreement_archive', new Zend_Controller_Router_Route(
    '/@agreement/@archive/:id_agreement',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'archive'
    ),
    array(
        'id_agreement' => '([0-9a-f]{32})',
    )
));

$router->addRoute('agreement_delete', new Zend_Controller_Router_Route(
    '/@agreement/@delete/:id_agreement',
    array(
        'module' => 'agreement',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_agreement' => '([0-9a-f]{32})',
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);