<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:45
 */

class Agreement_Loader_Export extends Agreement_Loader
{
    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $query = $this->_getQuery();

        $query->addSelect("concat(uc.name, ' ',uc.surname) as id_user_created");
        $query->leftJoin('o.UserCreated uc');

        $query->addSelect("concat(u.name, ' ',u.surname) as id_user");
        $query->leftJoin('o.User u');

        $query->addSelect("c.name as id_client");
        $query->leftJoin('o.Client c');

        $query->addSelect('s.name as id_status');
        $query->leftJoin('o.Status s');

        $query->addSelect('ct.name as id_contract_type');
        $query->leftJoin('o.ContractType ct');

        if ($select) {
            $query->select($select);
        }

        $result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        $dataQuery = $this->_filter->getValuesQuery(true);

        foreach($dataQuery['column'] as $column){
            $this->_labels[$column] =  Base::getFiledName('agreement.'.$column);
        }

        foreach($result as $k => $data){
            foreach ($dataQuery['column'] as $column) {
                switch($column){
                    case 'subscription_amount':{}
                    case 'subscription_hour_max':{
                        $this->_result[$k][$column] = number_format($data[$column], 2, ',', '');
                        break;
                    }
                    case 'tags':{
                        $this->_result[$k][$column] = join(', ', json_decode($data[$column], true));
                        break;
                    }
                    default:{
                        $this->_result[$k][$column] = trim(strip_tags($data[$column]));
                    }
                }
            }
        }

        unset($result);

        return $this->_result;
    }
}