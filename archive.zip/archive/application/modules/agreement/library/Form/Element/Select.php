<?php

class Agreement_Form_Element_Select extends Base_Form_Element_Select
{
    private $_defaultName   = 'id_agreement';

    private $_list    = array();
    
    public function __construct($name, $options = null) 
    {
        empty($name) && $name = $this->_defaultName;
        
        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_agreement';
        }
        
        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        $options['data-url-load-list'] = Base::url('agreement_ajax_get-list');

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $options) ) {
            $this->loadMultiOptions($options);
        }

    }


    public function loadMultiOptions($options)
    {
        $multiOptions = array('' => '- wybierz klienta -');
        $queryOptions = array('coll_key' => 'id_agreement');

        isset($options['id_client']) && $options['id_client'] && $queryOptions['id_client'] = $options['id_client'];

        if(isset($queryOptions['id_client']) && isset($queryOptions['id_client'])){
            $this->_list = Agreement::getList($queryOptions);

            foreach ($this->_list as $id_agreement => $v) {
                $name = array();
                $name[] = strip_tags(Dictionary::getNameById($v['id_contract_type']));
                $name = join(" ", $name);

                $multiOptions[$id_agreement] = $name;
            }

            $multiOptions = array('' => '- wybierz umowę -') + $multiOptions;
        }

        $this->setMultiOptions($multiOptions);

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }
    }
}

