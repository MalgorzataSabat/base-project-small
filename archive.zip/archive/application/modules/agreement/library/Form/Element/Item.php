<?php

class Agreement_Form_Element_Item extends Base_Form_Element_Select
{
    private $_defaultName   = 'id_agreement_item';

    private $_list    = array();
    
    public function __construct($name, $options = null) 
    {
        empty($name) && $name = $this->_defaultName;
        
        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_agreement_item';
        }
        
        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        $options['data-url-load-list'] = Base::url('agreement_ajax_get-list-item');

        parent::__construct($name, $options);

        if ( !array_key_exists('multioptions', $options) ) {
            $this->loadMultiOptions($options);
        }

    }


    public function loadMultiOptions($options)
    {
        $multiOptions = array('' => '- wybierz umowę -');
        $queryOptions = array('coll_key' => 'id_agreement_item');

        isset($options['id_agreement']) && $options['id_agreement'] && $queryOptions['id_agreement'] = $options['id_agreement'];

        if(isset($queryOptions['id_agreement']) && isset($queryOptions['id_agreement'])){
            $this->_list = AgreementItem::getList($queryOptions);

            foreach ($this->_list as $id_agreement_item => $v) {
                $name = array();
                $name[] = strip_tags(Dictionary::getNameById($v['id_agreement_service']));
                $name = join(" ", $name);

                $multiOptions[$id_agreement_item] = $name;
            }

            $multiOptions = array('' => '- wybierz usługę umowy -') + $multiOptions;
        }

        $this->setMultiOptions($multiOptions);

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }
    }
}

