<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:46
 */

class Agreement_Widget_Loader extends Base_Widget_Loader
{

    protected $_channel = 'Agreement';

    protected $_id_col = 'id_agreement';

    public function getParamsByWidget($widget)
    {
        $params = array();

        if($widget == 'Agreement_Widget_Card')
        {
            $params = array('agreement' => $this->_model);
        }

        elseif($widget == 'Agreement_Widget_Service')
        {
            $params = array('agreement' => $this->_model);
        }

        else{
            $params = parent::getParamsByWidget($widget);
        }

        return $params;
    }



}
