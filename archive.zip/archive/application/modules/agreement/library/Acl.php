<?php
class Agreement_Acl
{
    /**
     * @var Base_Acl
     */
    protected $_acl;

    /**
     * @param $acl Base_Acl
     */
    public function __construct($acl)
    {
        $this->_acl = $acl;
    }


    public function loadAcl()
    {
        $this->_acl->addResource('agreement_ajax_get-list', '_basic');
        $this->_acl->addResource('agreement_ajax_get-list-item', '_basic');

        return $this->_acl;
    }


}