<?php

class Agreement_IndexController extends Base_Controller_Action
{
    /**
     * @var Agreement
     */
    private $_agreement;

    public function indexAction()
    {
        $this->view->formFilter = new Agreement_Form_Filter();
//        $dataQuery = $formFilter->getValuesQuery(true);
//
//        $query = Agreement::getQuery($dataQuery);
//
//        $this->view->massActionOptions = array();
//        if($this->view->hasAccess('export_agreement')){
//            $this->view->massActionOptions['export'] = array(
//                'url' => Base::url('export', array('object' => 'agreement')),
//                'name' => $this->view->translate('mass-options_export')
//            );
//        }
//
//        $this->view->agreementList = $this->_helper->paging($query);
//        $this->view->formFilter = $formFilter;
    }

    public function showAction()
    {
        $this->_agreement = Agreement::find($this->getParam('id_agreement'));
        $this->forward404Unless($this->_agreement);

        $layoutService = new Layout_Service('agreement_card');
        $layoutService->setLoader('Agreement_Widget_Loader', array(
            'model' => $this->_agreement
        ));

        $this->view->layoutService = $layoutService;
        $this->view->agreement = $this->_agreement;
    }

    public function newAction()
    {
        $this->_agreement = new Agreement();
        $this->_agreement['id_user'] = Base_Auth::getUserId();
        $this->_agreement['id_client'] = $this->_getParam('id_client');

        $this->_formAgreement();
    }

    public function editAction()
    {
        $this->_agreement = Agreement::findRecord($this->getParam('id_agreement'));
        $this->forward404Unless($this->_agreement);

        $this->_formAgreement();
    }

    private function _formAgreement()
    {
        $this->_helper->viewRenderer('form');

        $form = new Agreement_Form_Agreement(array('model' => $this->_agreement));
        if ( $this->_request->isPost() && $form->isValid( $this->_request->getPost())){

            $this->_flash()->success->addMessage('label_save_success');

            $returnUrl = $this->_getReturnUrl();
            $this->_redirector()->gotoUrlAndExit($returnUrl);
        }

        $this->view->agreement = $this->_agreement;
        $this->view->form = $form;
    }

    public function archiveAction()
    {
        $this->_agreement = Agreement::findRecord($this->_getParam('id_agreement'));
        $this->forward403Unless($this->_agreement);

        $this->_agreement->archived_at = $this->_agreement->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_agreement->save();

        if ( $this->_agreement->archived_at ) {
            $this->_flash()->success->addMessage('label_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_unarchive_success');
        }

        $this->_gotoReturnUrl();
    }

    public function deleteAction()
    {
        $this->_agreement = Agreement::findRecord($this->_getParam('id_agreement'));
        $this->forward403Unless($this->_agreement);

        $this->_agreement->delete();

        $this->_flash()->success->addMessage('label_delete_success');
        $this->_gotoReturnUrl();
    }

    protected function _getReturnUrl($route = 'agreement', $params = array())
    {
        Setting::getSetting('agreement.return_route') && $route = Setting::getSetting('agreement.return_route');
        !$route && $route = 'agreement';

        if(isset($this->_agreement) && $this->_agreement){
            $params['id_agreement'] = $this->_agreement['hash'];

            if($this->_agreement['id_client']){
                $params['id_client'] = Client::getHashById($this->_agreement['id_client']);
            }
        }

        return Base::url($route, $params);
    }
}