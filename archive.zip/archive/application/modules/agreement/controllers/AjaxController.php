<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Agreement_AjaxController extends Base_Controller_Action
{

    public function getListAction()
    {
        $queryOptions = array();
        $agreementList   = array();
        $agreementList[] = array('id_agreement' => '', 'name' => '- wybierz klienta -');

        if(($id_client = $this->getParam('id_client'))){
            $queryOptions['id_client'] = $id_client;
        }

        if($id_client){
            $agreementList = Agreement::getList($queryOptions);
            foreach ($agreementList as $k => $v) {
                $name = array();
                $name[] = strip_tags(Dictionary::getNameById($v['id_contract_type']));
                $name = join(" ", $name);

                $agreementList[$k]['name'] = $name;
            }

            array_unshift($agreementList, array('id_agreement' => '', 'name' => '- wybierz umowę -'));
        }


        $this->_helper->json($agreementList);
    }


    public function getListItemAction()
    {
        $agreementItemList  = array();
        $agreementItemList[]= array('id_agreement_item' => '', 'name' => '- wybierz umowę -');
        $queryOptions = array();

        if(($id_agreement = $this->getParam('id_agreement'))){
            $queryOptions['id_agreement'] = $id_agreement;
        }

        if($id_agreement){
            $agreementItemList = AgreementItem::getList($queryOptions);
            foreach ($agreementItemList as $k => $v) {
                $name = array();
                $name[] = strip_tags(Dictionary::getNameById($v['id_agreement_service']));
                $name = join(" ", $name);

                $agreementItemList[$k]['name'] = $name;
            }

            array_unshift($agreementItemList, array('id_agreement_item' => '', 'name' => '- wybierz usługę umowy -'));
        }

        $this->_helper->json($agreementItemList);
    }

}