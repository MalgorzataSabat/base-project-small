<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 21.08.2018
 * Time: 15:36
 */

class Agreement_Form_AgreementService extends Base_Form_Horizontal
{
    protected $_belong_to = 'service';

    private $_serviceList = array();


    public function setServiceList($serviceList)
    {
        $this->_serviceList = $serviceList;
    }


    public function init()
    {
        $fields = array();
        $agreementServiceList = (array) Dictionary::getListByObject('AgreementService');

        $multiOptions = AgreementItem::getCalcStrategyList();

        foreach($agreementServiceList as $v){
            $fields[$v['id_dictionary']] = $this->createElement('select', $v['id_dictionary'], array(
                'label' => $v['name'],
                'value' => isset($this->_serviceList[$v['id_dictionary']]) ? $this->_serviceList[$v['id_dictionary']]['calc_strategy'] : AgreementItem::DEFAULT_CALC_STATEGY,
                'required' => false,
                'allowEmpty' => true,
                'multiOptions' => $multiOptions,
                'size' => 3,
                'label-size' => 9,
                'decorators' => array(
                    array('ViewHelper'),
                    array('FieldSize', array('size' => 9)),
                    array('Label', array('class' => 'control-label text-left', 'size' => 9, 'placement' => 'APPEND')),
                    array('WrapElement')
                )
            ));
        }

        if($fields){
            $this->addDisplayGroup($fields, 'main', array(
                'legend' => 'Usługi umowy, sposób rozliczenia'
            ));
            $this->addElements($fields);
        }

        $this->setDecorators(array(
            'FormElements',
        ));

    }


    public function postIsValid($data)
    {
        return true;
    }

}