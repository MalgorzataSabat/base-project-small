<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 23.09.2016
 * Time: 10:45
 */
class Agreement_Form_Filter_Default extends Agreement_Form_Filter
{

    protected $_forceClear = 1;

    protected function _getQueryFormClass()
    {
        return array_values(class_parents($this))[0];
    }

}