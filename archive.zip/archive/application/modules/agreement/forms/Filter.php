<?php

class Agreement_Form_Filter extends Base_Form_Filter
{

    protected $_version = 2;

    protected $_sortCols = array(
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'id_user_created' => 'o.id_user_created',
        'id_user' => 'o.id_user',
        'id_client' => 'o.id_client',
        'id_status' => 'o.id_status',
        'id_contract_type' => 'o.id_contract_type',
        'date_create' => 'o.date_create',
        'date_expire' => 'o.date_expire',
        'subscription_hour_max' => 'o.subscription_hour_max',
        'hour_rate' => 'o.hour_rate',
    );

    protected $_avalibleCols    = array(
        'created_at' => 'index.datetime',
        'updated_at' => 'index.datetime',
        'id_user_created' => 'user.user',
        'id_user' => 'user.user',
        'id_client' => 'client.client',
        'id_status' => 'dictionary.dictionary',
        'id_contract_type' => 'dictionary.dictionary',
        'number' => 'agreement.agreement',
        'date_create' => 'index.date',
        'date_expire' => 'index.date',
        'subscription_amount' => 'index.price',
        'subscription_hour_max' => 'index.text',
        'hour_rate' => 'index.price',
        'tags' => 'index.tags',
    );

    protected $_fieldsDisplay   = array(
        'id_client', 'id_contract_type', 'id_status'
    );

    protected $_defaultCols  = array (
        'number', 'id_client', 'id_status', 'id_contract_type', 'subscription_amount'
    );

    public function init()
    {
        $this->_searchElements['id_client'] = new Client_Form_Element_Client(null, array(
            'label' => Base::getFiledNameLabel('agreement.id_client'),
            'searchable' => true,
        ));

        $this->_searchElements['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => Base::getFiledNameLabel('agreement.id_status'),
            'object' => 'AgreementStatus',
            'searchable' => array('type' => 'dictionary'),
            'value' => array(
                'type' => 'open',
                'value' => '',
            )
        ));

        $this->_searchElements['id_contract_type'] = new Dictionary_Form_Element_Select('id_contract_type', array(
            'label' =>  Base::getFiledNameLabel('agreement.id_contract_type'),
            'object' => 'ContractType',
            'searchable' => array('type' => 'dictionary'),
            'value' => array(
                'type' => 'open',
                'value' => '',
            )
        ));

        $this->_searchElements['id_user'] = new User_Form_Element_User(null, array(
            'label' =>  Base::getFiledNameLabel('agreement.id_user'),
            'searchable' => true,
            'select2' => true,
        ));

        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' =>  Base::getFiledNameLabel('agreement.id_user_created'),
            'searchable' => true,
            'select2' => true,
        ));

        $this->_searchElements['number'] = $this->createElement('text', 'number', array(
            'label' =>  Base::getFiledNameLabel('agreement.number'),
        ));

        $this->_searchElements['date_create'] = $this->createElement('search_Date', 'date_create', array(
            'label' =>  Base::getFiledNameLabel('agreement.date_create'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['date_expire'] = $this->createElement('search_Date', 'date_expire', array(
            'label' =>  Base::getFiledNameLabel('agreement.date_expire'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['subscription_amount'] = $this->createElement('search_Number', 'subscription_amount', array(
            'label' =>  Base::getFiledNameLabel('agreement.subscription_amount'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));

        $this->_searchElements['subscription_hour_max'] = $this->createElement('search_Number', 'subscription_hour_max', array(
            'label' =>  Base::getFiledNameLabel('agreement.subscription_hour_max'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));

        $this->_searchElements['hour_rate'] = $this->createElement('search_Number', 'hour_rate', array(
            'label' =>  Base::getFiledNameLabel('agreement.hour_rate'),
            'filters' => array('StringTrim', new Base_Filter_Float),
        ));

        $this->_searchElements['tags'] = new Tag_Form_Element_Tag('tags', array(
            'select2' => array(),
            'multiple' => 'multiple',
            'model' => 'Agreement',
        ));

        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => Base::getFiledNameLabel('created_at'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['updated_at'] = $this->createElement('search_Date', 'updated_at', array(
            'label' => Base::getFiledNameLabel('updated_at'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['archived_at'] = new Base_Form_Element_ArchivedAt();
    }

}