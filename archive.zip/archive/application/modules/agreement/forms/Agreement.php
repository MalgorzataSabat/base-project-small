<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Agreement_Form_Agreement extends Base_Form_Horizontal
{

    /**
     * @var $_model Agreement
     */
    protected $_model = null;

    /**
     * @var Agreement_Form_AgreementService
     */
    protected $_agreementServiceForm;

    protected $_serviceList = array();

    public function init()
    {
        $fields = array();
        $fields_adv = array();
        $fields_desc = array();

        if($this->_model['id_agreement']){
            $serviceList = AgreementItem::getList(array('id_agreement' => $this->_model['id_agreement']));
            foreach($serviceList as $v){
                $this->_serviceList[$v['id_agreement_service']] = $v;
            }
        }

        $fields['number'] = $this->createElement('text', 'number', array(
            'label' => Base::getFiledNameLabel('agreement.number'),
            'value' => $this->_model['number'],
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['id_contract_type'] = new Dictionary_Form_Element_Select('id_contract_type', array(
            'label' =>  Base::getFiledNameLabel('agreement.id_contract_type'),
            'object' => 'ContractType',
            'value' => $this->_model['id_contract_type'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' =>  Base::getFiledNameLabel('agreement.id_status'),
            'object' => 'AgreementStatus',
            'value' => $this->_model['id_status'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['id_user'] = new User_Form_Element_User('id_user', array(
            'label' => Base::getFiledNameLabel('agreement.id_user'),
            'value' => $this->_model['id_user'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'select2' => true,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['id_client'] = new Client_Form_Element_Client('id_client', array(
            'label' => Base::getFiledNameLabel('agreement.id_client'),
            'value' => $this->_model['id_client'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['date_create'] = $this->createElement('DateTimePicker', 'date_create', array(
            'label' => Base::getFiledNameLabel('agreement.date_create'),
            'value' => $this->_model['date_create'],
            'allowEmpty' => true,
            'datetime-format' => 'date',
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            ),
            'size' => 8,
            'label-size' => 4,
            'filters' => array('Null'),
        ));

        $fields['date_expire'] = $this->createElement('DateTimePicker', 'date_expire', array(
            'label' => Base::getFiledNameLabel('agreement.date_expire'),
            'value' => $this->_model['date_expire'],
            'allowEmpty' => true,
            'datetime-format' => 'date',
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            ),
            'size' => 8,
            'label-size' => 4,
            'filters' => array('Null'),
        ));


        $fields_adv['amount'] = $this->createElement('text', 'subscription_amount', array(
            'label' => Base::getFiledNameLabel('agreement.subscription_amount'),
            'value' => $this->_model['subscription_amount'],
            'required' => false,
            'allowEmpty' => true,
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'filters' => array(new Base_Filter_Float(), 'StringTrim', 'Null'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields_adv['hour_max'] = $this->createElement('text', 'subscription_hour_max', array(
            'label' => Base::getFiledNameLabel('agreement.subscription_hour_max'),
            'description' => Base::getFiledNameLabel('agreement.subscription_hour_max', 'desc'),
            'value' => $this->_model['subscription_hour_max'],
            'required' => false,
            'allowEmpty' => true,
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'filters' => array(new Base_Filter_Float(), 'StringTrim', 'Null'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields_adv['hour_rate'] = $this->createElement('text', 'hour_rate', array(
            'label' => Base::getFiledNameLabel('agreement.hour_rate'),
            'description' => Base::getFiledNameLabel('agreement.hour_rate', 'desc'),
            'value' => $this->_model['hour_rate'],
            'required' => false,
            'allowEmpty' => true,
            'validators' => array(
                array('NotEmpty', true),
                array('StringLength', true, array('max' => 255)),
            ),
            'filters' => array(new Base_Filter_Float(), 'StringTrim', 'Null'),
            'size' => 8,
            'label-size' => 4,
            'input-group' => array(
                'post' => array(
                    'type' => 'href',
                    'class' => '',
                    'id' => 'getClientHourRate',
                    'label' => '<i class="fa fa-refresh fa-fw"></i> pobierz',
                ),
            ),
        ));


        $this->_agreementServiceForm = new Agreement_Form_AgreementService(array('serviceList' => $this->_serviceList));
        $this->_agreementServiceForm->removeDecorator('Form');

        $fields_desc['tags'] = new Tag_Form_Element_Tag('tags', array(
            'label' => Base::getFiledNameLabel('agreement.tags'),
            'value' => !empty($this->_model['tags']) ? json_decode($this->_model['tags']) : array(),
//            'size' => 8,
//            'label-size' => 2,
            'allowEmpty' => true,
            'required' => false,
            'select2' => array(),
            'data-tags' => true,
            'data-token-separators' => "[',']",
            'multiple' => 'multiple',
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'model' => get_class($this->_model),
        ));


        $fields_desc['desc'] = $this->createElement('wysiwyg', 'desc', array(
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model['desc'],
            'data-small' => true,
            'size' => 12,
        ));

        $this->addDisplayGroup($fields, 'main', array(
            'legend' => 'Podstawowe informacje'
        ));

        $this->addDisplayGroup($fields_adv, 'main_adv', array(
            'legend' => 'Rozliczenie abonamentowe'
        ));

        $this->addSubForm($this->_agreementServiceForm, 'service');

        $this->addDisplayGroup($fields_desc, 'main_desc', array(
            'legend' => 'Opis'
        ));

        $group_main = $this->getDisplayGroup('main');
        $group_adv = $this->getDisplayGroup('main_adv');

        $this->addHtmlTag(array($group_main), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_adv), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_main, $group_adv), array('class' => 'row'));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array( $save));
        $this->addElements(array($save));
    }



    public function postIsValid($data)
    {
        parent::postIsValid($data);

        $this->_model->save();

        $this->_saveService($this->getValue('service'));

        return true;
    }


    public function _saveService($serviceData)
    {
        $serviceData = array_filter($serviceData, 'strlen');

        // do usunięcia
        $serviceDelete = array_diff_key($this->_serviceList, $serviceData);


        if($serviceDelete){
            Doctrine_Query::create()
                ->delete('AgreementItem o')
                ->addWhere('(o.id_agreement = ? AND o.id_agreement_service IN ?)', array($this->_model['id_agreement'], array_keys($serviceDelete)))
                ->execute()
            ;
        }

        foreach($serviceData as $id_agreement_service => $value){
            $agreementItem = AgreementItem::getRecord(array(
                'id_agreement' => $this->_model['id_agreement'],
                'id_agreement_service' => $id_agreement_service,
                'hydrate' => Doctrine::HYDRATE_RECORD
            ));

            if(!$agreementItem){
                $agreementItem = new AgreementItem();
                $agreementItem['id_agreement'] = $this->_model['id_agreement'];
                $agreementItem['id_agreement_service'] = $id_agreement_service;
            }

            $agreementItem['calc_strategy'] = $value;
            $agreementItem->save();
        }
    }


}