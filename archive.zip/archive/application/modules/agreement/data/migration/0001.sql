DROP TABLE IF EXISTS `agreement`;
CREATE TABLE IF NOT EXISTS `agreement` (
  `id_agreement` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID umowy',
  `hash` char(32) NOT NULL COMMENT 'Hash',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia umowu',
  `updated_at` timestamp NOT NULL COMMENT 'Data ostatniej modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `id_user_created` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator użytkownika który dodał umowę',
  `id_user` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator przypisanego użytkownika',
  `id_client` int(10) UNSIGNED DEFAULT NULL COMMENT 'Identyfikator klienta',
  `id_status` int(10) UNSIGNED DEFAULT NULL COMMENT 'Status umowy',
  `id_contract_type` int(10) UNSIGNED DEFAULT NULL COMMENT 'Rodzaj umowy',
  `number` varchar(255) NOT NULL COMMENT 'Numer umowy',
  `date_create` date DEFAULT NULL COMMENT 'Data podpisania umowy',
  `date_expire` date DEFAULT NULL COMMENT 'Data wygaśnięcia umowy',
  `amount` double(10,2) DEFAULT NULL COMMENT 'Wartość abonamentu umowy',
  `hour_max` int(11) DEFAULT NULL COMMENT 'Maksymalna ilość godzin w abonamencie',
  `hour_rate` double(10,2) NOT NULL COMMENT 'Stawka godzinowa dla klienta poza umową',
  `tags` text NOT NULL COMMENT 'Tagi',
  PRIMARY KEY (`id_agreement`),
  UNIQUE KEY `hash` (`hash`),
  KEY `id_service` (`id_service`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `id_status` (`id_status`),
  KEY `id_contract_type` (`id_contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `agreement_item`
--

DROP TABLE IF EXISTS `agreement_item`;
CREATE TABLE IF NOT EXISTS `agreement_item` (
  `id_agreement_item` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `hash` char(32) NOT NULL COMMENT 'Hash',
  `id_service` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu',
  `id_agreement` int(10) UNSIGNED NOT NULL COMMENT 'Identyfikator umowy',
  `id_agreement_service` int(10) UNSIGNED DEFAULT NULL COMMENT 'Rodzaj usługi',
  `calc_strategy` tinyint(4) DEFAULT NULL COMMENT 'Strategia liczenia: NULL - bez limitu; 0 - Brak; 1 - Wg godzin',
  PRIMARY KEY (`id_agreement_item`),
  KEY `id_agreement` (`id_agreement`),
  KEY `id_agreement_service` (`id_agreement_service`),
  KEY `agreement_item_service` (`id_service`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `agreement`
--
ALTER TABLE `agreement`
  ADD CONSTRAINT `agreement_client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL,
  ADD CONSTRAINT `agreement_contract_type` FOREIGN KEY (`id_contract_type`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  ADD CONSTRAINT `agreement_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`) ON DELETE CASCADE,
  ADD CONSTRAINT `agreement_status` FOREIGN KEY (`id_status`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  ADD CONSTRAINT `agreement_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  ADD CONSTRAINT `agreement_user_created` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `agreement_item`
--
ALTER TABLE `agreement_item`
  ADD CONSTRAINT `agreement_item_agreement` FOREIGN KEY (`id_agreement`) REFERENCES `agreement` (`id_agreement`) ON DELETE CASCADE,
  ADD CONSTRAINT `agreement_item_agreement_service` FOREIGN KEY (`id_agreement_service`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  ADD CONSTRAINT `agreement_item_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

UPDATE `setting` SET `value` = '[\"PersonStatus\",\"TaskStatus\", \"TaskType\",\"ClientStatus\",\"TaskPriority\",\"Tax\",\"InvoiceUnit\",\"InvoicePayMethod\",\"InvoicePayTermDay\",\"Currency\",\"ProjectStatus\",\"DealStatus\",\"BillStatus\",\"ContractType\",\"AgreementStatus\",\"AgreementService\"]' WHERE `setting`.`key` = "dictionary.objects";

--INSERT INTO `dictionary` (`id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES
--(1, 'AgreementStatus', 'Aktywna', 1, 0, 1, '', '', ''),
--(1, 'AgreementStatus', 'Wygasła', 2, 1, 0, '', '', '');

-- INSERT INTO `dictionary` (`id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES
-- (1, 'AgreementService', 'Obsługa bieżąca', 1, 0, 1, '', '', ''),
-- (1, 'AgreementService', 'Zapytania i żądania osób - udzielanie odpowiedzi', 2, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Zapytania i żądania osób - opiniowanie odpowiedzi', 3, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Dostosowanie procesów', 4, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Opiniowanie umów i regulaminów dedykowanych', 5, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Opiniowanie polityk i procedur', 6, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Obsługa incydentów', 7, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Rejestr czynności', 8, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Projektowana i domyślna ochrona', 9, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Organ nadzorczy', 10, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Analiza ryzyka / DPIA', 11, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Bezpieczeństwo IT', 12, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Audyt planowy', 13, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Audyt dodatkowy – na życzenie klienta', 14, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Okólniki i monitorowanie prawa', 15, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'E-learning', 16, 0, 0, '', '', ''),
-- (1, 'AgreementService', 'Inne', 17, 0, 0, '', '', '');
