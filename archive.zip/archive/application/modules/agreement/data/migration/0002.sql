ALTER TABLE `agreement` ADD `desc` TEXT NOT NULL COMMENT 'Dodatkowy opis' AFTER `tags`;

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (NULL, 'agreement', 'Umowy', 'agreement', '', '', '', '');
SET @idAclAgreement = (SELECT id_acl_resource FROM acl_resource WHERE name = 'agreement');

INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (@idAclAgreement, 'agreement_read', 'Przeglądanie umów', 'agreement', '', '', '', '');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (@idAclAgreement, 'agreement_write', 'Zadządzanie umowani', 'agreement', '', '', '', '');

SET @idAclAgreementRead  = (SELECT id_acl_resource FROM acl_resource WHERE name = 'agreement_read');
SET @idAclAgreementWrite = (SELECT id_acl_resource FROM acl_resource WHERE name = 'agreement_write');

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementRead, 'agreement_index_index');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementRead, 'agreement_index_show');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementWrite, 'agreement_index_new');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementWrite, 'agreement_index_edit');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementWrite, 'agreement_index_archive');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementWrite, 'agreement_index_delete');

ALTER TABLE `agreement` CHANGE `amount` `subscription_amount` DOUBLE(10,2) NULL DEFAULT NULL COMMENT 'Wartość abonamentu umowy';
ALTER TABLE `agreement` CHANGE `hour_max` `subscription_hour_max` INT(11) NULL DEFAULT NULL COMMENT 'Maksymalna ilość godzin w abonamencie';

INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'agreement.return_route', 'agreement_show');

INSERT INTO `layout` (`id_layout`, `id_service`, `type`, `id_layout_template`, `id_user`, `name`, `data_map`, `is_default`, `is_public`) VALUES (NULL, NULL, 'agreement_card', '14', '47', 'Karta umowy', '[]', '1', '1');

SET @idAclAgreementExport = (SELECT id_acl_resource FROM acl_resource WHERE name = 'export');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `module`, `desc`, `assert`, `resource_class`, `is_hidden`) VALUES (@idAclAgreementExport, 'export_agreement', 'Export umów', 'export', '', '', '', '');

SET @idAclAgreementRead = (SELECT id_acl_resource FROM acl_resource WHERE name = 'agreement_read');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementRead, 'agreement_ajax_get-list');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @idAclAgreementRead, 'agreement_ajax_get-list-item');

