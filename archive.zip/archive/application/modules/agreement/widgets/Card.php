<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:05
 */

class Agreement_Widget_Card extends Base_Widget_Abstract
{
    public      $name = 'label_agreement_widget_card';
    public      $_renderView = 'card.phtml';

    /**
     * @var Agreement
     */
    protected   $_agreement;

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }

    public function renderWidget()
    {
        if(!isset($this->params['agreement'])){
            $this->_renderView = null;
            return;
        }


        if($this->params['agreement'] instanceof Agreement)
        {
            $this->_agreement = $this->params['agreement'];

        } elseif(is_array($this->params['agreement'])) {
            $this->_agreement = $this->params['agreement'];
        } else {
            $this->_agreement = Agreement::find($this->params['agreement']);
        }

        $serviceList = AgreementItem::getList(array(
            'id_agreement' => $this->_agreement['id_agreement']
        ));

        $this->view->agreement = $this->_agreement;
        $this->view->serviceList = $serviceList;
    }
}