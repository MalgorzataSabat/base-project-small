<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 14.03.2018
 * Time: 10:21
 */

class Client_Widget_Card extends Base_Widget_Abstract
{
    public      $name = 'label_client_widget_card';
    public      $_renderView = 'card';
    protected   $_model = false;

    protected $_renderViewOptions = array(
        'card' => 'Karta klient (podstawowa)',
        'card-full' => 'Karta klient (pełna)',
    );


    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function renderWidget()
    {
        if(!isset($this->params['client'])){
            $this->_renderView = null;
            return;
        }


        if($this->params['client'] instanceof Client || is_array($this->params['client']))
        {
            $this->_model = $this->params['client'];

        } elseif($this->params['client']){
            $this->_model = Client::find($this->params['client'], array(
                'addUserCreated' => '', 'addAddressCountry' => '', 'addAddressProvince' => ''
            ));
        }

        $this->view->client = $this->_model;
    }
}