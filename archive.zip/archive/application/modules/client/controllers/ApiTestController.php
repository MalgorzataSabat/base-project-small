<?php

class Client_ApiTestController extends Base_Controller_Action
{
    
    public function createAction()
    {
        $form = new Client_Form_ApiTest();

        if($this->_request->isPost() && $form->isValid( $this->_request->getPost())) {
            $apiConfig = array(
                'id_api_service' => Setting::getSetting('api.id_api_service'),
                'key' => Setting::getSetting('api.key'),
                'base_url' => PROTOCOL.'://'.DOMAIN,
            );

            $api = new Client_Api_Service($apiConfig);

            $data = $form->getValues(true);

            var_dump('--- REQUEST ---');
            var_dump($data);
            
            $client = $api->createClient($data);

            var_dump('--- RESPONSE ---');
            var_dump($client);
        }


        $this->view->form = $form;
    }
    
}