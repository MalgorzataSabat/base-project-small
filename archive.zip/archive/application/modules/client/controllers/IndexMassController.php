<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 11.03.2017
 * Time: 12:17
 */
class Client_IndexMassController extends Base_Controller_Action
{

    private $_items = array();
    private $_form;

    public function archiveAction()
    {
        if ( $this->_request->isPost())
        {
            $ids = (array) explode(',',$this->getParam('massItems'));
            $all = (bool)$this->getParam('massItemAllPage');
            $this->_items = $this->_getItems($ids, $all);

            if(count($this->_items)){
                $clientList = Doctrine_Query::create()->from('Client')
                    ->whereIn('id_client', $this->_items)
                    ->execute();

                foreach($clientList as $client){
                    $client->archived_at = date('YmdHis');
                    $client->save();
                }

            }

            $this->_helper->viewRenderer('archive-ajax-result');
        }else{
            $this->forward403('Post request method is required');
        }
    }

    public function statusAction()
    {
        $this->_form = new Client_Form_MassStatus(array('data' => array(
            'ids' => $this->getParam('massItems'),
            'all' => $this->getParam('massItemAllPage'),
        )));

        if ( $this->_request->isPost() && $this->hasParam($this->_form->getElementsBelongTo())
            && $this->_form->isValid( $this->_request->getPost()))
        {
            $ids = (array) explode(',',$this->_form->getValue('ids'));
            $all = (bool)$this->_form->getValue('all');
            $this->_items = $this->_getItems($ids, $all);

            if(count($this->_items)){
                $clientList = Doctrine_Query::create()->from('Client')
//                    ->set('id_client_status', $this->_form->getValue('id_client_status'))
                    ->whereIn('id_client', $this->_items)
                    ->execute();

                foreach($clientList as $client){
                    $client->id_status = $this->_form->getValue('id_status');
                    $client->save();
                }

            }

            $this->_helper->viewRenderer('form-ajax-result');
        }

        $this->view->form = $this->_form;
        $this->view->countItems = $this->getParam('countItems');
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('cms-page-title_client-mass_status') );
    }

    private function _getItems($ids, $all)
    {
        if($all){
            $filter = new Client_Form_Filter();
            $dataQuery = $filter->getValuesQuery(true);
            $dataQuery['coll_key'] = 'id_client';
            $query = Client::getQuery($dataQuery);
            $query->select('id_client');

            $result = $query->execute();

            $ids = array_keys($result);
        }

        if(empty($ids)){
            $this->forward403('Mass Action not selected items');
        }


        $this->_items = $ids;

        return $this->_items;
    }
}