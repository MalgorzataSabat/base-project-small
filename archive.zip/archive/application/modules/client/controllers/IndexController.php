<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Client_IndexController extends Base_Controller_Action
{

    /**
     * @var $_model Client
     */
    private $_model     = null;
    private $_formFilter;
    private $_dataQuery = array();

    public function init()
    {
        parent::init();
    }

    public function indexAction()
    {
        $this->_formFilter = new Client_Form_Filter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);

        $query = Client::getQuery($this->_dataQuery);

        $this->view->massActionOptions = array();

        // mass action
        if($this->_acl->hasAccess('client_write')){
            $this->view->massActionOptions['status'] = array(
                'url' => Base::url('client_mass-status'),
                'name' => $this->view->translate('mass-options_client_status')
            );
            $this->view->massActionOptions['archive'] = array(
                'url' => Base::url('client_mass-archive'),
                'name' => $this->view->translate('mass-options_client_archive')
            );
        }

        if($this->_acl->hasAccess('quickmail')){
            $this->view->massActionOptions['quickmail'] = array(
                'url' => Base::url('quickmail_add-mass', array('modules' => 'client')),
                'name' => $this->view->translate('mass-options_client_quickmail')
            );
        }

        if($this->_acl->hasAccess('export_client')){
            $this->view->massActionOptions['export'] = array(
                'url' => Base::url('export', array('object' => 'client')),
                'name' => $this->view->translate('mass-options_export')
            );
        }




        $this->view->clientList = $this->_helper->paging($query, array('limit' => 20));
        $this->view->formFilter = $this->_formFilter;
    }

    public function newAction()
    {
        $this->_model = new Client();
        $this->_model->id_user_owner = Base_Auth::getUserId();
        $this->_model->client_type = Setting::getSetting('client.default_client_type');

        if($this->_request->isXmlHttpRequest()){
            $this->_formClientShort();
        } else {
            $this->_formClient();
        }

        $this->view->model = $this->_model;
    }

    public function editAction()
    {
        $id_client = $this->_getParam('id_client');
        $this->_model = Client::findRecord($id_client);
        $this->forward403Unless($this->_model);

        $this->_formClient();
    }

    private function _formClient()
    {
        $form = new Client_Form_Client(array('model' => $this->_model));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() ) {
            
            if ( $form->isValid($this->_request->getPost()) ) {
                $this->_model->save();

                $this->_flash()->success->addMessage('label_cms_save_success');
                $this->_redirector()->gotoRouteAndExit(array('id_client' => $this->_model['hash']), 'client_show');
            }
        }

        $this->view->form = $form;
        $this->view->model = $this->_model;
    }

    private function _formClientShort()
    {
        $form = new Client_Form_ClientShort(array('model' => $this->_model));
        $this->_helper->viewRenderer('form-ajax');

        if ( $this->_request->isPost() ) {
            if ( $form->isValid($this->_request->getPost()) ) {
                $this->_model->save();

                $this->_helper->viewRenderer('form-ajax-result');
            }
        }

        $this->view->form = $form;
    }

    public function showAction()
    {
        $this->_model = $this->_model = Client::find($this->_getParam('id_client'), array(
            'addUserCreated' => '', 'addAddressCountry' => '', 'addAddressProvince' => ''
        ));
        $this->forward403Unless($this->_model);

        $layoutService = new Layout_Service('client_card');
        $layoutService->setLoader('Client_Widget_Loader', array(
            'model' => $this->_model
        ));

        $this->view->layoutService = $layoutService;
        $this->view->model = $this->_model;
    }

    public function deleteAction()
    {
        $id_client = $this->_getParam('id_client');
        $this->_model = Client::findRecord($id_client);
        $this->forward403Unless($this->_model);

        $this->_model->delete();

        $this->_flash()->success->addMessage('label_cms_delete_success');
        $this->_redirector()->gotoRouteAndExit(array(), 'client');
    }

    public function archiveAction()
    {
        $id_client = $this->_getParam('id_client');
        $this->_model = Client::findRecord($id_client);
        $this->forward403Unless($this->_model);

        $this->_model->archived_at = $this->_model->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_model->save();

        if ( $this->_model->archived_at ) {
            $this->_flash()->success->addMessage('label_cms_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_cms_unarchive_success');
        }

        $this->_redirector()->gotoRouteAndExit(array(), 'client');
    }
}