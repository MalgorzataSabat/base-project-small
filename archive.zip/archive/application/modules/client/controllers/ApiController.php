<?php

class Client_ApiController extends Api_Controller_Action
{
    
    
    private $_clientData = array(

    );

    public function createAction()
    {
        
        if(!$this->_result['result']){
            return;
        }

        $this->_processClient();
    }


    private function _processClient()
    {
        $this->_clientData = $this->getAllParams();

        $dataClient = new Client_Api_Data();
        if(!$dataClient->isValid($this->_clientData)){
            $this->_result['message'] = $dataClient->getErrorMessage();
            $this->_result['result'] = false;

            return false;
        }

        $client = $dataClient->getClient();

        if($client){
            $client = $client->toArray();
        }
        
        $this->_result['body'] = $client;
    }
    
}