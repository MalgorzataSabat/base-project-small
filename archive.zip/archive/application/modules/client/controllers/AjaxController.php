<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:31
 */
class Client_AjaxController extends Base_Controller_Action
{
    /**
     * @var bool|Client
     */
    private $_client = false;


    public function getClientAction()
    {
        $id_client = $this->getParam('id_client');
        $this->forward403Unless($id_client, 'ID Client is required');

        $this->_client = Client::find($this->getParam('id_client'));
        $this->forward403Unless($this->_client);

        $this->_client['phone'] = $this->view->displayPhone($this->_client['phone']);
        $this->_client['nip'] = $this->view->displayNip($this->_client['nip']);


        $this->_helper->json($this->_client);
    }



}