ALTER TABLE `client` ADD `hash` CHAR(32) NOT NULL AFTER `id_client`;
update `client` set `hash` = MD5(CONCAT(`id_client`,"ssdfvsdfb"));
ALTER TABLE `client` ADD UNIQUE(`hash`);
INSERT INTO `setting` (`id_setting`, `id_service`, `key`, `value`) VALUES (NULL, NULL, 'client.dafault_hour-rate', '140');
