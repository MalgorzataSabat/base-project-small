ALTER TABLE `client` ADD `client_type` VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Typ clienta: private- Osoba prywatka, business- firma' AFTER `finance_hour_rate`;
