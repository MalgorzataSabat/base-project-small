update `client` SET `tags` = '[]' WHERE `tags` = 'null' OR `tags` = '';
DELETE FROM `label` WHERE `label` LIKE 'label_client_admin_list_%';
DELETE FROM `label` WHERE `label` LIKE 'filter_client-column_%';
DELETE FROM `label` WHERE `label` LIKE 'client_form_client_%';
