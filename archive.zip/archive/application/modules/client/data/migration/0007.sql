update `client` set `contact_person` = "[]", `contact_mail_fv` = "[]";
