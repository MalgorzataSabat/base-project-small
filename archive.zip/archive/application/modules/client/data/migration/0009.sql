ALTER TABLE `invoice` ADD CONSTRAINT `invoice_client` FOREIGN KEY (`id_client`) REFERENCES `client`(`id_client`) ON DELETE SET NULL ON UPDATE RESTRICT;
