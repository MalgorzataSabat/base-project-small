-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id_client` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `id_service` int(10) unsigned NOT NULL COMMENT 'Identyfikator serwisu',
  `id_client_image` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator loga klienta',
  `id_user_created` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator użytkownika, który stworzył klienta',
  `id_status` smallint(5) unsigned DEFAULT NULL COMMENT 'Identyfikator statusu klienta',
  `id_address_country` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator kraju',
  `id_address_province` tinyint(3) unsigned DEFAULT NULL COMMENT 'Identyfikator regionu',
  `address_city` varchar(255) NOT NULL COMMENT 'Nazwa miasta',
  `address_street` varchar(255) NOT NULL COMMENT 'Nazwa ulicy',
  `address_zip_code` varchar(6) NOT NULL COMMENT 'Kod pocztowy',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia klienta',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data ostatniej modyfikacji klienta',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji klienta',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia klienta',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa klienta',
  `description` text NOT NULL COMMENT 'Opis klienta',
  `nip` varchar(32) NOT NULL COMMENT 'Nip',
  `www` varchar(255) NOT NULL COMMENT 'Adres strony www',
  `email` varchar(255) NOT NULL COMMENT 'Adres email klienta',
  `phone` varchar(32) NOT NULL COMMENT 'Numer telefonu klienta',
  `contact_person` varchar(255) NOT NULL COMMENT 'Osoba do kontaktu',
  `tags` text NOT NULL COMMENT 'Tagi',
  PRIMARY KEY (`id_client`),
  KEY `id_client_image` (`id_client_image`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_client_status` (`id_status`),
  KEY `id_address_country` (`id_address_country`),
  KEY `id_address_province` (`id_address_province`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `client_ibfk_10` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`),
  CONSTRAINT `client_ibfk_2` FOREIGN KEY (`id_client_image`) REFERENCES `image` (`id_image`) ON DELETE SET NULL,
  CONSTRAINT `client_ibfk_5` FOREIGN KEY (`id_address_country`) REFERENCES `address_country` (`id_country`) ON DELETE SET NULL,
  CONSTRAINT `client_ibfk_6` FOREIGN KEY (`id_address_province`) REFERENCES `address_province` (`id_province`) ON DELETE SET NULL,
  CONSTRAINT `client_ibfk_7` FOREIGN KEY (`id_status`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  CONSTRAINT `client_ibfk_8` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  CONSTRAINT `client_ibfk_9` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='Baza danych klientów aplikacji';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
-- Dump OBJECT: ClientStatus
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Lead', '1', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Lead', '1', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Lead', '1', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Lead', '1', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Lead', '1', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Kontakt', '2', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Kontakt', '2', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Kontakt', '2', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Kontakt', '2', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Kontakt', '2', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Potencjalny', '3', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Potencjalny', '3', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Potencjalny', '3', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Potencjalny', '3', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Potencjalny', '3', '0', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Aktywny', '4', '0', '1','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Aktywny', '4', '0', '1','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Aktywny', '4', '0', '1','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Aktywny', '4', '0', '1','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Aktywny', '4', '0', '1','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Zawieszony', '5', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Zawieszony', '5', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Zawieszony', '5', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Zawieszony', '5', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Zawieszony', '5', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Nieaktywny', '6', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Nieaktywny', '6', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Nieaktywny', '6', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Nieaktywny', '6', '1', '0','', '', '');
INSERT INTO `dictionary` (`object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES ('ClientStatus', 'Nieaktywny', '6', '1', '0','', '', '');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'client','Klient','');
SET @resParentId54831 = LAST_INSERT_ID();
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54831,'client_read','Przeglądanie','');
SET @resParentId54832 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client_ajax');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client_ajax_get-client');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client_index_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54832,'client_index_show');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54831,'client_write','Zarządzanie','');
SET @resParentId54833 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index_new');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index_edit');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index_delete');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index_archive');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index-mass');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index-mass_archive');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54833,'client_index-mass_status');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54831,'client_api','Klient Api','');
SET @resParentId54860 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54860,'client_api');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54860,'client_api_create');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54860,'client_api-test');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54860,'client_api-test_create');
-- Dump MODULE: client
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'admin', 'client');
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'client'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('0001.20170718095956.csv','client','2017-07-18 08:44:05',2),('0001.sql','client','2017-07-18 08:44:01',1),('0002.sql','client','2017-12-13 10:46:44',1),('_install.sql','client','2017-07-08 08:25:36',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_client','label','2016-09-12 18:01:36','2016-09-12 18:01:36','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klienci');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_client_new','label','2016-09-12 18:01:55','2016-09-12 18:01:55','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nowy klient');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client_new','label','2016-09-12 18:02:44','2016-09-12 18:02:44','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nowy klient');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_group_std','label','2016-09-12 18:03:03','2017-05-27 16:11:02','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Podstawowe informacje');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_name','label','2016-09-12 18:15:49','2017-05-27 16:11:09','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_id_client_image','label','2016-09-12 18:16:09','2017-05-27 16:11:20','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zdjęcie');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_archived_at','label','2016-09-12 18:16:31','2017-05-27 16:11:28','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwalny');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_nip','label','2016-09-12 18:16:49','2017-05-27 16:11:36','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Numer NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_www','label','2016-09-12 18:16:59','2017-05-27 16:11:44','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres www');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_email','label','2016-09-12 18:17:09','2017-05-27 16:11:52','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres e-mail');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_phone','label','2016-09-12 18:17:27','2017-05-27 16:11:59','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_contact_person','label','2016-09-12 18:17:40','2017-05-27 16:12:08','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Osoba do kontaktu');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_group_desc_std','label','2016-09-12 18:18:19','2017-05-27 16:12:16','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Opis firmy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('button_client_admin_client_list','label','2016-09-12 18:28:38','2016-09-12 18:28:38','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista klientów');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_order','label','2016-09-12 19:05:46','2017-05-27 14:46:18','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Sortowanie');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_order_direction','label','2016-09-12 19:05:57','2017-05-27 14:48:55','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kierunek sortowania');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list-add-button','label','2016-09-12 19:06:33','2016-09-12 19:06:33','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client_list','label','2016-09-12 19:06:56','2016-09-12 19:06:56','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista klientów');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_search','label','2016-09-12 19:17:02','2017-05-27 14:48:45','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_phone','label','2016-09-12 19:17:10','2017-05-27 14:48:38','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_email','label','2016-09-12 19:17:19','2017-05-27 14:48:28','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres e-mail');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_nip','label','2016-09-12 19:17:27','2017-05-27 14:48:20','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Numer NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_archived_at','label','2016-09-12 19:17:41','2017-05-27 14:48:12','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwalne');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_client','label','2016-09-12 19:20:56','2016-09-12 19:20:56','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_created_at','label','2016-09-12 19:21:42','2016-09-12 19:21:42','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data dodania');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_client_image','label','2016-09-12 19:21:54','2016-09-12 19:21:54','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zdjęcie');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_name','label','2016-09-12 19:22:06','2016-09-12 19:22:06','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_archived_at','label','2016-09-12 19:22:16','2016-09-12 19:22:16','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwalny');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_updated_at','label','2016-09-12 19:22:27','2016-09-12 19:22:27','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_nip','label','2016-09-12 19:22:38','2016-09-12 19:22:38','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Numer NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_www','label','2016-09-12 19:22:48','2016-09-12 19:22:48','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres www');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_email','label','2016-09-12 19:22:56','2016-09-12 19:22:56','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres e-mail');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_phone','label','2016-09-12 19:23:04','2016-09-12 19:23:04','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_contact_person','label','2016-09-12 19:23:15','2016-09-12 19:23:15','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Osoba do kontaktu');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_address_street','label','2016-09-12 19:23:33','2016-09-12 19:23:33','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_address_zip_code','label','2016-09-12 19:23:43','2016-09-12 19:23:43','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_address_city','label','2016-09-12 19:23:52','2016-09-12 19:23:52','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_id_client','label','2016-09-12 19:25:30','2016-09-12 19:25:30','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_created_at','label','2016-09-12 19:25:41','2016-09-12 19:25:41','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data dodania');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_name','label','2016-09-12 19:25:49','2016-09-12 19:25:49','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_archived_at','label','2016-09-12 19:26:04','2016-09-12 19:26:04','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwalny');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_updated_at','label','2016-09-12 19:26:15','2016-09-12 19:26:15','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_www','label','2016-09-13 13:00:05','2016-09-13 13:00:05','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres www');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_options','label','2016-09-13 13:00:15','2016-09-13 13:00:15','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Opcje');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_phone','label','2016-09-13 13:00:28','2016-09-13 13:00:28','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_id_client_image','label','2016-09-13 13:00:53','2016-09-13 13:00:53','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zdjęcie');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_nip','label','2016-09-13 13:01:03','2016-09-13 13:01:03','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Numer NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_email','label','2016-09-13 13:01:13','2016-09-13 13:01:13','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres e-mail');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_contact_person','label','2016-09-13 13:01:22','2016-09-13 13:01:22','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Osoba do kontaktu');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_address_street','label','2016-09-13 13:01:37','2016-09-13 13:01:37','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_address_zip_code','label','2016-09-13 13:01:46','2016-09-13 13:01:46','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_address_city','label','2016-09-13 13:01:55','2016-09-13 13:01:55','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_record_archive','label','2016-09-13 13:03:13','2016-09-13 13:03:13','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwizuj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_contact_person','label','2016-09-13 13:16:36','2017-05-27 14:48:02','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Osoba do kontaktu');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client_edit','label','2016-09-13 13:26:51','2016-09-13 13:27:50','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja Klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_client_edit','label','2016-09-13 13:27:13','2016-09-13 13:27:13','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_client_status','label','2016-09-13 14:39:26','2016-09-13 14:39:26','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_client_archived_at_time: %s','label','2016-09-13 14:41:47','2017-05-27 16:12:25','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data archiwizacji: %s');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_status','label','2016-09-13 15:35:20','2017-06-18 15:43:31','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_id_status','label','2016-09-13 15:42:17','2017-06-18 15:42:56','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_id_address_province','label','2016-11-25 17:27:14','2016-11-25 17:27:14','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Region');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_id_address_province','label','2016-11-25 17:28:00','2016-11-25 17:28:00','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Region');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_status','label','2016-11-29 14:09:34','2016-11-29 14:09:34','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_created_at','label','2016-11-29 14:10:04','2016-11-29 14:10:04','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_phone','label','2016-11-29 14:10:19','2016-11-29 14:10:19','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Telefon');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_email','label','2016-11-29 14:10:34','2016-11-29 14:10:34','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres e-mail');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_www','label','2016-11-29 14:11:12','2016-11-29 14:11:12','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres www');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_panel_client-tab','label','2016-11-29 15:56:19','2016-11-29 15:56:19','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klient');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_panel_client-address','label','2016-11-29 15:56:37','2016-11-29 15:56:37','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dane adresowe');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client_show','label','2016-11-29 15:57:14','2016-11-29 15:57:14','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klient');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_panel_title','label','2016-11-29 15:57:42','2016-11-29 15:57:42','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_name','label','2016-11-29 15:57:56','2016-11-29 15:57:56','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_nip','label','2016-11-29 15:58:09','2016-11-29 15:58:09','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','NIP');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_address_country','label','2016-11-29 15:58:49','2016-11-29 15:58:49','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kraj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_address_province','label','2016-11-29 15:58:59','2016-11-29 15:58:59','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Region');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_address_city','label','2016-11-29 15:59:09','2016-11-29 15:59:09','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_address_street','label','2016-11-29 15:59:20','2016-11-29 15:59:20','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_address_zip_code','label','2016-11-29 15:59:31','2016-11-29 15:59:31','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('field_client_quick-add','label','2017-02-01 13:23:42','2017-02-01 13:23:42','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj nowego klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_www','label','2017-03-11 12:05:28','2017-05-27 14:47:52','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Adres www');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_id_user_created','label','2017-03-11 12:06:01','2017-05-27 14:47:45','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Utworzone przez');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_address_city','label','2017-03-11 12:06:18','2017-05-27 14:47:37','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Miasto');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_address_street','label','2017-03-11 12:06:29','2017-05-27 14:47:28','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Ulica');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_address_zip_code','label','2017-03-11 12:06:44','2017-05-27 14:47:20','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kod pocztowy');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_created_at','label','2017-03-11 12:06:58','2017-05-27 14:47:12','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data utworzenia');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_id_client','label','2017-03-11 12:07:42','2017-05-27 14:47:04','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','ID');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_name','label','2017-03-11 12:08:00','2017-05-27 14:46:57','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Imię i nazwisko');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_updated_at','label','2017-03-11 12:08:14','2017-05-27 14:46:48','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Data modyfikacji');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('nav-cms_client_show','label','2017-03-11 12:10:15','2017-03-11 12:10:15','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Szczegóły klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_button_list','label','2017-03-11 12:10:35','2017-03-11 12:10:35','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Lista klientów');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('mass-options_client_status','label','2017-03-11 13:00:00','2017-03-11 13:00:00','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zmień status klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client-mass_status','label','2017-03-11 13:00:22','2017-03-11 13:00:22','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Zmiana statusu klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('mass-options_client_archive','label','2017-03-11 13:03:59','2017-03-11 13:03:59','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Archiwizuj');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('cms-page-title_client-mass_quickmail','label','2017-04-25 13:05:57','2017-04-25 13:05:57','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodawanie odbiorców do wysyłki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('mass-options_client_quickmail','label','2017-04-26 10:21:23','2017-04-26 10:21:23','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodanie klientów do wysyłki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_button_quickmail','label','2017-05-22 22:43:46','2017-05-22 22:43:46','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodaj klienta do szybkiej wysyłki');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('module_name-client','label','2017-05-27 14:46:33','2017-05-27 15:40:53','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Klient');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_id_status','label','2017-05-27 14:50:07','2017-06-18 15:43:41','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Status klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_contact_person','label','2017-05-27 16:33:07','2017-05-27 16:33:07','client','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Osoba kontaktowa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_show-client-tab_empty','label','2017-07-15 16:55:32','2017-07-18 10:44:04','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nie wybrano klienta');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_show_tags','label','2017-07-18 10:44:05','2017-07-18 10:44:05','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Tagi');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('client_form_filter_tags','label','2017-07-18 10:44:05','2017-07-18 10:44:05','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Tagi');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('filter_client-column_tag','label','2017-07-18 10:44:05','2017-07-18 10:44:05','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Tagi');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_client_admin_list_tags','label','2017-07-18 10:44:05','2017-07-18 10:44:05','client','1');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Tagi');
