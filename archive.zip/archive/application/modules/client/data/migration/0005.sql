ALTER TABLE `client` ADD `finance_hour_rate` DOUBLE(10,2) NULL DEFAULT NULL COMMENT 'Stawka godzinowa dla klietna' AFTER `tags`;
