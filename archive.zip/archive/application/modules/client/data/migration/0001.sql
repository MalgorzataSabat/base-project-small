ALTER TABLE `client` ADD `tags` TEXT NOT NULL COMMENT 'Tagi';


