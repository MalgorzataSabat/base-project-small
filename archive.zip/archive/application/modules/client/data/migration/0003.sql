ALTER TABLE `client` ADD `id_industry` SMALLINT(5) UNSIGNED NULL AFTER `id_address_province`, ADD INDEX (`id_industry`);

ALTER TABLE `client` ADD FOREIGN KEY (`id_industry`) REFERENCES `industry`(`id_industry`) ON DELETE SET NULL ON UPDATE RESTRICT;