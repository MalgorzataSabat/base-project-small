ALTER TABLE `client` ADD `id_source` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Źródło pozyskania klienta' AFTER `finance_hour_rate`, ADD INDEX (`id_source`);
UPDATE `setting` SET `value` = '[\"PersonStatus\",\"TaskStatus\", \"TaskType\", \"TaskTypeSub\",\"ClientStatus\", \"ClientSource\",\"TaskPriority\",\"Tax\",\"InvoiceUnit\",\"InvoicePayMethod\",\"InvoicePayTermDay\",\"InvoiceCorrectionReason\",\"Currency\",\"ProjectStatus\",\"DealStatus\",\"BillStatus\",\"ContractType\",\"AgreementStatus\",\"AgreementService\",\"TemplateType\"]' WHERE `setting`.`key` = 'dictionary.objects';

INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `id_parent`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES
(NULL, '1', NULL, 'ClientSource', 'Polecenie', '1', '', '', '', '', ''),
(NULL, '1', NULL, 'ClientSource', 'Strona internetowa', '2', '', '', '', '', ''),
(NULL, '1', NULL, 'ClientSource', 'Z reklamy w internecie', '3', '', '', '', '', ''),
(NULL, '1', NULL, 'ClientSource', 'Z mailingu', '4', '', '', '', '', '');

INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `id_parent`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES
(NULL, '2', NULL, 'ClientSource', 'Polecenie', '1', '', '', '', '', ''),
(NULL, '2', NULL, 'ClientSource', 'Strona internetowa', '2', '', '', '', '', ''),
(NULL, '2', NULL, 'ClientSource', 'Z reklamy w internecie', '3', '', '', '', '', ''),
(NULL, '2', NULL, 'ClientSource', 'Z mailingu', '4', '', '', '', '', '');
