ALTER TABLE `client` ADD `short_name` VARCHAR(255) NOT NULL AFTER `name`;
ALTER TABLE `client` ADD `id_user_owner` INT UNSIGNED NULL DEFAULT NULL AFTER `phone`, ADD INDEX `user_owner` (`id_user_owner`);
ALTER TABLE `client` ADD `id_users_assign` VARCHAR(255) NOT NULL DEFAULT '[]' AFTER `id_user_owner`;
update `client` set `id_user_owner` = `id_user_created`;
ALTER TABLE `client` CHANGE `id_users_assign` `assign_users` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '[]';
ALTER TABLE `client` ADD FOREIGN KEY (`id_user_owner`) REFERENCES `user`(`id_user`) ON DELETE SET NULL ON UPDATE RESTRICT;
