ALTER TABLE `client` ADD `id_service` INT UNSIGNED NOT NULL COMMENT 'Identyfikator serwisu' AFTER `id_client`, ADD INDEX (`id_service`) ;
update `client` SET `id_service` = 1;
ALTER TABLE `client` ADD FOREIGN KEY (`id_service`) REFERENCES `service`(`id_service`) ON DELETE RESTRICT ON UPDATE RESTRICT;

