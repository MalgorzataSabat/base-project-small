<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Client_Form_ClientShort extends Base_Form_Horizontal
{

    protected $_tlabel = 'client_form_client_';

    public function init()
    {
        $fields = array();
        $fields_desc = array();

        $this->setAction(Base::url());

        if(Setting::getSetting('client.turn_off_client_type'))
        {
            $multiOptions = Client::$client_type;
            $fields['client_type'] = $this->createElement('radio', 'client_type', array(
                'label' => $this->_tlabel.'client_type',
                'class' => 'clientType radio-inline ',
                'offset' => 4,
                'multiOptions' => $multiOptions,
                'required' => true,
                'allowEmpty' => false,
                'inline' => true,
                //            'filters' => array('StringTrim'),
                'value' => $this->_model->getClientType(),
                'size' => 8,
                'label-size' => 4
            ));
            $fields['client_type']->getDecorator('WrapElement')->setOption('class', 'inline-group');
            $fields['client_type']->removeDecorator('Label');
        }

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model->getName(),
            'size' => 8,
            'label-size' => 4
        ));

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'object' => 'ClientStatus',
            'value' => $this->_model['id_status'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['id_industry'] = new Industry_Form_Element_Industry('id_industry', array(
            'label' => $this->_tlabel.'id_industry',
            'value' => $this->_model['id_industry'],
            'required' => false,
            'allowEmpty' => true,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields['nip'] = $this->createElement('text', 'nip', array(
            'label' => $this->_tlabel.'nip',
            'allowEmpty' => true,
            'required' => false,
            'filters' => array(new Base_Filter_Nip),
            'value' => $this->_model->getNip(),
            'size' => 8,
            'label-size' => 4,
        ));
        $fields['nip']->getDecorator('WrapElement')->setOption('class', 'typeElementHide');

        $fields['www'] = $this->createElement('text', 'www', array(
            'label' => $this->_tlabel.'www',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim', new Base_Filter_HttpLink()),
            'placeholder' => 'http://',
            'value' => $this->_model->getWww(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => $this->_tlabel.'email',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'value' => $this->_model->getEmail(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => $this->_tlabel.'phone',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Phone),
            'value' => $this->_model->getPhone(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['contact_person'] = $this->createElement('text', 'contact_person', array(
            'label' => $this->_tlabel.'contact_person',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getContactPerson(),
            'size' => 8,
            'label-size' => 4,
        ));

        $this->addDisplayGroup(
            $fields,
            'main',
            array(
                'legend' => $this->_tlabel.'group_std'
            )
        );

        $this->setAttrib('id', $this->getElementsBelongTo());

        $addressForm = new Address_Form_Address(array('model' => $this->_model));
        $this->addSubForm($addressForm, 'address');

        $group_main = $this->getDisplayGroup('main');
        $group_address = $addressForm->getDisplayGroup('main');

        $this->addHtmlTag(array($group_main), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_main, $group_address), array('class' => 'row'));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }


    public function render(Zend_View_Interface $view = null)
    {
        $clientTypeValue = $this->getValue('client_type');
        !$clientTypeValue && $clientTypeValue = $this->_model['client_type'];

        $nip = $this->getElement('nip');

        if($clientTypeValue == Client::CLIENT_PRIVATE) {
            $nip->getDecorator('WrapElement')->setOption('style','display:none');
        }


        return parent::render($view);
    }

}