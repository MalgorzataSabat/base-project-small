<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Client_Form_Import extends Base_Form_Horizontal
{
    /**
     * @var Import
     */
    private $_import;

    private $_defaultValues;

    protected function setImport($import)
    {
        $this->_import = $import;
        $this->_defaultValues = json_decode($this->_import['default_values'], true);
    }


    public function init()
    {
        $fields = array();

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => Base::getFiledNameLabel('client.id_status'),
            'object' => 'ClientStatus',
            'required' => true,
            'allowEmpty' => false,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'value' => isset($this->_defaultValues['id_status']) ? $this->_defaultValues['id_status'] : '',
            'use_default' => true
        ));

        $fields['id_user_owner'] = new User_Form_Element_User('id_user_owner', array(
            'label' => Base::getFiledNameLabel('client.id_user_owner'),
            'decorators' => $this->_elementDecorators,
            'required' => true,
            'allowEmpty' => false,
            'value' => isset($this->_defaultValues['id_user_owner']) ? $this->_defaultValues['id_user_owner'] : '',
            'select2' => true,
        ));

        $fields['id_source'] = new Dictionary_Form_Element_Select('id_source', array(
            'label' => Base::getFiledNameLabel('client.id_source'),
            'object' => 'ClientSource',
            'required' => false,
            'allowEmpty' => true,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'value' => isset($this->_defaultValues['id_source']) ? $this->_defaultValues['id_source'] : '',
        ));

        $this->addElements($fields);
        $this->setElementsBelongTo('defaultValues');
        $this->setDecorators(array('FormElements'));
    }



}