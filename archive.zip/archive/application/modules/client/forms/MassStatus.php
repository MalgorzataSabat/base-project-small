<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 11.03.2017
 * Time: 12:18
 */
class Client_Form_MassStatus extends Base_Form_Horizontal
{

    protected $_data;

    protected function setData($data)
    {
        $this->_data = $data;
    }

    public function init()
    {
        $fields = array();
        $this->setAction(Base::url());

        $fields['ids'] = $this->createElement('hidden', 'ids', array('value' => $this->_data['ids']));
        $fields['ids']->removeDecorator('WrapElement');
        $fields['all'] = $this->createElement('hidden', 'all', array('value' => $this->_data['all']));
        $fields['all']->removeDecorator('WrapElement');

        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => 'field_status',
            'value' => $this->_model['id_status'],
            'object' => 'ClientStatus',
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit',
            'btnClass' => 'success'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }
}