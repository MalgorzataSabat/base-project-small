<?php

class Client_Form_ApiTest extends Base_Form_Horizontal
{
    public function init()
    {
        $fields = array();

        $fields['id'] = $this->createElement('text', 'id', array(
            'label' => 'Identyfikator',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'size' => 8,
            'label-size' => 4
        ));


        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => 'Nazwa firmy',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'size' => 8,
            'label-size' => 4
        ));

        $fields['nip'] = $this->createElement('text', 'nip', array(
            'label' => 'NIP',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['address_city'] = $this->createElement('text', 'address_city', array(
            'label' => 'Miejscowość',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['address_street'] = $this->createElement('text', 'address_street', array(
            'label' =>'Ulica',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['address_zip_code'] = $this->createElement('text', 'address_zip_code', array(
            'label' => 'Kod pocztowy',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => 'E-mail',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => 'Telefon',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['contact_person'] = $this->createElement('text', 'contact_person', array(
            'label' => 'Osoba kontaktowa',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'size' => 8,
            'label-size' => 4,
        ));


        $this->addDisplayGroup($fields, 'main', array(
            'legend' => 'API Test - Client'
        ));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));
    }
}