<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Client_Form_Client extends Base_Form_Horizontal
{

    /**
     * @var $_model Client
     */
    protected $_model = null;

    public function init()
    {
        $fields = array();
        $fields_adv = array();
        $fields_desc = array();
        $_acl = Base_Acl::_();


//        if($this->_model->isNew()) {
        if(Setting::getSetting('client.turn_off_client_type'))
        {
            $multiOptions = Client::$client_type;

            $fields['client_type'] = $this->createElement('radio', 'client_type', array(
                'label' => Base::getFiledNameLabel('client.client_type'),
                'class' => 'clientType ',
                'offset' => 4,
                'multiOptions' => $multiOptions,
                'required' => true,
                'allowEmpty' => false,
                'inline' => true,
                'label_class' => 'radio',
    //            'filters' => array('StringTrim'),
                'value' => $this->_model->getClientType(),
                'size' => 8,
                'label-size' => 4
            ));
            $fields['client_type']->getDecorator('WrapElement')->setOption('class', 'inline-group');
            $fields['client_type']->removeDecorator('Label');
        }

//        }


        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => Base::getFiledNameLabel('client.name'),
            'class' => 'name',
            'required' => true,
            'allowEmpty' => false,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model->getName(),
            'size' => 8,
            'label-size' => 4
        ));

        $fields['short_name'] = $this->createElement('text', 'short_name', array(
            'label' => Base::getFiledNameLabel('client.short_name'),
            'class' => 'name',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model['short_name'],
            'size' => 8,
            'label-size' => 4
        ));
        $fields['short_name']->getDecorator('WrapElement')->setOption('class', 'typeElementHide');


        $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => Base::getFiledNameLabel('client.id_status'),
            'object' => 'ClientStatus',
            'value' => $this->_model['id_status'],
            'required' => true,
            'allowEmpty' => false,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $fields['nip'] = $this->createElement('text', 'nip', array(
            'label' => Base::getFiledNameLabel('client.nip'),
            'allowEmpty' => true,
            'required' => false,
            'filters' => array(new Base_Filter_Nip),
            'input-group' => array(
                'post' => array(
                    'type' => 'href',
                    'class' => '',
                    'id' => 'gusButtonAction',
                    'data-url' => Base::url('tools_gus'),
                    'data-id' => '#' . $this->_tlabel . 'nip',
                    'label' => '<i class="fa fa-download"></i> pobierz z GUS',
                ),
                
            ),
            'id' => $this->_tlabel. 'nip',
            'value' => $this->_model->getNip(),
            'size' => 8,
            'label-size' => 4,
        ));
        $fields['nip']->getDecorator('WrapElement')->setOption('class', 'typeElementHide');

        if($_acl->hasAccess('field.client.id_user_owner', 'write')){
            $fields['id_user_owner'] = new User_Form_Element_User('id_user_owner', array(
                'label' => Base::getFiledNameLabel('client.id_user_owner'),
                'value' => $this->_model['id_user_owner'],
                'decorators' => $this->_elementDecorators,
                'allowEmpty' => false,
                'required' => true,
                'label-size' => 4,
                'size' => 8,
                'select2' => true,
            ));
        }

        $valueAssignUsers = !empty($this->_model['assign_users']) ? json_decode($this->_model['assign_users']) : array();
        $fields['assign_users'] = new User_Form_Element_User('assign_users', array(
            'label' => Base::getFiledNameLabel('client.assign_users'),
            'value' => $valueAssignUsers,
            'decorators' => $this->_elementDecorators,
            'allowEmpty' => true,
            'required' => false,
            'label-size' => 4,
            'size' => 8,
            'multiple' => 'multiple',
            'select2' => true,
            'registerInArrayValidator' => false,
        ));

        $fields['www'] = $this->createElement('text', 'www', array(
            'label' => Base::getFiledNameLabel('client.www'),
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim', new Base_Filter_HttpLink()),
            'placeholder' => 'http://',
            'value' => $this->_model->getWww(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['email'] = $this->createElement('text', 'email', array(
            'label' => Base::getFiledNameLabel('client.email'),
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('EmailAddress', true)
            ),
            'value' => $this->_model->getEmail(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['phone'] = $this->createElement('text', 'phone', array(
            'label' => Base::getFiledNameLabel('client.phone'),
            'required' => false,
            'allowEmpty' => true,
            'filters' => array(new Base_Filter_Phone),
            'value' => $this->_model->getPhone(),
            'size' => 8,
            'label-size' => 4,
        ));

        $fields['id_client_image'] = $this->createElement('FileImage', 'id_client_image', array(
            'label' => Base::getFiledNameLabel('client.id_client_image'),
            'allowEmpty' => true,
            'required' => false,
            'validators' => array(
                array('Extension', false, 'jpg, jpeg, png, gif'),
                array('Count', false, 1),
            ),
            'size' => 8,
            'label-size' => 4
        ));
        if ( !empty($this->_model->id_client_image) ) {
            $imageDecorator = $fields['id_client_image']->getDecorator('FileImage');
            $imageDecorator->setOptions(array(
                'id_image' => $this->_model->id_client_image,
                'crop' => true,
                'delete' => true
            ));
        }


        $fields_adv['id_source'] = new Dictionary_Form_Element_Select('id_source', array(
            'label' => Base::getFiledNameLabel('client.id_source'),
            'object' => 'ClientSource',
            'value' => $this->_model['id_source'],
            'required' => false,
            'allowEmpty' => true,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        $fields_adv['id_industry'] = new Industry_Form_Element_Industry('id_industry', array(
            'label' => Base::getFiledNameLabel('client.id_industry'),
            'value' => $this->_model['id_industry'],
            'required' => false,
            'allowEmpty' => true,
            'size' => 8,
            'label-size' => 4,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
        ));

        if(!$this->_model->isNew()){
            $valueContactPerson = !empty($this->_model['contact_person']) ? json_decode($this->_model['contact_person']) : array();
            $fields_adv['contact_person'] = new Person_Form_Element_Select('contact_person', array(
                'label' => Base::getFiledNameLabel('client.contact_person'),
                'required' => false,
                'allowEmpty' => true,
                'value' => $valueContactPerson,
                'size' => 8,
                'label-size' => 4,
                'multiple' => 'multiple',
                'id_client' => $this->_model->getId(),
                'decorators' => $this->_elementDecorators,
                'registerInArrayValidator' => false,
            ));

            $valueContactMailFv = !empty($this->_model['contact_mail_fv']) ? json_decode($this->_model['contact_mail_fv']) : array();
            $fields_adv['contact_mail_fv'] = new Person_Form_Element_Select('contact_mail_fv', array(
                'label' => Base::getFiledNameLabel('client.contact_mail_fv'),
                'required' => false,
                'allowEmpty' => true,
                'value' => $valueContactMailFv,
                'size' => 8,
                'label-size' => 4,
                'multiple' => 'multiple',
                'id_client' => $this->_model->getId(),
                'decorators' => $this->_elementDecorators,
                'registerInArrayValidator' => false,
            ));
        }


        if($_acl->hasAccess('client_finance')){
            $fields_adv['finance_hour_rate'] = $this->createElement('text', 'finance_hour_rate', array(
                'label' => Base::getFiledNameLabel('client.finance_hour_rate'),
                'required' => false,
                'allowEmpty' => true,
                'filters' => array('StringTrim', 'Float', 'Null'),
                'value' => $this->_model['finance_hour_rate'],
                'size' => 8,
                'label-size' => 4,
            ));
        }

        $fields_adv['tags'] = new Tag_Form_Element_Tag('tags', array(
            'label' => Base::getFiledNameLabel('client.tags'),
            'value' => !empty($this->_model['tags']) ? json_decode($this->_model['tags']) : array(),
            'size' => 8,
            'label-size' => 4,
            'allowEmpty' => true,
            'required' => false,
            'select2' => array(),
            'data-tags' => true,
            'data-token-separators' => "[',']",
            'multiple' => 'multiple',
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'model' => 'Client',
        ));
        $fields_adv['tags']->getDecorator('Description')->setEscape(false);
        $fields_adv['tags']->setDescription('<i class="fa fa-tags"></i> Opisz klienta tagami');


        $fields_desc['description'] = $this->createElement('wysiwyg', 'description', array(
            'label' => Base::getFiledNameLabel('client.description'),
            'label' => $this->_tlabel.'description',
            'allowEmpty' => true,
            'required' => false,
            'filters' => array('StringTrim'),
            'value' => $this->_model->getDescription(),
            'size' => 12,
            'data-small' => true
        ))->removeDecorator('Label');



        $this->addDisplayGroup($fields, 'main', array(
            'legend' => 'Podstawowe informacje'
        ));

        $addressForm = new Address_Form_Address(array('model' => $this->_model));
        $this->addSubForm($addressForm, 'address');

        $this->addDisplayGroup($fields_adv, 'main_adv', array(
            'legend' => 'Dodatkowe informacje'
        ));

        $this->addDisplayGroup($fields_desc, 'main_desc', array(
            'legend' => 'Opis'
        ));


        $group_main = $this->getDisplayGroup('main');
        $group_address = $addressForm->getDisplayGroup('main');
        $group_adv = $this->getDisplayGroup('main_adv');

        $this->addHtmlTag(array($group_main), array('class' => 'col-md-6'));

        $this->addHtmlTag(array($group_adv), array('class' => 'col-md-6'));
        $this->addHtmlTag(array($group_main, $group_adv), array('class' => 'row'));

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'btnClass' => 'success',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setFormActions(array( $save));
        $this->addElements(array($save));
    }

    public function render(Zend_View_Interface $view = null)
    {
        $clientTypeValue = $this->getValue('client_type');
        !$clientTypeValue && $clientTypeValue = $this->_model['client_type'];

        $nip = $this->getElement('nip');
        $short_name = $this->getElement('short_name');

        if($clientTypeValue == Client::CLIENT_PRIVATE) {
            $nip->getDecorator('WrapElement')->setOption('style','display:none');
            $short_name->getDecorator('WrapElement')->setOption('style','display:none');
        }


        return parent::render($view);
    }

}