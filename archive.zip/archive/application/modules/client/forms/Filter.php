<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 18:35
 */
class Client_Form_Filter extends Base_Form_Filter
{

    protected $_version = 2;

    protected $_sortCols        = array(
        'id_client' => 'o.id_client',
        'created_at' => 'o.created_at',
        'name' => 'o.name',
        'contact_person' => 'o.contact_person',
        'archived_at' => 'o.archived_at',
        'updated_at' => 'o.updated_at',
    );

    protected $_avalibleCols    = array(
        'id_client' => 'filter_client-column_id_client',
        'created_at' => 'filter_client-column_created_at',
        'id_client_image' => 'filter_client-column_id_client_image',
        'name' => 'filter_client-column_name',
        'short_name' => 'filter_client-column_short_name',
        'id_status' => 'filter_client-column_id_status',
        'id_source' => 'filter_client-column_id_source',
        'archived_at' => 'filter_client-column_id_archived_at',
        'updated_at' => 'filter_client-column_id_updated_at',
        'nip' => 'filter_client-column_nip',
        'www' => 'filter_client-column_www',
        'email' => 'filter_client-column_email',
        'phone' => 'filter_client-column_phone',
        'id_user_owner' => 'filter_client-column_id_user_owner',
        'assign_users' => 'filter_client-column_assign_users',
        'contact_person' => 'filter_client-column_contact_person',
        'id_address_province' => 'filter_client-column_id_address_province',
        'address_street' => 'filter_client-column_address_street',
        'address_zip_code' => 'filter_client-column_address_zip_code',
        'address_city' => 'filter_client-column_address_city',
        'tags' => 'filter_client-column_tag',
        'id_industry' => 'filter_client-column_id_industry',
    );

    protected $_fieldsDisplay   = array(
        'search', 'id_status', 'email'
    );

    protected $_defaultCols     = array (
        'name', 'id_status', 'contact_person', 'phone', 'www', 'updated_at'
    );

    public function init()
    {
        $_acl = Base_Acl::_();

        if($_acl->hasAccess('client_finance')){
            $this->_sortCols['finance_hour_rate'] = 'o.finance_hour_rate';
            $this->_avalibleCols['finance_hour_rate'] = 'filter_client-column_finance_hour_rate';
        }

        $this->_searchElements['search'] = $this->createElement('text', 'search', array(
            'label' => Base::getFiledNameLabel('search'),
        ));

        $this->_searchElements['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => Base::getFiledNameLabel('client.id_status'),
            'object' => 'ClientStatus',
        ));

        $this->_searchElements['id_source'] = new Dictionary_Form_Element_Select('id_source', array(
            'label' => Base::getFiledNameLabel('client.id_source'),
            'object' => 'ClientSource',
        ));

        $this->_searchElements['email'] = $this->createElement('text', 'email', array(
            'label' => Base::getFiledNameLabel('client.email'),
        ));

        $this->_searchElements['phone'] = $this->createElement('text', 'phone', array(
            'label' => Base::getFiledNameLabel('client.phone'),
            'filters' => array(new Base_Filter_Phone),
        ));

        $this->_searchElements['www'] = $this->createElement('text', 'www', array(
            'label' => Base::getFiledNameLabel('client.www'),
        ));

        if($_acl->hasAccess('client_finance')) {
            $this->_searchElements['finance_hour_rate'] = $this->createElement('search_Number', 'finance_hour_rate', array(
                'label' => Base::getFiledNameLabel('client.finance_hour_rate'),
            ));
        }

        $this->_searchElements['nip'] = $this->createElement('text', 'nip', array(
            'label' => Base::getFiledNameLabel('client.nip'),
            'filters' => array(new Base_Filter_Nip),
        ));

        $this->_searchElements['id_industry'] = new Industry_Form_Element_Industry('id_industry', array(
            'label' => Base::getFiledNameLabel('client.id_industry'),
            'select2' => true,
            'searchable' => true,
        ));

        $this->_searchElements['contact_person'] = new Person_Form_Element_Select('contact_person', array(
            'label' => Base::getFiledNameLabel('client.contact_person'),
        ));

        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' => Base::getFiledNameLabel('client.id_user_created'),
        ));

        $this->_searchElements['id_user_owner'] = new User_Form_Element_User('id_user_owner', array(
            'label' => Base::getFiledNameLabel('client.id_user_owner'),
        ));

        $this->_searchElements['assign_users'] = new User_Form_Element_User('assign_users', array(
            'label' => Base::getFiledNameLabel('client.assign_users'),
        ));

        $this->_searchElements['address_city'] = $this->createElement('text', 'address_city', array(
            'label' => Base::getFiledNameLabel('client.address_city'),
        ));

        $this->_searchElements['address_street'] = $this->createElement('text', 'address_street', array(
            'label' => Base::getFiledNameLabel('client.address_street'),
        ));

        $this->_searchElements['address_zip_code'] = $this->createElement('text', 'address_zip_code', array(
            'label' => Base::getFiledNameLabel('client.address_zip_code'),
        ));
        
        $this->_searchElements['tags'] = new Tag_Form_Element_Tag('tags', array(
            'label' => Base::getFiledNameLabel('client.tags'),
            'select2' => array(),
            'multiple' => 'multiple',
            'model' => 'Client',
        ));
        
        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => Base::getFiledNameLabel('client.created_at'),
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['archived_at'] = new Base_Form_Element_ArchivedAt();
    }
}