<?php
class Client_Api_Service extends Api_Service
{

    private $_base_url = null;

    private static $URL_MAP = array(
        'create-client' => 'client/api/create',
    );

    /**
     * @param $options
     */
    public function __construct($options)
    {
        parent::__construct($options);

        if(isset($options['base_url'])){
            $this->setBaseUrl($options['base_url']);
        }

    }

    /**
     * @return null
     */
    public function getBaseUrl()
    {
        return $this->_base_url;
    }

    /**
     * @param $baseUrl
     * @return $this
     */
    public function setBaseUrl($baseUrl)
    {
        $this->_base_url = $baseUrl;

        return $this;
    }


    public function createClient($data)
    {
        if(!$this->_validateClient($data)){
            return false;
        }

        $this->addParams($data);

        $this->setUrl($this->getBaseUrl().'/'.self::$URL_MAP['create-client']);

        return $this->makeRequest();
    }

    private function _validateClient($data)
    {
//        if(!isset($data['id']) || !strlen($data['id'])){
//            return false;
//        }

        if(!isset($data['name']) || !strlen($data['name'])){
            return false;
        }

        if(!isset($data['nip']) || !strlen($data['nip'])){
            return false;
        }

        return true;
    }


}