<?php
class Client_Api_Data extends Api_Data
{

    /**
     * @var Client
     */
    protected $_client;

    public function isValid($data = null)
    {
        if($data){
            $this->setData($data);
        }

        if(null !== $this->_isValid){
            return $this->_isValid;
        }

        if( !isset($this->_data['id_api_service']) || !strlen($this->_data['id_api_service'])){
            $this->_error['message'] = 'Client: Field "id_api_service" is required';

            $this->_isValid = false;
            return $this->_isValid;
        }

//        if( !isset($this->_data['id']) || !strlen($this->_data['id'])){
//            $this->_error['message'] = 'Client: Field "id" is required';
//
//            $this->_isValid = false;
//            return $this->_isValid;
//        }

        if( !isset($this->_data['name']) || !strlen($this->_data['name'])){
            $this->_error['message'] = 'Client: Field "name" is required';

            $this->_isValid = false;
            return $this->_isValid;
        }

        if( !isset($this->_data['nip']) || !strlen($this->_data['nip'])){
            $this->_error['message'] = 'Client: Field "NIP" is required';

            $this->_isValid = false;
            return $this->_isValid;
        }


        $this->_isValid = true;
        return $this->_isValid;
    }


    public function getClient()
    {
        if(!$this->isValid()){
            throw new Exception('Client data is not Valid');
        }
        $this->_data['nip'] = str_replace(array('-', ' '), '', $this->_data['nip']);
        $queryOptions = array('nip' => $this->_data['nip'], 'is_active' => '', 'hydrate' => Doctrine::HYDRATE_RECORD);
        $this->_client = Client::getRecord($queryOptions);

        if(!$this->_client){
            $this->_client = new Client();

            $dictionary = Dictionary::getDefault('ClientStatus');
            if($dictionary){ $this->_client->id_status = $dictionary['id_dictionary']; }

            $this->_client->name = $this->_data['name'];
            $this->_client->nip = $this->_data['nip'];
            $this->_client->address_city = $this->_data['address_city'];
            $this->_client->address_street = $this->_data['address_street'];
            $this->_client->address_zip_code = $this->_data['address_zip_code'];
            $this->_client->email = $this->_data['email'];
            $this->_client->phone = $this->_data['phone'];
            $this->_client->contact_person = $this->_data['contact_person'];
            $this->_client->save();
        }

        return $this->_client;
    }


}