<?php


class Client_Extractor extends Base_Extractor
{

    protected $_tables = array('client');

    protected $_data = array();

    protected $_module = 'client';

    protected $_dumpResource = array('client');

    protected $_dumpRule = array('client');

    protected $_dumpLabel = array('client');

    protected $_dumpChangelog = array('client');

    protected $_dumpSettings = array('client');

    protected $_dumpDictionary = array('ClientStatus');


}