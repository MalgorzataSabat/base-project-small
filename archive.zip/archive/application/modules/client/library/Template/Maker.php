<?php


class Client_Template_Maker extends Template_Maker_Abstract implements Template_Maker_Interface
{

    protected $_prefixKey = 'client';



}