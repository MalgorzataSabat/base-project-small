<?php


class Client_Form_Field extends  Field_Form_Field_Abstract
{

    public function createElement($field, $fieldOptions, $form)
    {
        return new Client_Form_Element_Client($field['hash'], $fieldOptions);
    }


}