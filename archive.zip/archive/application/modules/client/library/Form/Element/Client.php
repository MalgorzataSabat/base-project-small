<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 15.09.2016
 * Time: 19:30
 */
class Client_Form_Element_Client extends Base_Form_Element_Select
{

    private $_defaultName       = 'id_client';
    private $_clientList    = array();
    private $_clientOptions = array();

    /**
     * @var false|Base_Doctrine_Record
     */
    private $_model = false;

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_client';
        }

        if(isset($options['model']) && $options['model']){
            $this->_model = $options['model'];
            unset($options['model']);
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        if(isset($options['searchable']) && $options['searchable']){
            $this->_registerInArrayValidator = false;
        }else{
            $options['validators'][] = array('InArray', true, array(array_keys($this->_clientOptions)));
        }

        if(isset($options['add-record']) && $options['add-record']){
            unset($options['add-record']);

            $options['input-group']['post'] = array(
                'type' => 'href',
                'href' => Base::url('client_new'),
                'label' => '<i class="fa fa-plus "></i>',
                'data-type' => 'ajax',
                'rel' => 'tooltip',
                'data-toggle' => 'overbox',
                'data-original-title' => $this->getView()->translate('field_client_quick-add'),
                'data-wrap-style' => 'width: 80%; max-width: 1000px;'
            );
        }

        $options['select2'] = array(
            'allowClear' => true
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    public function getClientList()
    {
        return $this->_clientList;
    }

    private function _loadMultiOptions(&$options)
    {
        $this->_clientOptions = array();
        $queryOptions = array('select' => 'o.id_client, o.hash, o.name');

        if($this->_model && isset($this->_model['created_at']) && $this->_model['created_at']){
            $queryOptions['archived_at'] = $this->_model['created_at'];
        }

        $this->_clientList = Client::getList($queryOptions);


        foreach ($this->_clientList as $v) {
            $this->_clientOptions[$v['id_client']] = $v['name'];
        }

        $this->_clientOptions = array('' => '') + $this->_clientOptions;

        $options['multioptions'] = $this->_clientOptions;
    }
}