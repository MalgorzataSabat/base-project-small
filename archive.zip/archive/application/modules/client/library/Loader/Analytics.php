<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 07.05.2018
 * Time: 11:38
 */

class Client_Loader_Analytics extends Analytics_Loader_Abstract
{

    protected $_groupOptions = array(
        'id_user_created',
        'id_status',
        'id_industry',
        'address_city',
        'created_at',
    );

    protected $_defaultGroup = 'id_user_created';

    protected $_queryResult;

    protected $_query;


    public function getResult()
    {

        $this->_query = Client::getQuery($this->_dataQuery);

        $methodName = 'getQueryGroupBy' . Base::lineToCamel($this->_data['group']);

        if (method_exists($this, $methodName)) {
            $this->$methodName();
        }

        $result = $this->_query->execute();

        foreach ($result as $v) {
            $label = !empty($v['stats_label']) ? $v['stats_label'] : 'Brak danych';
            $this->_result[] = array(
                $label,
                intval($v['stats_value']),
            );
        }

        return $this->_result;
    }

    private function getQueryGroupByIdUserCreated()
    {
        $this->_query->leftJoin('o.UserCreated uc');
        $this->_query->addSelect('CONCAT(uc.name, " ", uc.surname) as stats_label');
        $this->_query->addSelect('count(*) as stats_value');
        $this->_query->groupBy('o.' . $this->_data['group']);
    }

    private function getQueryGroupByIdStatus()
    {
        $this->_query->leftJoin('o.Status cs');
        $this->_query->addSelect('cs.name as stats_label');
        $this->_query->addSelect('count(*) as stats_value');
        $this->_query->groupBy('o.' . $this->_data['group']);
    }

    private function getQueryGroupByIdIndustry()
    {
        $this->_query->leftJoin('o.Industry i');
        $this->_query->addSelect('i.name as stats_label');
        $this->_query->addSelect('count(*) as stats_value');
        $this->_query->groupBy('o.' . $this->_data['group']);
    }

    private function getQueryGroupByAddressCity()
    {
        $this->_query->addSelect('o.address_city as stats_label');
        $this->_query->addSelect('count(*) as stats_value');
        $this->_query->groupBy('o.' . $this->_data['group']);
    }

    private function getQueryGroupByCreatedAt()
    {
        $this->_query->addSelect("DATE_FORMAT(o.created_at,'%m/%Y') as stats_label");
        $this->_query->addSelect('count(*) as stats_value');
        $this->_query->orderBy('o.created_at ASC');
        $this->_query->groupBy('stats_label');
    }

}