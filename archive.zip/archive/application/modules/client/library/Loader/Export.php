<?php


class Client_Loader_Export extends Client_Loader
{

    /**
     * @return array
     */
    public function getResult($select = null)
    {
        $filter = new Client_Form_Filter();
        $dataQuery = $filter->getValuesQuery(true);
        $selectColumn = join(',', $dataQuery['column']);
        $view = Base_Layout::getView();

        if ($this->getAll()) {
            $query = Client::getQuery($dataQuery)
                ->select($selectColumn);
        } elseif ($this->getValue()) {
            $query = Doctrine_Query::create()
                ->select($selectColumn)
                //->from('Client o INDEXBY o.id_client')
                ->from('Client o')
                ->whereIn('o.id_client', $this->getValue());

        }

        $query->addSelect('s.name as id_status');
        $query->leftJoin('o.Status s');
        $query->addSelect('so.name as id_source');
        $query->leftJoin('o.Source so');
        $query->addSelect("concat(uc.name, ' ',uc.surname) as id_user_created");
        $query->leftJoin('o.UserCreated uc');
        $query->addSelect("concat(uo.name, ' ',uo.surname) as id_user_owner");
        $query->leftJoin('o.UserOwner uo');
        $query->addSelect('ac.name as id_address_country');
        $query->leftJoin('o.Country ac');
        $query->addSelect("ap.name as id_address_province");
        $query->leftJoin('o.Province ap');

        if ($select) {
            $query->select($select);
        }

        $result = $query->execute(array(), Doctrine::HYDRATE_ARRAY);

        foreach($result as $k => $data){
            foreach ($dataQuery['column'] as $column) {
                $this->_labels[$column] = Base::getFiledName('client.'.$column);

                if ($column == 'tags') {
                    $tags = $data[$column] ? $data[$column] : '[]';
                    $this->_result[$k][$column] = join(', ', json_decode($tags, true));
                }elseif($column == 'id_industry'){
                    if($data[$column]){
                        $service = Industry_Service::_();
                        $children = $service->getParentByIdInd($data[$column]);
                        $this->_result[$k][$column] = trim(strip_tags(implode(' » ',$children)));
                    }else{
                        $this->_result[$k][$column] = '';
                    }
                }elseif($column == 'contact_person') {
                    if ($contactPerson = json_decode($data[$column], true)) {


                        $this->_result[$k][$column] = join(', ', $contactPerson);
                    } else {
                        $this->_result[$k][$column] = '';
                    }
                }elseif($column == 'id_client_image'){
                    if($data[$column]){
                        $this->_result[$k][$column] = PROTOCOL.'://'.DOMAIN.Image::getUrl($data[$column], array('resize' => 'o'));
                    }else{
                        $this->_result[$k][$column] = '';
                    }
                }else{
                    $this->_result[$k][$column] = trim(strip_tags($data[$column]));
                }
            }
        }


        unset($result);

        return $this->_result;
    }


}