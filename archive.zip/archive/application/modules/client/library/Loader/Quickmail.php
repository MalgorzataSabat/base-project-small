<?php


class Client_Loader_Quickmail extends Client_Loader
{

    public function getResult($select = null)
    {
        $result = parent::getResult('o.id_client, o.email');

        $emails = array();

        foreach($result as $v){
            $emails[] = $v['email'];
        }

        $emails = array_unique(array_filter($emails));

        return $emails;
    }


}