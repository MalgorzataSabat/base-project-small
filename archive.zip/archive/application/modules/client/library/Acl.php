<?php
class Client_Acl
{
    /**
     * @var Base_Acl
     */
    protected $_acl;

    /**
     * @param $acl Base_Acl
     */
    public function __construct($acl)
    {
        $this->_acl = $acl;
    }


    public function loadAcl()
    {
        $columns = Doctrine::getTable('Client')->getColumns();

        $this->_acl->addResource('field.client');
        $this->_acl->allow(Base_Auth::MAIN_ROLE_LOGIN, array('field.client'));

        foreach($columns as $name => $data){
            $this->_acl->addResource('field.client.'.$name, 'field.client');
        }

//        var_dump($this->_acl);
//        var_dump($columns);
//        exit();


        return $this->_acl;
    }


}