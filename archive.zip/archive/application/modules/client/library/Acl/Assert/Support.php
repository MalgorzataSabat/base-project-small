<?php

class Client_Acl_Assert_Support implements Zend_Acl_Assert_Interface
{

    public function assert(Zend_Acl $acl,
                           Zend_Acl_Role_Interface $role = null,
                           Zend_Acl_Resource_Interface $resource = null,
                           $privilege = null)
    {

        if($resource instanceof Base_Acl_Resource)
        {
            $access = $acl->isAllowed($role, 'bill_full');
            if($access){
                return true;
            }

            if(isset($resource->id_client)){
                $client = Client::getById($resource->id_client);
                if($client && ($client['id_user_owner'] == $role->id_user || strstr($client['assign_users'], '"'.$role->id_user.'"'))){
                    $access = true;
                }
            }

            
            return $access ;
        }

        return null;
    }

    /**
     * @param $query Doctrine_Query
     * @return Doctrine_Query
     */
    public function getQuery($query)
    {
        $query->leftJoin('o.Client c');
        $query->addWhere('(c.id_user_owner = ? OR c.assign_users LIKE ?)', array(Base_Auth::getUserId(), '%"'.Base_Auth::getUserId().'"%'));

        return $query;
    }

}
