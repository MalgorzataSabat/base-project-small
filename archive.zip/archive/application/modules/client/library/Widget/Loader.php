<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 23.03.2018
 * Time: 16:46
 */

class Client_Widget_Loader extends Base_Widget_Loader
{
    protected $_channel = 'Client';

    protected $_id_col = 'id_client';


    public function getParamsByWidget($widget)
    {
        $params = array();

        if($widget == 'Client_Widget_Card')
        {
            $params = array(
                'renderView' => 'card-full',
                'client' => $this->_model
            );
        }

        else{
            $params = parent::getParamsByWidget($widget);
        }


        return $params;
    }



}
