<?php

class Client_Import extends Import_Service implements Import_Service_Interface{


    protected $_tableName = 'client';

    private $_mapData = array();

    private $_defaultValues = array(
        'id_status' => null,
        'id_user_owner' => null,
    );

    public function __construct($options = array())
    {
        parent::__construct($options);

        $this->identifyRecordOptions = array(
            'nip' => Base::getFiledName('client.nip'),
            'name' => Base::getFiledName('client.name'),
            'short_name' => Base::getFiledName('client.short_name'),
            'email' => Base::getFiledName('client.email'),
            'phone' => Base::getFiledName('client.phone'),
        );

        $this->defaultForm = new Client_Form_Import(array('import' => $this->_import));

    }

    public function execute()
    {
        $this->_loadMapData();
        $data = $this->_getData();
        $selectedColumns = $this->getSelectedColumns();
        $headColumns = $this->getHeadColumns();

        $nipFilter = new Base_Filter_Nip();
        $phoneFilter = new Base_Filter_Phone();

        $identifyColName = false;
        if($this->_import['identify'] && ($identifyColId = array_search($this->_import['identify'], $selectedColumns)) !== false){
            $identifyColName = $this->_import['identify'];
        }

        if($this->_import['default_values']){
            $this->_defaultValues = json_decode($this->_import['default_values'], true);
        }


        $this->_log.= "Data importu: ".date('Y-m-d H:i:s')."\r\n";
        $this->_log.= "Kodowanie: ".$this->_import['encoding']."\r\n";
        $this->_log.= "Separator: ".$this->_import['divider']."\r\n";
        $this->_log.= "Tryb: ".$this->_import['mode']."\r\n";
        $this->_log.= "Użytkownik: ".User::getFullnameById(Base_Auth::getUserId())."\r\n\r\n";


        $_log = '';
        $_logCount = 0;
        $_logCountSkip = 0;
        $_logCountUpdate = 0;
        $_logCountCreate = 0;

        foreach($data as $row){
            $_log.= "\r\nWiersz #".(++$_logCount).'; ';
            $client = false;
            $description = array();

            // sprawdzamy czy rekord istnieje już w bazie
            if($identifyColName && $identifyColId !== false){

                switch ($identifyColName){
                    case 'phone': { $searchValue = $phoneFilter->filter($row[$identifyColId]); break; }
                    case 'nip':   { $searchValue = $nipFilter->filter($row[$identifyColId]); break; }
                    default:      { $searchValue = $row[$identifyColId]; }
                }

                $searchValue = trim($searchValue);

                if(!$searchValue && $this->_import['identify_skip']){
                    $_log.= "Pomijam, Identyfikator wiersza jest pusty \"".$identifyColName."\" ";
                    $_logCountSkip++;
                    continue;
                }

                $_log.= "Szukam po \"".Base::getFiledName('client.'.$identifyColName)."\": \"".$searchValue."\"; ";

                $searchResult = Client::getQuery(array('hydrate' => Doctrine::HYDRATE_RECORD))
                    ->addWhere('o.'.$identifyColName. ' = ?', array($searchValue))
                    ->execute();

                if($searchResult->count() > 1){
                    $_log.= "Pomijam, znaleziono kilka pasujących rekordów do podanego identyfikatora; ";
                    $_logCountSkip++;
                    continue;
                }else{
                    $client = $searchResult->getFirst();
                }

                if($client){
                    $_log.= "Czy istnieje: TAK; ";
                }else{
                    $_log.= "Czy istnieje: NIE; ";
                }
            }


            // sprawdzamy tryb importu
            if($this->_import['mode'] == Import::MODE_ADD){ // tryb tylko do dodania
                if($client){
                    $_log.= "Pomijam, tryb importu tylko do dodania.";
                    $_logCountSkip++;
                    continue;
                } // rekord już istnieje - teraz tylko dodajemy
            }elseif($this->_import['mode'] == Import::MODE_UPDATE){
                if(!$client){
                    $_log.= "Pomijam, tryb importu tylko do aktualizcji.";
                    $_logCountSkip++;
                    continue;
                } // brak rekordu - teraz tylko aktualizujemy
            }


            if(!$client){
                $client = new Client();
                $client['client_type'] = Setting::getSetting('client.default_client_type');
                $_log.= "Dodaję nowy rekord; ";
                $_logCountCreate++;
            }else{
                $description[] = $client['description'];
                $_log.= "Aktualizuję rekord; ";
                $_logCountUpdate++;
            }

            // przypisywanie pól z importowanego pliku
            foreach($selectedColumns as $colId => $colName){
                if(!$colName || $colName == '-') continue;

                $value = $row[$colId];

                switch ($colName){
                    case 'tags' :{
                        $tags = array_unique(array_filter(array_map('trim', explode(',',$value))));
                        $client->setTags($tags);
                        break;
                    }
                    case 'phone' :{ $client['phone'] = $phoneFilter->filter($value); break; }
                    case 'nip'   :{ $client['nip'] = $nipFilter->filter($value); break; }
                    case '_desc_':{
                        $description[] = $headColumns[$colId].': '.$value;
                        break;
                    }
                    default:{
                        isset($this->_mapData[$colName][$value]) && $value = $this->_mapData[$colName][$value];
                        $client[$colName] = $value ? trim($value) : null;
                    }
                }
            }

            // uzupełnienie domyślnymi wartościami jeśli były podane
            foreach($this->_defaultValues as $colName => $value){
                if($value && !$client[$colName]){
                    $client[$colName] = $value;
                }
            }

            $client['description'].= join('<br/>', array_filter($description)) ;

            try{
                $client->save();
                $_log.= "Zapisano: \"".trim($client['name'])."\"";
            }catch (Exception $e){
                $_log.= "Błąd zapisu: \"".join(';', $row)."\"";

                if(DEBUG){
                    var_dump($e);
                    var_dump($client->toArray());
                    exit();
                }
            }
        }


        $this->_log.= "Ilość rekordów: ".$_logCount."\r\n";
        $this->_log.= "Rekordów pominiętych: ".$_logCountSkip."\r\n";
        $this->_log.= "Rekordów dodanych: ".$_logCountCreate."\r\n";
        $this->_log.= "Rekordów zaktualizowanych: ".$_logCountUpdate."\r\n";

        $this->_log.= $_log;

    }


    private function _loadMapData()
    {
        // wczytanie listy statusów
        $statusList = Dictionary::getListByObject('ClientStatus');
        $this->_mapData['id_status'] = array_column($statusList, 'id_dictionary', 'name');

        // wczytanie listy źródła klienta
        $sourceList = Dictionary::getListByObject('ClientSource');
        $this->_mapData['id_source'] = array_column($sourceList, 'id_dictionary', 'name');

        // wczytanie listy userów
        $userList = User::getList(array('fullname' => true));
        $this->_mapData['id_user_owner'] = array_column($userList, 'id_user', 'fullname');
        $this->_mapData['id_user_created'] = $this->_mapData['id_user_owner'];

        // wczytanie listy województw/regionów
        $provinceList = AddressProvince::getList();
        $this->_mapData['id_address_province'] = array_column($provinceList, 'id_province', 'name');
    }


}
