<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('client_api_create', new Zend_Controller_Router_Route(
    '/client/api/create',
    array(
        'module' => 'client',
        'controller' => 'api',
        'action' => 'create'
    )
));




Zend_Controller_Front::getInstance()->setRouter($router);