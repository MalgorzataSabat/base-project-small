<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('client_ajax_get-client', new Zend_Controller_Router_Route(
    '/@client/ajax/get-client/:id_client',
    array(
        'module' => 'client',
        'controller' => 'ajax',
        'action' => 'get-client',
        'id_client' => null,
    ),
    array(
        'id_client' => '((\d+)|([0-9a-f]{32}))'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
