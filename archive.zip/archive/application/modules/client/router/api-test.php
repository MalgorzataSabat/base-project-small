<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('client_api-test_create', new Zend_Controller_Router_Route(
    '/client/api/test/create',
    array(
        'module' => 'client',
        'controller' => 'api-test',
        'action' => 'create'
    )
));




Zend_Controller_Front::getInstance()->setRouter($router);