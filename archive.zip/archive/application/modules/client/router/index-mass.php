<?php

$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('client_mass-status', new Zend_Controller_Router_Route(
    '/@client/@mass-status',
    array(
        'module' => 'client',
        'controller' => 'index-mass',
        'action' => 'status'
    )
));


$router->addRoute('client_mass-archive', new Zend_Controller_Router_Route(
    '/@client/@mass-archive',
    array(
        'module' => 'client',
        'controller' => 'index-mass',
        'action' => 'archive'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);