<?php
$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('client', new Zend_Controller_Router_Route(
    '/@client',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('client_new', new Zend_Controller_Router_Route(
    '/@client/@new',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'new'
    )
));

$router->addRoute('client_edit', new Zend_Controller_Router_Route(
    '/@client/@edit/:id_client',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'edit'
    ),
    array(
        'id_client' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('client_show', new Zend_Controller_Router_Route(
    '/@client/@show/:id_client',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'show'
    ),
    array(
        'id_client' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('client_delete', new Zend_Controller_Router_Route(
    '/@client/@delete/:id_client',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'delete'
    ),
    array(
        'id_client' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('client_archive', new Zend_Controller_Router_Route(
    '/@client/@archive/:id_client',
    array(
        'module' => 'client',
        'controller' => 'index',
        'action' => 'archive'
    ),
    array(
        'id_client' => '((\d+)|([0-9a-f]{32}))'
    )
));

Zend_Controller_Front::getInstance()->setRouter($router);
