<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.09.2016
 * Time: 17:44
 */
class Client_Bootstrap extends Base_Application_Module_Bootstrap
{

    public function _initWidget()
    {
        if(DEV){
            Base_Widget::registerWidget('Client_Widget_Card');
        }
    }

    public function _initAnalytics()
    {
        Base_Analytics::addChannel('client', array(
            'key' => 'client',
            'name' => 'analytics_channel_client',
            'filter' => 'Client_Form_Filter',
            'loader' => 'Client_Loader_Analytics',
        ));

    }

}