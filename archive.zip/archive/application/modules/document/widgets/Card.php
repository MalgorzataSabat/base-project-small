<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 29.03.2018
 * Time: 14:13
 */

class Document_Widget_Card extends Base_Widget_Abstract
{
    public      $name           = 'label_widget_document_card';
    public      $_renderView    = 'card.phtml';
    protected   $_document = false;

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }

    public function renderWidget()
    {
        if(!isset($this->params['document'])){
            $this->_renderView = null;
            return;
        }


        if($this->params['document'] instanceof Document)
        {
            $this->_document = $this->params['document'];

        } elseif (is_array($this->params['document'])) {

        } else {
            $this->_document = Document::findRecord($this->params['document']);
        }

        $this->view->document = $this->_document;
    }
}