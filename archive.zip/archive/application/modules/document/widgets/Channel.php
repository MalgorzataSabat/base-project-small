<?php

class Document_Widget_Channel extends Base_Widget_Abstract
{

    public      $name           = 'label_widget_document_channel';
    public      $_renderView    = 'channel.phtml';

    public function getViewScriptsDir()
    {
        return __DIR__;
    }

    public function getRenderView()
    {
        return $this->_renderView;
    }


    public function renderWidget()
    {
        $channel = isset($this->params['channel']) ? $this->params['channel'] : null;
        $object_id = isset($this->params['object_id']) ? $this->params['object_id'] : null;
        $id_category = isset($this->params['id_category']) ? $this->params['id_category'] : null;

        if(!$channel){
            $this->_renderView = null;
            return;
        }


        $documentList = Document::getList(array(
            'channel' => $channel,
            'object_id' => $object_id,
            'id_category' => $id_category,
            'order' => 'o.id_category ASC, o.name ASC',
            'addUserCreated' => '',
        ));

        $documentListCategory = array();

        foreach($documentList as $document){
            $key = $document['id_category'] ? $document['id_category'] : 0;
            $documentListCategory[$key][$document['id_document']] = $document;
        }

        $this->view->channel = $channel;
        $this->view->object_id = $object_id;
        $this->view->id_category = $id_category;
        $this->view->documentListCategory = $documentListCategory;
    }
}