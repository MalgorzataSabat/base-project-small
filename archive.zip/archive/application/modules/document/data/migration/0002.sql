SET @id_acl_resource001 = (SELECT id_acl_resource FROM acl_resource WHERE name = 'document_read');

INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource001, 'document_index_index'), (NULL, @id_acl_resource001, 'document_index_show');
INSERT INTO `acl_resource_item` (`id_acl_resource_item`, `id_acl_resource`, `name`) VALUES (NULL, @id_acl_resource001, 'document_index_get-file');