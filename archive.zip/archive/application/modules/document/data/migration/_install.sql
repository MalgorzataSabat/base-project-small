-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id_document` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identyfikator',
  `id_service` int(10) unsigned NOT NULL COMMENT 'Identyfikator serwisu',
  `hash` char(32) NOT NULL COMMENT 'Identyfikator hash',
  `id_document_parent` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator rodzica',
  `id_user_created` int(10) unsigned DEFAULT NULL COMMENT 'Identyfikator użytkownika, który utworzył plik',
  `id_category` smallint(5) unsigned DEFAULT NULL COMMENT 'Identyfikator kategorii',
  `object_id` int(10) unsigned DEFAULT NULL COMMENT 'ID Obiektu',
  `channel` varchar(255) NOT NULL COMMENT 'Kanał',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data utworzenia',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Data modyfikacji',
  `archived_at` timestamp NULL DEFAULT NULL COMMENT 'Data archiwizacji',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'Data usunięcia',
  `name` varchar(255) NOT NULL COMMENT 'Nazwa',
  `desc` text NOT NULL COMMENT 'Opis',
  `filename` varchar(255) NOT NULL COMMENT 'Nazwa pliku',
  `filename_real` varchar(255) NOT NULL COMMENT 'Ścieżka do pliku',
  `file_ext` varchar(16) NOT NULL COMMENT 'Rozszerzenie pliku',
  `file_mime_type` varchar(255) NOT NULL COMMENT 'Mime type pliku',
  `file_size` bigint(20) unsigned NOT NULL COMMENT 'Wielkość pliku',
  PRIMARY KEY (`id_document`),
  UNIQUE KEY `hash` (`hash`),
  KEY `id_user_created` (`id_user_created`),
  KEY `id_category` (`id_category`),
  KEY `id_document_parent` (`id_document_parent`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `document_ibfk_1` FOREIGN KEY (`id_user_created`) REFERENCES `user` (`id_user`) ON DELETE SET NULL,
  CONSTRAINT `document_ibfk_2` FOREIGN KEY (`id_category`) REFERENCES `dictionary` (`id_dictionary`) ON DELETE SET NULL,
  CONSTRAINT `document_ibfk_3` FOREIGN KEY (`id_document_parent`) REFERENCES `document` (`id_document`) ON DELETE SET NULL,
  CONSTRAINT `document_ibfk_4` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (NULL,'document','Dokumenty','');
SET @resParentId54861 = LAST_INSERT_ID();
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54861,'document_read','Przeglądanie','');
SET @resParentId54862 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54862,'document');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54862,'document_index');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54862,'document_index_download');
INSERT INTO `acl_resource` (`id_parent`, `name`, `text`, `desc`) VALUES (@resParentId54861,'document_write','Zarządzanie','');
SET @resParentId54863 = LAST_INSERT_ID();
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54863,'document_index_new');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54863,'document_index_edit');
INSERT INTO `acl_resource_item`(`id_acl_resource`, `name`) VALUES (@resParentId54863,'document_index_archive');
-- Dump MODULE: document
INSERT INTO `acl_rule`(`is_allow`, `role`, `resource`) VALUES ('1', 'user', 'document');
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: base-crm.local_20171221
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `database_changelog`
--
-- WHERE:  module = 'document'

LOCK TABLES `database_changelog` WRITE;
/*!40000 ALTER TABLE `database_changelog` DISABLE KEYS */;
INSERT INTO `database_changelog` VALUES ('0001.20171113182043.csv','document','2017-11-13 17:20:43',2),('0001.sql','document','2017-12-13 10:46:55',1),('0002.20171114141439.csv','document','2017-11-14 13:14:39',2),('_install.sql','document','2017-11-14 13:39:57',1);
/*!40000 ALTER TABLE `database_changelog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-22 12:44:46
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_form_file_name','label','2017-11-13 17:34:01','2017-11-14 13:55:25','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa pliku');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_form_file_file','label','2017-11-13 17:34:16','2017-11-14 13:55:32','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Plik');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_form_file_desc','label','2017-11-13 17:34:30','2017-11-14 13:55:38','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Opis');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('page-title_document_new','label','2017-11-13 17:34:46','2017-11-13 17:34:46','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nowy dokument');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_form_file_name-desc','label','2017-11-13 17:36:04','2017-11-14 13:55:46','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Wybierz plik, aby automatycznie uzupełnić nazwę.');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_form_file_id_category','label','2017-11-13 18:04:08','2017-11-14 13:55:52','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Kategoria');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_document_col_created_at','label','2017-11-14 11:42:39','2017-11-14 11:42:39','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Dodano');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_document_col_name','label','2017-11-14 11:42:51','2017-11-14 11:42:51','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nazwa');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('label_document_col_id_user_created','label','2017-11-14 11:43:14','2017-11-14 11:43:14','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Utworzony przez');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_default-category_name','label','2017-11-14 12:50:00','2017-11-14 13:04:45','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','<em class=\"txt-color-blue\">brak</em>');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('document_widget_empty-list','label','2017-11-14 12:55:17','2017-11-14 12:55:17','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Nie dodano jeszcze dokumentów.');
INSERT INTO `label`(`label`, `type`, `created_at`, `modified_at`, `module`, `from_import`) VALUES ('page-title_document_edit','label','2017-11-14 13:53:18','2017-11-14 13:53:18','document','0');
INSERT INTO `label_translation`(`id_label`, `id_language`, `value`) VALUES (LAST_INSERT_ID(),'2','Edycja dokumentu');
