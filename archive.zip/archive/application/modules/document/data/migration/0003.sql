INSERT INTO `dictionary` (`id_dictionary`, `id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES (NULL, '1', 'DocumentStatus', 'Rejestracja', '1', '0', '1', 'primary', '', ''), (NULL, '1', 'DocumentStatus', 'Do akceptacji', '2', '0', '0', 'info', '', ''), (NULL, '1', 'DocumentStatus', 'Zaakceptowany', '3', '1', '0', 'success', '', ''), (NULL, '1', 'DocumentStatus', 'Odrzucony', '4', '1', '0', 'danger', '', '');

ALTER TABLE `document` ADD `id_status` INT(11) UNSIGNED NULL COMMENT 'Status' AFTER `id_user_created`, ADD INDEX (`id_status`);

ALTER TABLE `document` ADD FOREIGN KEY (`id_status`) REFERENCES `dictionary`(`id_dictionary`) ON DELETE SET NULL ON UPDATE RESTRICT;

INSERT INTO `dictionary` (`id_service`, `object`, `name`, `order`, `is_closed`, `is_default`, `class`, `style`, `data`) VALUES
(2, 'DocumentStatus', 'Rejestracja', 1, 0, 1, 'primary', '', ''),
(2, 'DocumentStatus', 'Do akceptacji', 2, 0, 0, 'info', '', ''),
(2, 'DocumentStatus', 'Zaakceptowany', 3, 1, 0, 'success', '', ''),
(2, 'DocumentStatus', 'Odrzucony', 4, 1, 0, 'danger', '', '');
