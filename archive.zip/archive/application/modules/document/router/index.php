<?php

$router = Zend_Controller_Front::getInstance()->getRouter();

$router->addRoute('document', new Zend_Controller_Router_Route(
    '/@document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'index'
    )
));

$router->addRoute('document_index', new Zend_Controller_Router_Route(
    '/@document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'index',
    )
));

$router->addRoute('document_show', new Zend_Controller_Router_Route(
    '/@document/@show/:id_document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'show',
    ),array(
        'id_document' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('document_new', new Zend_Controller_Router_Route(
    '/@document/@new/:channel/:object_id',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'new',
        'object_id' => null,
    ),array(
        'channel' => '.*'
    )
));

$router->addRoute('document_download', new Zend_Controller_Router_Route(
    '/@document/@download/:id_document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'download',
    ),array(
        'id_document' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('document_edit', new Zend_Controller_Router_Route(
    '/@document/@edit/:id_document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'edit',
    ),array(
        'id_document' => '((\d+)|([0-9a-f]{32}))'
    )
));

$router->addRoute('document_archive', new Zend_Controller_Router_Route(
    '/@document/@archive/:id_document',
    array(
        'module' => 'document',
        'controller' => 'index',
        'action' => 'archive',
    ),array(
        'id_document' => '((\d+)|([0-9a-f]{32}))'
    )
));


Zend_Controller_Front::getInstance()->setRouter($router);