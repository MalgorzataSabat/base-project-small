<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 29.03.2018
 * Time: 13:10
 */

class Document_Form_Element_Channel extends Base_Form_Element_Select
{
    private $_defaultName           = 'channel';
    private $_channelList      = array();

    public function __construct($name = null, $options = array())
    {
        empty($name) && $name = $this->_defaultName;

        if ( !array_key_exists('label', $options) ) {
            $options['label'] = 'field_channel';
        }

        if ( !array_key_exists('multioptions', $options) ) {
            $this->_loadMultiOptions($options);
        }

        $options['select2'] = array(
            'allowClear' => true,
        );

        $options['prefixPath'] = array(
            'decorator' => array('Base_Form_Decorator' => 'Base/Form/Decorator')
        );

        return parent::__construct($name, $options);
    }

    public function getChannelList()
    {
        return $this->_channelList;
    }

    private function _loadMultiOptions(&$options)
    {
        $channelOptions = array();
        $this->_channelList = Document::getList();

        foreach ($this->_channelList as $id_channel => $v) {
            $channelOptions[$v['channel']] = $v['channel'];
        }

        $channelOptions = array('' => '') + $channelOptions;

        $options['multioptions'] = $channelOptions;

        $options['validators'][] = array('InArray', true, array(array_keys($channelOptions)));
    }
}