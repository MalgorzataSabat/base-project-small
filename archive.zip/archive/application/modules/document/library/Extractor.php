<?php


class Document_Extractor extends Base_Extractor
{

    protected $_tables = array('document');

    protected $_data = array();

    protected $_module = 'document';

    protected $_dumpResource = array('document');

    protected $_dumpRule = array('document');

    protected $_dumpLabel = array('document');

    protected $_dumpChangelog = array('document');

    protected $_dumpSettings = array('document');

    protected $_dumpDictionary = array();


}