<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 12.05.2017
 * Time: 15:36
 */
class Document_IndexController extends Base_Controller_Action
{

    /**
     * @var $_document Document
     */
    private $_document = null;

    private $_dataQuery;
    private $_formFilter;
    private $_previewShow = null;


    public function indexAction()
    {
        $this->_formFilter = new Document_Form_Filter();
        $this->_dataQuery = $this->_formFilter->getValuesQuery(true);
        $this->_dataQuery['channel'] = Document::class;

        $query = Document::getQuery($this->_dataQuery);

        $this->view->documentList = $this->_helper->paging($query);
        $this->view->formFilter = $this->_formFilter;
    }

    public function showAction()
    {
        $this->_document = Document::findRecord($this->getParam('id_document'));
        $this->forward403Unless($this->_document);


        $this->view->document = $this->_document;
    }

    /**
     * @todo check access to channel and object_id
     */
    public function newAction()
    {
        $this->_document = new Document();
        $this->_document->setChannel($this->_getParam('channel'));
        $this->_document->setObjectId($this->_getParam('object_id'));

        $form = new Document_Form_NewFile(array('model' => $this->_document));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() && $form->isValid($this->_request->getPost()))
        {
            $this->_document->save();

            if ( $this->_request->isXmlHttpRequest() ) {
                $this->_helper->viewRenderer('form-ajax-result');
            }else{
                $return = $this->_request->getServer('HTTP_REFERER', Base::url('home'));
                $this->_redirector()->gotoUrlAndExit($return);
            }
        }

        $this->view->document = $this->_document;
        $this->view->form = $form;
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('page-title_document_new') );
    }

    public function editAction()
    {
        $this->_document = Document::findRecord($this->getParam('id_document'));
        $this->forward403Unless($this->_document);

        $form = new Document_Form_EditFile(array('model' => $this->_document));
        $this->_helper->viewRenderer('form');

        if ( $this->_request->isPost() && $form->isValid($this->_request->getPost()))
        {
            $this->_document->save();

            if ( $this->_request->isXmlHttpRequest() ) {
                $this->_helper->viewRenderer('form-ajax-result');
            }else{
                $return = $this->_request->getServer('HTTP_REFERER', Base::url('home'));
                $this->_redirector()->gotoUrlAndExit($return);
            }
        }

        $this->view->document = $this->_document;
        $this->view->form = $form;
        $this->view->placeholder( 'page-title' )->set( $this->view->translate('page-title_document_edit') );
    }

    public function archiveAction()
    {
        $this->_document = Document::findRecord($this->getParam('id_document'));
        $this->forward403Unless($this->_document);

        $this->_document->archived_at = $this->_document->archived_at === null ? date('Y-m-d H:i:s') : null;
        $this->_document->save();

        if ( $this->_document->archived_at ) {
            $this->_flash()->success->addMessage('label_cms_archive_success');
        } else {
            $this->_flash()->success->addMessage('label_cms_unarchive_success');
        }

        if ( $this->_request->isXmlHttpRequest() ) {
            $this->_helper->viewRenderer('archive-ajax-result');
        }else{
            $return = $this->_request->getServer('HTTP_REFERER', Base::url('home'));
            $this->_redirector()->gotoUrlAndExit($return);
        }
    }


    public function downloadAction()
    {
        Base_Layout::disableLayout();
        Base_Layout::disableView();
        $this->_document = Document::find($this->getParam('id_document'));
        $this->forward403Unless($this->_document);

        $filename_real = Document::getBasePath() . DS . $this->_document['filename_real'];

        if ( file_exists($filename_real) ) {
            ob_clean();
            ob_end_flush();

            header('Content-Length: ' . $this->_document['file_size']);
            header('Content-Type: '. $this->_document['file_mime_type']);

            if($this->hasParam('preview')) {
                header('Content-Disposition: inline; filename=' . $this->_document['filename']);
                readfile($filename_real);
            } else {
                header('Content-Description: File Transfer');
                header('Content-Disposition: attachment; filename='.$this->_document['filename']);
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
            }

            $handle = @fopen($filename_real, 'r');
            if($handle){
                while (($buffer = fgets($handle, 4096)) !== false) {
                    echo $buffer;
                }

                fclose($handle);
            }
            exit();
        } else {
            throw new Exception('File ' . $filename_real . ' doesn`t exist.');
        }
    }

}