<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 29.03.2018
 * Time: 12:55
 */

class Document_Form_Filter extends Base_Form_Filter
{

    protected $_sortCols        = array(
        'id_document' => 'o.id_document',
        'id_user_created' => 'o.id_user_created',
//        'id_category' => 'o.id_category',
        'id_status' => 'o.id_status',
        'created_at' => 'o.created_at',
        'updated_at' => 'o.updated_at',
        'archived_at' => 'o.archived_at',
        'name' => 'o.name',
        'filename' => 'o.filename',
        'filesize' => 'o.file_size'
    );
    protected $_avalibleCols    = array(
        'id_document' => 'filter_document-column_id_document',
        'id_user_created' => 'filter_document-column_id_user_created',
        'id_status' => 'filter_document-column_id_status',
//        'id_category' => 'filter_document-column_id_category',
//        'channel' => 'filter_document-column_channel',
//        'object_id' => 'filter_document-column_object_id',
        'created_at' => 'filter_document-column_created_at',
        'updated_at' => 'filter_document-column_updated_at',
        'archived_at' => 'filter_document-column_archived_at',
        'name' => 'filter_document-column_name',
        'filename' => 'filter_document-column_filename',
    );

    protected $_fieldsAllow     = array(
        'name',
        'id_user_created',
        'id_status',
//        'id_category',
        'created_at',
        'archived_at'
    );

    protected $_fieldsDisplay   = array(
        'name'
    );

    protected $_defaultCols     = array(
        'created_at',
//        'channel',
//        'object_id',
//        'id_category',
        'id_status',
        'name',
        'filename',
        'id_user_created',
        'updated_at'
    );

    public function init()
    {
        $this->_searchElements['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
        ));

//        $this->_searchElements['id_category'] = new Dictionary_Form_Element_Select('id_status', array(
//            'label' => $this->_tlabel.'id_category',
//            'object' => Document::class.'DocumentCategory',
//            'decorators' => $this->_elementDecorators
//        ));

        $this->_searchElements['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
            'label' => $this->_tlabel.'id_status',
            'object' => 'DocumentStatus',
            'decorators' => $this->_elementDecorators
        ));

        $this->_searchElements['id_user_created'] = new User_Form_Element_User('id_user_created', array(
            'label' => $this->_tlabel.'id_user_created',
            'decorators' => $this->_elementDecorators
        ));

        $this->_searchElements['created_at'] = $this->createElement('search_Date', 'created_at', array(
            'label' => $this->_tlabel . 'created_at',
            'filters' => array('StringTrim'),
            'validators' => array(
                array('Date', true, array('format' => 'yyyy-MM-dd'))
            )
        ));

        $this->_searchElements['archived_at'] = new Base_Form_Element_ArchivedAt();
    }
}