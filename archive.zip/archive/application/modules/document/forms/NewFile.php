<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Document_Form_NewFile extends Base_Form_Horizontal
{
    protected $_tlabel = 'document_form_file_';

    public function init()
    {
        $fields = array();

        $this->setAction(Base::url());

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
//            'description' => $this->_tlabel.'name-desc',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
        ));

        if($this->_model['channel'] == 'Document')
        {
            $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
                'label' => $this->_tlabel.'id_status',
                'object' => 'DocumentStatus',
                'required' => true,
                'allowEmpty' => false,
                'decorators' => $this->_elementDecorators,
                'filters' => array('Null'),
            ));
        }

        $categoryFiled = new Dictionary_Form_Element_Select('id_category', array(
            'label' => $this->_tlabel.'id_category',
            'object' => ucfirst($this->_model['channel']).'DocumentCategory',
            'required' => false,
            'allowEmpty' => true,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $multiOptions = array_filter($categoryFiled->getMultiOptions());
        if($multiOptions){
            $fields['id_category'] = $categoryFiled;
        }

        $fields['file'] = $this->createElement('file', 'file', array(
            'label' => $this->_tlabel.'file',
            'required' => true,
            'allowEmpty' => false,
            'style' => 'width: 100%; text-align: left',
            'validators' => array(
                array('File_ExcludeExtension', true, 'exe,php,php4,php5'),
                array('File_MaxPostSize', true, array())
            ),
        ));

        $fields['desc'] = $this->createElement('textarea', 'desc', array(
            'label' => $this->_tlabel.'desc',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'data-small' => true,
            'value' => $this->_model['desc'],
            'rows' => 5,
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

    public function postIsValid($data)
    {
        parent::postIsValid($data);

        $values = $this->getValues(true);

        if (empty($values['filename'])) {
            $adapter = $this->file->getTransferAdapter();
            $fileInfo = $adapter->getFileInfo();
            $file_ext = pathinfo($fileInfo['file']['name'], PATHINFO_EXTENSION);
            $filename = $fileInfo['file']['name'];
            $file_from = $fileInfo['file']['tmp_name'];
            $file_mime_type = $fileInfo['file']['type'];
            $file_size = $fileInfo['file']['size'];
        } else {
            $file_ext = Base::getFileExt($values['filename']);
            $filename = $values['filename'];
            $file_from = APPLICATION_DATA . DS . 'upload' . DS . $values['filename'];
            $file_mime_type = mime_content_type($file_from);
            $file_size = filesize($file_from);
        }


        $date = date('Y-m');
        $path = Document::getBasePath() . DS . $date;
        Base::createDir($path);

        $filename_real = $date . DS . Base::getUniqueFileName('', $filename);
        $filename_full = Document::getBasePath() . DS . $filename_real;

        rename($file_from, $filename_full);

        if(empty($this->_model['name'])){
            $this->_model->name = $filename;
        }

        $this->_model->filename = $filename;
        $this->_model->filename_real = $filename_real;
        $this->_model->file_ext = $file_ext;
        $this->_model->file_mime_type = $file_mime_type;
        $this->_model->file_size = $file_size;

        return true;
    }

}