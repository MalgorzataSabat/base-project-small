<?php

/**
 * Created by PhpStorm.
 * User: skotar
 * Date: 10.09.2016
 * Time: 15:55
 */
class Document_Form_EditFile extends Base_Form_Horizontal
{
    protected $_tlabel = 'document_form_file_';

    public function init()
    {
        $fields = array();

        $this->setAction(Base::url());

        $fields['name'] = $this->createElement('text', 'name', array(
            'label' => $this->_tlabel.'name',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'validators' => array(
                array('NotEmpty', true)
            ),
            'value' => $this->_model['name']
        ));

        if($this->_model['channel'] == 'Document')
        {
            $fields['id_status'] = new Dictionary_Form_Element_Select('id_status', array(
                'label' => $this->_tlabel.'id_status',
                'object' => 'DocumentStatus',
                'required' => true,
                'allowEmpty' => false,
                'decorators' => $this->_elementDecorators,
                'filters' => array('Null'),
                'value' => $this->_model['id_status']
            ));
        }

        $categoryFiled = new Dictionary_Form_Element_Select('id_category', array(
            'label' => $this->_tlabel.'id_category',
            'object' => ucfirst($this->_model['channel']).'DocumentCategory',
            'required' => false,
            'allowEmpty' => true,
            'decorators' => $this->_elementDecorators,
            'filters' => array('Null'),
            'use_default' => true,
        ));

        $multiOptions = array_filter($categoryFiled->getMultiOptions());
        if($multiOptions){
            $fields['id_category'] = $categoryFiled;
        }

        $fields['desc'] = $this->createElement('textarea', 'desc', array(
            'label' => $this->_tlabel.'desc',
            'required' => false,
            'allowEmpty' => true,
            'filters' => array('StringTrim'),
            'data-small' => true,
            'value' => $this->_model['desc'],
            'rows' => 5,
        ));

        $this->addDisplayGroup($fields, 'main');

        $save = $this->createElement('button', 'submit', array(
            'label' => 'cms_button_save',
            'icon' => 'save',
            'type' => 'submit'
        ));

        $this->setFormActions(array($save));
        $this->addElements(array($save));

        $this->setAttrib('class', $this->getAttrib('class').' ajax');
        $this->setAttrib('id', $this->getElementsBelongTo());
        $this->setAttrib('data-overbox-replace', true);
    }

}