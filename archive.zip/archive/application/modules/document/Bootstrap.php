<?php
/**
 * Created by PhpStorm.
 * User: Robert Rogiński
 * Date: 15.06.2015
 * Time: 16:52
 */

class Document_Bootstrap extends Base_Application_Module_Bootstrap {


    public function _initWidget()
    {
        if(DEV){
            Base_Widget::registerWidget('Document_Widget_Channel');
        }
    }

} 