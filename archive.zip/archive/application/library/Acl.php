<?php
class Default_Acl
{
    /**
     * @var Base_Acl
     */
    protected $_acl;

    /**
     * @param $acl Base_Acl
     */
    public function __construct($acl)
    {
        $this->_acl = $acl;
    }


    public function loadAcl()
    {
        $this->_acl->addResource('default_cron_index', '_basic');

        $this->_acl->addResource('default_index_manifest', '_basic');
        $this->_acl->addResource('default_error_error', '_basic');
        $this->_acl->addResource('default_error_error404', '_basic');
        $this->_acl->addResource('default_error_error503', '_basic');
        $this->_acl->addResource('default_tools_cookie', '_basic');

        $this->_acl->addResource('default_index_index', '_user');
        $this->_acl->addResource('default_tools_gus', '_user');
        $this->_acl->addResource('default_tools_search', '_user');
        $this->_acl->addResource('default_tools_get-file', '_user');

        $this->_acl->addResource('default_query_delete', '_user');
        $this->_acl->addResource('default_query_edit', '_user');
        $this->_acl->addResource('default_query_index', '_user');
        $this->_acl->addResource('default_query_new', '_user');
        $this->_acl->addResource('default_query_save', '_user');
        $this->_acl->addResource('default_query_save-order', '_user');


        return $this->_acl;
    }


}